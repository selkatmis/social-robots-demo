import enum
from abc import ABC, abstractmethod
from typing import Any, List, Optional

from robond.core.listener_backend import UNSET


class Expression(enum.Enum):
    HAPPY     = "happy"
    EXCITED   = "excited"
    NEUTRAL   = "neutral"
    SAD       = "sad"
    ANGRY     = "angry"
    SURPRISED = "surprised"
    THINKING  = "thinking"
    SMILE     = "smile"
    CONFUSED  = "confused"
    SHY       = "shy"
    EYES_HEARTS = "eyes_hearts" # Mini
    EYES_SUNGLASSES = "eyes_sunglasses" #Mini

class Gesture(enum.Enum):
    WAVE          = "wave"
    NOD           = "nod"
    CLAP          = "clap"
    HAPPY         = "happy"
    STRETCH       = "stretch"
    CHEER         = "cheer"
    GREET         = "greet"
    FAREWELL      = "farewell"
    FAREWELL_WARM = "farewell_warm"
    POINT_FRONT   = "point_front"
    WIGGLE_BUTT   = "wiggle_but" # Mini
    DANCE1        = "dance1" # Mini
    DANCE2        = "dance2" # Mini
    DANCE3        = "dance3" # Mini


class RobotInterface(ABC):
    """Abstract interface for social robot control. All robot implementations must extend this."""

    @abstractmethod
    def say(self, text: str) -> None:
        pass

    @abstractmethod
    def set_expression(self, expression: Expression) -> None:
        pass

    @abstractmethod
    def play_gesture(self, gesture: Gesture, speed: float = 0.5) -> None:
        pass

    @abstractmethod
    def set_language(self, lang: str) -> None:
        pass

    def say_with_gesture(self, text: str, gesture: Gesture, speed: float = 0.5) -> None:
        self.play_gesture(gesture, speed)
        self.say(text)

    @abstractmethod
    def coordinated_action(self, text: str, gesture: Optional[Gesture] = None,
                           expression: Optional[Expression] = None, speed: float = 0.5) -> None:
        pass

    @abstractmethod
    def is_speaking(self) -> bool:
        pass

    @abstractmethod
    def get_available_gestures(self) -> List[Gesture]:
        pass

    @abstractmethod
    def get_available_expressions(self) -> List[Expression]:
        pass

    @abstractmethod
    def listen(self, timeout: int = 10, silence_timeout: Any = UNSET) -> str:
        """Listen for speech. Returns transcript, or '[TIMEOUT]' if nothing heard.

        :param timeout: the **overall** budget for the call, covering detection,
            transcription and any retry the backend makes internally.
        :param silence_timeout: end the call early after this many seconds of
            captured non-speech, without waiting out ``timeout``. Omit it for
            the backend's own default; pass ``None`` to disable it for this turn.

            It exists because a backend that retries internally does so
            *silently* — it re-records someone who has already answered and has
            no way to know anything went wrong. Only the caller can re-prompt
            out loud, so this is how it gets control back.

            Optional, and not every backend has one. It is declared on
            ``ListenerBackend`` all the same, and a backend that cannot
            honour it **ignores it**, so an application can pass it
            unconditionally without knowing which backend the robot holds.
            A backend that ignores it waits out the full ``timeout``, and
            says so once in the log.
        """
        pass

    @abstractmethod
    def stop(self) -> None:
        """Immediately interrupt any ongoing speech. Called on shutdown."""
        pass

    @abstractmethod
    def play_sound(self, wav_data: bytes) -> None:
        """Play raw WAV audio. Blocks until playback completes."""
        pass
