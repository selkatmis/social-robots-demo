import time,concurrent.futures
class TaskSynchronizer:
	def __init__(self,max_workers:int=5):self.executor=concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
	def _run_task(self,task):A,B=task;time.sleep(A);return B()
	def sync(self,tasks)->list:
		B=[self.executor.submit(self._run_task,A)for A in tasks];A=[]
		for C in concurrent.futures.as_completed(B):
			try:A.append(C.result())
			except Exception as D:print(f"[sync] task error (ignored): {D}")
		return A