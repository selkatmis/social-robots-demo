from abc import ABC, abstractmethod
from typing import List, Dict, Optional


class LanguageBackend(ABC):
    """Abstract interface for LLM backends."""

    @abstractmethod
    def send_message(self, message: str) -> str:
        pass

    @abstractmethod
    def reset_conversation(self, restore_to: Optional[List[Dict]] = None) -> None:
        pass

    @abstractmethod
    def get_conversation_history(self) -> List[Dict]:
        pass
