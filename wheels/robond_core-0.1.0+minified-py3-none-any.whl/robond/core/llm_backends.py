_J='assistant'
_I='Hmm, let me think.'
_H=True
_G='user'
_F='error'
_E='system'
_D='content'
_C='llm'
_B=None
_A='role'
import os,re,time
from typing import List,Dict,Optional
from openai import OpenAI
from robond.core.llm_backend import LanguageBackend
try:from langchain_core.messages import SystemMessage,HumanMessage,AIMessage,BaseMessage;from langchain_core.language_models.chat_models import BaseChatModel;_LANGCHAIN_AVAILABLE=_H
except ImportError:_LANGCHAIN_AVAILABLE=False
try:from dev_logger import dev_log
except ImportError:
	def dev_log(cat,msg):0
NEBULA_BASE_URL='https://nebula.cs.vu.nl/litellm'
_REASONING_STARTERS='we need to','we should','we can ','we have ','i need to','i should','i will ',"i'll ","i'm ",'i am ','let me',"let's think",'the user','the assistant','okay, ','ok, ','alright, ','provide a','provide the','provide short','ensure no','ensure that','ensure the','should be ','already used','note:','note that','here is the',"here's the",'must be ','make sure','this is a ','this would','this should','keep it ','use only','do not ',"don't "
def _strip_reasoning_leak(reply:str)->str:
	G='\n\n';B=reply
	if not B:return B
	B=re.sub('<think>.*?</think>\\s*','',B,flags=re.DOTALL|re.IGNORECASE);D=[]
	for E in B.split('\n'):
		F=E.strip().lower()
		if F and any(F.startswith(A)for A in _REASONING_STARTERS):continue
		D.append(E)
	C='\n'.join(D).strip()
	if not C:return''
	A=[A.strip()for A in C.split(G)if A.strip()]
	if len(A)>1:
		while A and A[0].lower().startswith(_REASONING_STARTERS):A.pop(0)
		C=G.join(A).strip()if A else''
	return C
def _is_garbage_reply(reply:str)->bool:
	A=reply
	if not A or not A.strip():return _H
	if re.search('\\.{2,}\\s+\\.{2,}',A):return _H
	if re.search(';\\s{2,}\\.',A):return _H
	return False
_MAX_CONTEXT_MSGS=40
SURF_BASE_URL='https://robotbondllmtes.robot-bonding-v.src.surf-hosted.nl'
class SURFBackend(LanguageBackend):
	def __init__(self,api_key:Optional[str]=_B,model:str='mistral-small-24b',system_prompt:str='',temperature:float=.3,max_tokens:int=100,fallback_phrase:str=_I):
		A=system_prompt;self.api_key=api_key or os.getenv('SURF_API_KEY')
		if not self.api_key:raise ValueError('SURF API key required. Set SURF_API_KEY environment variable.')
		self.client=OpenAI(api_key=self.api_key,base_url=SURF_BASE_URL);self.model=model;self.temperature=temperature;self.max_tokens=max_tokens;self._fallback_phrase=fallback_phrase;self.messages=[]
		if A:self.messages.append({_A:_E,_D:A})
	def send_message(self,message:str)->str:
		C=message;self.messages.append({_A:_G,_D:C});dev_log(_C,f"GPT ← prompt ({len(self.messages)} msgs in ctx): {C[:200]}");E=time.time()
		for A in range(3):
			try:
				F=self.client.chat.completions.create(model=self.model,messages=self.messages,temperature=self.temperature,max_tokens=self.max_tokens);B=(F.choices[0].message.content or'').strip();G=int((time.time()-E)*1000)
				if B:self.messages.append({_A:_J,_D:B});dev_log(_C,f"GPT → reply ({G}ms, attempt {A+1}): {B}");return B
				print(f"GPT returned empty response (attempt {A+1}/3), retrying...");dev_log(_C,f"GPT → EMPTY response (attempt {A+1}/{3})")
			except Exception as D:print(f"GPT error (attempt {A+1}/3): {D}");dev_log(_F,f"GPT exception (attempt {A+1}): {D}")
		self.messages.pop();dev_log(_F,f"GPT ALL 3 ATTEMPTS FAILED → returning fallback: '{self._fallback_phrase}'");return self._fallback_phrase
	def reset_conversation(self,restore_to:Optional[List[Dict]]=_B)->_B:
		A=restore_to
		if A is not _B:self.messages=list(A)
		else:self.messages=[A for A in self.messages if A[_A]==_E]
	def get_conversation_history(self)->List[Dict]:return self.messages.copy()
class GPTBackend(LanguageBackend):
	def __init__(self,api_key:Optional[str]=_B,model:str='gpt-4',system_prompt:str='',temperature:float=.3,max_tokens:int=100,fallback_phrase:str=_I):
		A=system_prompt;self.api_key=api_key or os.getenv('OPENAI_API_KEY')
		if not self.api_key:raise ValueError('OpenAI API key required. Set OPENAI_API_KEY environment variable.')
		self.client=OpenAI(api_key=self.api_key);self.model=model;self.temperature=temperature;self.max_tokens=max_tokens;self._fallback_phrase=fallback_phrase;self.messages=[]
		if A:self.messages.append({_A:_E,_D:A})
	def send_message(self,message:str)->str:
		C=message;self.messages.append({_A:_G,_D:C});dev_log(_C,f"GPT ← prompt ({len(self.messages)} msgs in ctx): {C[:200]}");E=time.time()
		for A in range(3):
			try:
				F=self.client.chat.completions.create(model=self.model,messages=self.messages,temperature=self.temperature,max_tokens=self.max_tokens);B=(F.choices[0].message.content or'').strip();G=int((time.time()-E)*1000)
				if B:self.messages.append({_A:_J,_D:B});dev_log(_C,f"GPT → reply ({G}ms, attempt {A+1}): {B}");return B
				print(f"GPT returned empty response (attempt {A+1}/3), retrying...");dev_log(_C,f"GPT → EMPTY response (attempt {A+1}/{3})")
			except Exception as D:print(f"GPT error (attempt {A+1}/3): {D}");dev_log(_F,f"GPT exception (attempt {A+1}): {D}")
		self.messages.pop();dev_log(_F,f"GPT ALL 3 ATTEMPTS FAILED → returning fallback: '{self._fallback_phrase}'");return self._fallback_phrase
	def reset_conversation(self,restore_to:Optional[List[Dict]]=_B)->_B:
		A=restore_to
		if A is not _B:self.messages=list(A)
		else:self.messages=[A for A in self.messages if A[_A]==_E]
	def get_conversation_history(self)->List[Dict]:return self.messages.copy()
class NebulaBackend(LanguageBackend):
	def __init__(self,api_key:Optional[str]=_B,model:str='FAST.gpt-oss:120b',system_prompt:str='',temperature:float=.3,max_tokens:int=350,fallback_phrase:str=_I):
		A=system_prompt;B=api_key or os.getenv('NEBULA_API_KEY')
		if not B:raise ValueError('Nebula API key required. Set NEBULA_API_KEY environment variable.')
		self.client=OpenAI(api_key=B,base_url=NEBULA_BASE_URL);self.model=model;self.temperature=temperature;self.max_tokens=max_tokens;self._fallback_phrase=fallback_phrase;self.messages=[]
		if A:self.messages.append({_A:_E,_D:A})
	def _trim_context(self)->_B:
		C=[A for A in self.messages if A[_A]==_E];A=[A for A in self.messages if A[_A]!=_E]
		if len(A)>_MAX_CONTEXT_MSGS:B=len(A)-_MAX_CONTEXT_MSGS;B+=B%2;A=A[B:];dev_log(_C,f"Context trimmed: dropped {B} old msgs → context now {len(C)+len(A)} msgs")
		self.messages=C+A
	def send_message(self,message:str)->str:
		D=message;self._trim_context();self.messages.append({_A:_G,_D:D});dev_log(_C,f"Nebula ← prompt ({len(self.messages)} msgs in ctx): {D[:200]}");H=time.time()
		for B in range(3):
			try:
				I=self.client.chat.completions.create(model=self.model,messages=self.messages,temperature=self.temperature,max_tokens=self.max_tokens);C=(I.choices[0].message.content or'').strip();A=_strip_reasoning_leak(C);J=int((time.time()-H)*1000)
				if A and not _is_garbage_reply(A):
					self.messages.append({_A:_J,_D:A})
					if A!=C:dev_log(_C,f"Nebula → reasoning leak stripped ({len(C)-len(A)} chars removed)")
					dev_log(_C,f"Nebula → reply ({J}ms, attempt {B+1}): {A}");return A
				E='GARBAGE'if A and _is_garbage_reply(A)else'EMPTY';print(f"Nebula returned {E.lower()} response (attempt {B+1}/3), retrying...");dev_log(_C,f"Nebula → {E} response (attempt {B+1}/3)")
			except Exception as F:print(f"Nebula error (attempt {B+1}/3): {F}");dev_log(_F,f"Nebula exception (attempt {B+1}): {F}")
			if B<2:G=2*(B+1);print(f"Nebula retry in {G}s...");time.sleep(G)
		self.messages.pop();dev_log(_F,f"Nebula ALL 3 ATTEMPTS FAILED → returning fallback: '{self._fallback_phrase}'");return self._fallback_phrase
	def reset_conversation(self,restore_to:Optional[List[Dict]]=_B)->_B:
		A=restore_to
		if A is not _B:self.messages=list(A)
		else:self.messages=[A for A in self.messages if A[_A]==_E]
	def get_conversation_history(self)->List[Dict]:return self.messages.copy()
def _to_lc_messages(messages:List[Dict])->'List[BaseMessage]':
	A=[]
	for C in messages:
		D,B=C[_A],C[_D]
		if D==_E:A.append(SystemMessage(content=B))
		elif D==_G:A.append(HumanMessage(content=B))
		else:A.append(AIMessage(content=B))
	return A
class LangChainBackend(LanguageBackend):
	def __init__(self,model:'BaseChatModel',system_prompt:str='',fallback_phrase:str=_I):
		A=system_prompt
		if not _LANGCHAIN_AVAILABLE:raise ImportError('LangChain is not installed. Run: pip install "robond.core[langchain]" or pip install langchain-core langchain-ollama langchain-community')
		self._model=model;self._fallback_phrase=fallback_phrase;(self.messages):List[Dict]=[]
		if A:self.messages.append({_A:_E,_D:A})
	def send_message(self,message:str)->str:
		C=message;self.messages.append({_A:_G,_D:C});dev_log(_C,f"LangChain ← prompt ({len(self.messages)} msgs in ctx): {C[:200]}");E=time.time()
		for A in range(3):
			try:
				F=_to_lc_messages(self.messages);G=self._model.invoke(F);B=(G.content or'').strip();H=int((time.time()-E)*1000)
				if B:self.messages.append({_A:_J,_D:B});dev_log(_C,f"LangChain → reply ({H}ms, attempt {A+1}): {B}");return B
				print(f"LangChain returned empty response (attempt {A+1}/3), retrying...");dev_log(_C,f"LangChain → EMPTY response (attempt {A+1}/3)")
			except Exception as D:print(f"LangChain error (attempt {A+1}/3): {D}");dev_log(_F,f"LangChain exception (attempt {A+1}): {D}")
		self.messages.pop();dev_log(_F,f"LangChain ALL 3 ATTEMPTS FAILED → returning fallback: '{self._fallback_phrase}'");return self._fallback_phrase
	def reset_conversation(self,restore_to:Optional[List[Dict]]=_B)->_B:
		A=restore_to
		if A is not _B:self.messages=list(A)
		else:self.messages=[A for A in self.messages if A[_A]==_E]
	def get_conversation_history(self)->List[Dict]:return self.messages.copy()