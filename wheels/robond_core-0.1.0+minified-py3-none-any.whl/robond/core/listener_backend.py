import logging
from abc import ABC, abstractmethod
from typing import Any

logger = logging.getLogger(__name__)


class _Unset:
    """The type of :data:`UNSET`. Exists only so it reprs readably in a
    traceback and cannot be confused with ``None``."""

    __slots__ = ()

    def __repr__(self) -> str:            # pragma: no cover - debugging aid
        return "UNSET"


UNSET = _Unset()
"""Marker for "this argument was not given", where ``None`` already means
something else.

``silence_timeout`` needs three states, not two: *use whatever default the
backend was built with*, *turn it off for this one turn*, and *use this value*.
``None`` is spoken for by the middle one — it is how a caller says "no silence
budget" — so the first needs a marker of its own. Without it, a backend built
with a 4 s default could never be asked for an open question ("vertel eens over
je dag") with no budget at all.
"""

_warned_backends = set()
"""Class names that have already logged the ignored-budget warning."""


class ListenerBackend(ABC):
    """Abstract interface for speech/text input. Injected into robot implementations.

    ``listen`` takes two budgets. ``timeout`` is the overall one and every
    backend honours it. ``silence_timeout`` is the newer one and **not every
    backend can honour it** — it needs speech/non-speech detection the caller
    owns, which the four legacy ASR backends do not expose and which
    ``VOSKListenerBackend`` hands to a ROS service that has no silence concept.

    It is declared here anyway, so that an application can pass it
    unconditionally without knowing which backend the robot happens to hold. A
    backend that cannot honour it calls :meth:`_ignore_silence_timeout` and
    carries on with the overall timeout alone.
    """

    @abstractmethod
    def listen(self, timeout: int = 10, silence_timeout: Any = UNSET) -> str:
        """Listen for input. Returns transcript, or '[TIMEOUT]' if nothing received.

        :param timeout: the **overall** budget for the call, covering detection,
            transcription and any retry the backend makes internally.
        :param silence_timeout: end the call early after this many seconds of
            captured non-speech, without waiting out ``timeout``. Omit it for
            the backend's own default; pass ``None`` to disable it for this
            turn. Implementations that have no silence budget must accept it
            and pass it to :meth:`_ignore_silence_timeout`.
        """
        pass

    def _ignore_silence_timeout(self, silence_timeout: Any) -> None:
        """Accept a ``silence_timeout`` this backend cannot honour, and say so.

        Ignoring beats refusing: one application drives every robot in this
        repo, and a ``TypeError`` from whichever backend happens to be plugged
        in would take the session down over a knob that is only ever an
        optimisation. The cost is that the budget can quietly do nothing, so it
        is not entirely quiet.

        **One WARNING per backend class, not per turn.** Per turn it would be a
        line every few seconds for a whole session, which is how a real warning
        gets tuned out. Once is enough to answer "why is my silence budget doing
        nothing", which is the only question it exists for.
        """
        if silence_timeout is UNSET or silence_timeout is None:
            return
        name = type(self).__name__
        if name in _warned_backends:
            return
        _warned_backends.add(name)
        logger.warning(
            "%s has no silence_timeout, so the %r passed is being ignored — "
            "this backend waits out the full timeout. The budget is an "
            "addition of robond.asr.dualpath.DualPathListenerBackend; switch "
            "to it if you need turns to end early on silence.",
            name, silence_timeout)

    def start(self) -> None:
        """Optional lifecycle hook — called when the robot starts (e.g. for streaming)."""
        pass

    def stop(self) -> None:
        """Optional lifecycle hook — called when the robot stops (e.g. streaming cleanup)."""
        pass
