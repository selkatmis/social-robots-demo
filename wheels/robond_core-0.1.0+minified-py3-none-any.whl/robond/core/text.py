import re
def clean_for_speech(text:str,lang:str='en-US')->str:
	S=' divided by ';R=' = ';Q=' gedeeld door ';P=' / ';O=' X ';N=' x ';M=' * ';L=' plus ';K=' + ';J=' - ';I='tens';H='fives';G='twos';F='\\1';D='kjoetie';C=' times ';B=' keer ';A=text;A=re.sub('\\*{1,2}(.+?)\\*{1,2}',F,A);A=re.sub('_{1,2}(.+?)_{1,2}',F,A);T={"2's":G,'2s':G,"5's":H,'5s':H,"10's":I,'10s':I}
	for(U,V)in T.items():A=A.replace(U,V)
	if lang.startswith('nl'):E=[(J,' min '),(K,L),(M,B),(N,B),(O,B),(P,Q),(R,' is '),('÷',Q),('×',B),('≠',' is niet gelijk aan '),('≤',' kleiner dan of gelijk aan '),('≥',' groter dan of gelijk aan ')]
	else:E=[(J,' minus '),(K,L),(M,C),(N,C),(O,C),(P,S),(R,' equals '),('÷',S),('×',C),('≠',' does not equal '),('≤',' less than or equal to '),('≥',' greater than or equal to ')]
	for(W,X)in E:A=A.replace(W,X)
	if lang.startswith('nl'):A=re.sub('\\bQT\\b',D,A);A=re.sub('\\bKjoetie\\b',D,A,flags=re.IGNORECASE);A=re.sub('\\bcutie\\b',D,A,flags=re.IGNORECASE)
	return A