_I='BROW_UP_RIGHT'
_H='SMILE_CLOSED'
_G='SMILE_OPEN'
_F='Smile'
_E='BigSmile'
_D=False
_C=True
_B=1.
_A=None
import array,asyncio,base64,io,logging,threading,wave
from typing import Any,List,Optional
from robond.core.robot_interface import RobotInterface,Gesture,Expression
from robond.core.listener_backend import UNSET,ListenerBackend
logger=logging.getLogger(__name__)
try:from furhat_realtime_api import AsyncFurhatClient;FURHAT_AVAILABLE=_C
except ImportError:FURHAT_AVAILABLE=_D;AsyncFurhatClient=_A
_FURHAT_EXPRESSION={Expression.HAPPY:{_G:_B},Expression.SMILE:{_H:_B},Expression.EXCITED:{_G:_B,'BROW_UP_LEFT':_B,_I:_B},Expression.NEUTRAL:{},Expression.SAD:{'EXPR_SAD':_B},Expression.ANGRY:{'EXPR_ANGER':_B},Expression.SURPRISED:{'SURPRISE':_B},Expression.CONFUSED:{'BROW_DOWN_LEFT':_B,_I:_B},Expression.SHY:{'LOOK_DOWN':_B,_H:.4}}
_FURHAT_EXPRESSION_GESTURE={Expression.SMILE:_E,Expression.HAPPY:_E,Expression.EXCITED:_E,Expression.SAD:'ExpressSad',Expression.ANGRY:'ExpressAnger',Expression.SURPRISED:'Surprise',Expression.CONFUSED:'BrowFrown'}
_FURHAT_GESTURE={Gesture.WAVE:_A,Gesture.NOD:'Nod',Gesture.CLAP:_A,Gesture.HAPPY:_F,Gesture.STRETCH:_A,Gesture.CHEER:_A,Gesture.GREET:_F,Gesture.FAREWELL:_F,Gesture.FAREWELL_WARM:_A,Gesture.POINT_FRONT:_A}
def _stereo_to_mono_16bit(frames:bytes)->bytes:A=array.array('h');A.frombytes(frames);B=array.array('h',((A[B]+A[B+1])//2 for B in range(0,len(A)-1,2)));return B.tobytes()
class FurhatRobotInterface(RobotInterface):
	def __init__(self,host:str='127.0.0.1',auth_key:Optional[str]=_A,listener:Optional[ListenerBackend]=_A,tts_lang:str='en-US',connect_timeout:float=15.):
		B=tts_lang;A=listener
		if not FURHAT_AVAILABLE:raise ImportError('furhat-realtime-api not available. Run `pip install furhat-realtime-api`.')
		if A is _A:raise ValueError('FurhatRobotInterface requires a `listener` ')
		self._listener=A;self._tts_lang=B;self._is_speaking=threading.Event();self._loop=asyncio.new_event_loop();self._loop_thread=threading.Thread(target=self._loop.run_forever,daemon=_C);self._loop_thread.start();self._client=AsyncFurhatClient(host,auth_key)
		try:self._run(self._client.connect(),timeout=connect_timeout)
		except Exception:self._loop.call_soon_threadsafe(self._loop.stop);raise
		try:self._run(self._client.request_voice_config(language=B),timeout=10)
		except Exception as C:logger.warning('Could not set initial voice language (continuing anyway): %s',C)
		self._listener.start();logger.info('Connected to Furhat at %s',host)
	def _run(self,coro,timeout:float=15.):return asyncio.run_coroutine_threadsafe(coro,self._loop).result(timeout=timeout)
	def say(self,text:str)->_A:
		self._is_speaking.set()
		try:self._run(self._client.request_speak_text(text,wait=_C,abort=_C),timeout=45)
		finally:self._is_speaking.clear()
	def set_language(self,lang:str)->_A:
		A=lang;self._tts_lang=A
		try:self._run(self._client.request_voice_config(language=A),timeout=10)
		except Exception as B:logger.warning('Could not set voice language to %s: %s',A,B)
		logger.debug('Furhat voice language set to %s',A)
	def is_speaking(self)->bool:return self._is_speaking.is_set()
	def stop(self)->_A:
		try:self._run(self._client.request_speak_stop(),timeout=5)
		except Exception as A:logger.warning('Furhat request_speak_stop failed: %s',A)
		self._is_speaking.clear();self._listener.stop()
	def listen(self,timeout:int=10,silence_timeout:Any=UNSET)->str:return self._listener.listen(timeout,silence_timeout=silence_timeout)
	async def _play_gesture_coro(self,gesture:Gesture,speed:float=.5):
		B=speed;A=gesture;C=_FURHAT_GESTURE.get(A)
		if C is _A:logger.warning('Gesture %s has no Furhat mapping',A);return
		D=max(.3,_B/B)if B>0 else _B;await self._client.request_gesture_start(C,duration=1,wait=_D)
	def play_gesture(self,gesture:Gesture,speed:float=.5)->_A:self._run(self._play_gesture_coro(gesture,speed=speed),timeout=10)
	async def _set_expression_coro(self,expression:Expression,reset:bool=_C):
		A=expression;B=_FURHAT_EXPRESSION_GESTURE.get(A)
		if B is not _A:await self._client.request_gesture_start(B,intensity=1,duration=1,wait=_D);return
		C=_FURHAT_EXPRESSION.get(A)
		if C is _A:logger.warning('Expression %s has no Furhat mapping',A);return
		if reset:await self._client.request_face_reset()
		await self._client.request_face_params(C)
	def set_expression(self,expression:Expression)->_A:self._run(self._set_expression_coro(expression),timeout=10)
	async def _speak_coro(self,text:str,abort:bool=_C):await self._client.request_speak_text(text,wait=_C,abort=abort)
	def say(self,text:str)->_A:
		self._is_speaking.set()
		try:self._run(self._speak_coro(text),timeout=45)
		finally:self._is_speaking.clear()
	def coordinated_action(self,text:str,gesture:Optional[Gesture]=_A,expression:Optional[Expression]=_A,speed:float=.5)->_A:
		B=expression;A=gesture;C=[f"expr={B.name}"if B else _A,f"gesture={A.name}"if A else _A];D=' | '.join(A for A in C if A);print(f"[Furhat + {D}] {text}")
		async def E():
			C=[]
			if A:C.append(self._play_gesture_coro(A,speed=speed))
			if B:C.append(self._set_expression_coro(B,reset=not A))
			if C:await asyncio.gather(*C)
			await self._speak_coro(text,abort=not A)
		self._is_speaking.set()
		try:self._run(E(),timeout=45)
		finally:self._is_speaking.clear()
	def get_available_gestures(self)->List[Gesture]:return[Gesture.NOD]+list(_FURHAT_GESTURE.keys())
	def get_available_expressions(self)->List[Expression]:return list(_FURHAT_EXPRESSION.keys())+[Expression.NEUTRAL,Expression.THINKING]
	def play_sound(self,wav_data:bytes)->_A:self._run(self._play_sound_async(wav_data),timeout=30)
	async def _play_sound_async(self,wav_data:bytes)->_A:
		with io.BytesIO(wav_data)as G,wave.open(G,'rb')as A:C=A.getnchannels();D=A.getsampwidth();H=A.getframerate();B=A.readframes(A.getnframes())
		if D!=2:raise ValueError(f"play_sound requires 16-bit PCM WAV audio, got {D*8}-bit. Convert the file before calling play_sound().")
		if C==2:B=_stereo_to_mono_16bit(B)
		elif C!=1:raise ValueError(f"play_sound requires mono or stereo audio, got {C} channels.")
		await self._client.request_speak_audio_start(sample_rate=H,lipsync=_D)
		try:
			E=4096
			for F in range(0,len(B),E):I=B[F:F+E];await self._client.request_speak_audio_data(base64.b64encode(I).decode('ascii'))
		finally:await self._client.request_speak_audio_end()
	def shutdown(self)->_A:
		try:self._run(self._client.disconnect(),timeout=5)
		except Exception:logger.exception('Error disconnecting from Furhat')
		self._loop.call_soon_threadsafe(self._loop.stop)