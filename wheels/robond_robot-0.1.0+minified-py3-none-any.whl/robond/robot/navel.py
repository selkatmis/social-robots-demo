_B=False
_A=None
import asyncio,subprocess,tempfile,os,time
from typing import Any,List,Optional
from robond.core.robot_interface import RobotInterface,Gesture,Expression
from robond.core.listener_backend import UNSET,ListenerBackend
try:import navel as navel_sdk
except ImportError:navel_sdk=_A
EXPRESSION_MAP={Expression.HAPPY:(0,1,0,0,0,0),Expression.EXCITED:(0,.8,0,.5,0,.5),Expression.NEUTRAL:(1,0,0,0,0,0),Expression.SAD:(0,0,1,0,0,0),Expression.ANGRY:(0,0,0,0,1,0),Expression.SURPRISED:(0,0,0,1,0,0),Expression.THINKING:(.6,0,.15,.2,.05,0),Expression.SMILE:(0,.5,0,0,0,1),Expression.CONFUSED:(.15,0,.15,.45,.25,0),Expression.SHY:_A}
GESTURE_MAP={Gesture.WAVE:(150,0),Gesture.NOD:(0,0),Gesture.CLAP:(90,90),Gesture.HAPPY:(120,120),Gesture.STRETCH:(170,170),Gesture.CHEER:(160,160),Gesture.GREET:(150,0),Gesture.FAREWELL:(150,0),Gesture.FAREWELL_WARM:(130,90),Gesture.POINT_FRONT:(90,0)}
LANGUAGE_TAG_MAP={'nl-NL':'nl1','en-US':'en1'}
def _run_async(coro):
	A=coro
	try:
		B=asyncio.get_event_loop()
		if B.is_running():
			import concurrent.futures
			with concurrent.futures.ThreadPoolExecutor(max_workers=1)as C:return C.submit(asyncio.run,A).result()
		return B.run_until_complete(A)
	except RuntimeError:return asyncio.run(A)
class NavelRobotInterface(RobotInterface):
	def __init__(self,language:str='en-US',listener:Optional[ListenerBackend]=_A):
		if navel_sdk is _A:raise RuntimeError('navel SDK is not installed. NavelRobotInterface must run on the robot.')
		self._language=_A;self._is_speaking=_B;self._listener=listener
		if self._listener:self._listener.start()
		self.set_language(language)
	def _run(self,coro):return _run_async(coro)
	def _say_async(self,text:str):
		async def A():
			async with navel_sdk.Robot()as A:await A.say(text)
		return A()
	def _expression_async(self,expression:Expression):
		A=EXPRESSION_MAP.get(expression,(1,0,0,0,0,0))
		async def B():
			async with navel_sdk.Robot()as B:B.head_facial_expression(neutral=A[0],happy=A[1],sad=A[2],surprise=A[3],anger=A[4],smile=A[5])
		return B()
	def _gesture_async(self,gesture:Gesture):
		A=GESTURE_MAP.get(gesture,(0,0))
		async def B():
			async with navel_sdk.Robot()as B:await B.rotate_arms(A[0],A[1]);await asyncio.sleep(.8);await B.rotate_arms(0,0)
		return B()
	def _set_language_async(self,lang:str):
		A=LANGUAGE_TAG_MAP.get(lang)
		if A is _A:raise ValueError(f"Unknown language {lang!r}; add it to LANGUAGE_TAG_MAP")
		async def B():
			async with navel_sdk.Robot()as B:await B.say(f"<lang,{A}>")
		return B()
	def _coordinated_async(self,text:str,gesture:Optional[Gesture],expression:Optional[Expression]):
		D=expression;C=gesture;A=EXPRESSION_MAP.get(D,(1,0,0,0,0,0))if D else _A;B=GESTURE_MAP.get(C)if C else _A
		async def E():
			async with navel_sdk.Robot()as C:
				if A:C.head_facial_expression(neutral=A[0],happy=A[1],sad=A[2],surprise=A[3],anger=A[4],smile=A[5])
				if B:C.rotate_arms(B[0],B[1])
				await C.say(text)
				if B:await C.rotate_arms(0,0)
		return E()
	def say(self,text:str)->_A:
		self._is_speaking=True
		try:self._run(self._say_async(text))
		finally:self._is_speaking=_B
	def set_expression(self,expression:Expression)->_A:self._run(self._expression_async(expression))
	def play_gesture(self,gesture:Gesture,speed:float=.5)->_A:self._run(self._gesture_async(gesture))
	def set_language(self,lang:str)->_A:self._run(self._set_language_async(lang));self._language=lang
	def coordinated_action(self,text:str,gesture:Optional[Gesture]=_A,expression:Optional[Expression]=_A,speed:float=.5)->_A:
		self._is_speaking=True
		try:self._run(self._coordinated_async(text,gesture,expression))
		finally:self._is_speaking=_B
	def is_speaking(self)->bool:return self._is_speaking
	def get_available_gestures(self)->List[Gesture]:return list(Gesture)
	def get_available_expressions(self)->List[Expression]:return list(Expression)
	def listen(self,timeout:int=10,silence_timeout:Any=UNSET)->str:
		if self._listener:return self._listener.listen(timeout,silence_timeout=silence_timeout)
		raise RuntimeError('No ListenerBackend injected. When using the proxy, listen() is handled by RemoteRobotInterface on the laptop.')
	def stop(self)->_A:
		self._is_speaking=_B
		if self._listener:self._listener.stop()
	def play_sound(self,wav_data:bytes)->_A:
		with tempfile.NamedTemporaryFile(suffix='.wav',delete=_B)as A:A.write(wav_data);B=A.name
		try:subprocess.run(['aplay',B],check=True)
		except subprocess.CalledProcessError as C:raise RuntimeError(f"aplay failed: {C}")from C
		finally:os.unlink(B)