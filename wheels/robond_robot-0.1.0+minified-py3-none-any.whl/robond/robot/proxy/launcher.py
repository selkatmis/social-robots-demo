def main():from robond.robot.proxy.qt_proxy import main as A;A()
if __name__=='__main__':main()