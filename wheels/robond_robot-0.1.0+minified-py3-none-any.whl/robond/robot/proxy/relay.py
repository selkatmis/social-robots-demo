_B=None
_A=True
import socket,threading
QTPC_HOST='192.168.100.2'
QTPC_PORT=7342
LISTEN_PORT=7342
def _pump(src:socket.socket,dst:socket.socket,done:threading.Event)->_B:
	try:
		while _A:
			A=src.recv(4096)
			if not A:break
			dst.sendall(A)
	except OSError:0
	finally:
		try:dst.shutdown(socket.SHUT_WR)
		except OSError:0
		done.set()
def _relay_connection(client:socket.socket,backend:socket.socket)->_B:
	B=backend;A=client;E=threading.Event();F=threading.Event();C=threading.Thread(target=_pump,args=(A,B,E),daemon=_A);C.start();D=threading.Thread(target=_pump,args=(B,A,F),daemon=_A);D.start();C.join();D.join()
	for G in(A,B):
		try:G.close()
		except OSError:0
def main()->_B:
	A=socket.socket(socket.AF_INET,socket.SOCK_STREAM);A.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);A.bind(('0.0.0.0',LISTEN_PORT));A.listen(5);print(f"qtrp_relay: listening on :{LISTEN_PORT} → {QTPC_HOST}:{QTPC_PORT}")
	while _A:
		B,E=A.accept()
		try:C=socket.create_connection((QTPC_HOST,QTPC_PORT),timeout=5);C.settimeout(_B)
		except OSError as D:print(f"qtrp_relay: cannot reach QTPC ({QTPC_HOST}:{QTPC_PORT}): {D}");B.close();continue
		threading.Thread(target=_relay_connection,args=(B,C),daemon=_A).start()
if __name__=='__main__':main()