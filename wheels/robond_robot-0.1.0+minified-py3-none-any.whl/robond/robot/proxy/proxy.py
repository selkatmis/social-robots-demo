import logging
from flask import Flask,Response,request,jsonify,stream_with_context
from robond.core.robot_interface import RobotInterface,Gesture,Expression
logger=logging.getLogger(__name__)
class RobotProxy:
	def __init__(self,robot:RobotInterface,audio_source):A=robot;self._robot=A;self._audio_source=audio_source;logger.info('RobotProxy ready (robot=%s).',type(A).__name__)
	@property
	def app(self)->Flask:
		G='/behaviour/<path:key>';E='utf-8';F='language';D='POST';C=True;B=None;A=Flask(__name__)
		@A.route('/health')
		def H():A=getattr(self._robot,'_current_language','unknown');return jsonify({'ok':C,F:A})
		@A.route('/text',methods=[D])
		def I():
			D=request.data.decode(E);F=request.headers.get('X-Gesture');G=request.headers.get('X-Expression')
			try:J=float(request.headers.get('X-Speed','0.5'));H=Gesture(F)if F else B;I=Expression(G)if G else B
			except(ValueError,KeyError)as A:logger.warning('POST /text invalid header: %s',A);return Response(status=400)
			try:
				if H or I:self._robot.coordinated_action(D,gesture=H,expression=I,speed=J)
				else:self._robot.say(D)
			except Exception as A:logger.error('POST /text failed: %s',A,exc_info=C);return Response(status=500)
			return Response(status=200)
		@A.route('/sound',methods=[D])
		def J():
			B=request.content_type or''
			if not B.startswith('audio/wav'):return Response(status=400)
			A=request.data
			if not A:return Response(status=400)
			try:self._robot.play_sound(A)
			except Exception as D:logger.error('POST /sound failed: %s',D,exc_info=C);return Response(status=500)
			return Response(status=200)
		@A.route('/web',methods=[D])
		def K():
			A=request.data.decode(E)
			if not A:return Response(status=400)
			D=getattr(self._robot,'show_web_page',B)
			if D is B:logger.warning('POST /web: robot does not support show_web_page');return Response(status=501)
			try:D(A)
			except Exception as F:logger.error('POST /web failed: %s',F,exc_info=C);return Response(status=500)
			return Response(status=200)
		@A.route('/image',methods=[D])
		def L():
			A=request.content_type or''
			if not(A.startswith('image/jpeg')or A.startswith('image/png')):return Response(status=400)
			D=request.data
			if not D:return Response(status=400)
			E=getattr(self._robot,'set_image',B)
			if E is B:logger.warning('POST /image: robot does not support set_image');return Response(status=501)
			try:E(D,content_type=A)
			except Exception as F:logger.error('POST /image failed: %s',F,exc_info=C);return Response(status=500)
			return Response(status=200)
		@A.route(G,methods=['PUT'])
		def M(key):
			B=key;A,G,D=B.partition(':')
			try:
				if A=='gesture':self._robot.play_gesture(Gesture(D))
				elif A=='expression':self._robot.set_expression(Expression(D))
				elif A==F:self._robot.set_language(D)
				else:logger.warning('Unknown behaviour kind: %s',A);return Response(status=400)
			except(ValueError,KeyError)as E:logger.warning('Invalid behaviour value %r: %s',B,E);return Response(status=400)
			except Exception as E:logger.error('behaviour_start %r failed: %s',B,E,exc_info=C);return Response(status=500)
			return Response(status=200)
		@A.route(G,methods=['DELETE'])
		def N(key):
			A,B,B=key.partition(':')
			if A=='speech':self._robot.stop()
			logger.debug('DELETE /behaviour/%s (no-op for kind=%s)',key,A);return Response(status=200)
		@A.route('/behaviours')
		def O():return jsonify({'gestures':[A.value for A in self._robot.get_available_gestures()],'expressions':[A.value for A in self._robot.get_available_expressions()]})
		@A.route('/configure',methods=[D])
		def P():
			E='mic_gain';D='volume';A=request.get_json(force=C)
			if not isinstance(A,dict):return Response(status=400)
			F=getattr(self._robot,'_set_system_volume',B);G=getattr(self._robot,'_set_mic_gain',B)
			if D in A:
				if not isinstance(A[D],int):return Response(status=400)
				if F:F(A[D])
				else:logger.warning('POST /configure: robot does not support volume control')
			if E in A:
				if not isinstance(A[E],int):return Response(status=400)
				if G:G(A[E])
				else:logger.warning('POST /configure: robot does not support mic gain control')
			return Response(status=200)
		@A.route('/audio')
		def Q():
			A=self._audio_source;B=f"audio/L16; rate={A.rate}; channels={A.channels}; frame_size={A.frame_size}"
			def C():
				with A as B:
					for C in B.audio:yield C.tobytes()
			return Response(stream_with_context(C()),mimetype=B)
		@A.after_request
		def R(response):A=response;A.headers['Cache-Control']='no-cache, no-store, must-revalidate';A.headers['Pragma']='no-cache';A.headers['Expires']='0';return A
		return A