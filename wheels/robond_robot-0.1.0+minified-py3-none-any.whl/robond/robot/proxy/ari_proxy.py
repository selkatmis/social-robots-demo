import argparse,logging,os,signal
from robond.robot.ari import ARIRobotInterface
from robond.robot.proxy.proxy import RobotProxy
logging.basicConfig(level=logging.INFO)
logger=logging.getLogger(__name__)
class _NoAudioSource:
	rate=16000;channels=1;frame_size=480
	def __enter__(self):return self
	def __exit__(self,*A):0
	@property
	def audio(self):return iter([])
def main():
	B=argparse.ArgumentParser(description='ARI HTTP proxy');B.add_argument('--port',type=int,default=7342);B.add_argument('--language',type=str,default='en_US');B.add_argument('--host',type=str,default='0.0.0.0');B.add_argument('--status-page',type=str,default=None,help="ROS name of a page already published via the Touchscreen Manager -- if set, switches ARI's tablet to it on startup");A=B.parse_args();logger.info('Starting ARI proxy on %s:%d (language=%s)',A.host,A.port,A.language);C=ARIRobotInterface(node_name='ari_proxy_node',language=A.language)
	if A.status_page:C.show_web_page(A.status_page)
	E=RobotProxy(robot=C,audio_source=_NoAudioSource())
	def D(reason:str)->None:
		A=reason;logger.info('Shutting down: %s',A)
		try:import rospy;rospy.signal_shutdown(A)
		except Exception:0
		os._exit(0)
	signal.signal(signal.SIGTERM,lambda _s,_f:D('SIGTERM'));signal.signal(signal.SIGINT,lambda _s,_f:D('SIGINT'));E.app.run(host=A.host,port=A.port)
if __name__=='__main__':main()