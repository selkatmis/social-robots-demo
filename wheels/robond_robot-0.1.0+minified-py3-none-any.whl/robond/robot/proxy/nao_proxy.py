from __future__ import print_function
_H='127.0.0.1'
_G='English'
_F='System/animations/Stand/Gestures/Hey_1'
_E='0.0.0.0'
_D=False
_C='en-US'
_B=True
_A=None
import argparse,logging,os,tempfile,threading,time
try:import Queue as queue
except ImportError:import queue
from flask import Flask,Response,request,jsonify,stream_with_context
from naoqi import ALProxy,ALModule,ALBroker
logging.basicConfig(level=logging.INFO)
logger=logging.getLogger('nao_onboard_server')
EXPRESSION_LEDS={'happy':65280,'excited':16744448,'neutral':16777215,'sad':25855,'angry':16711680,'surprised':65280,'thinking':8388863,'smile':16249610,'confused':16753920,'shy':16227500}
GESTURE_BEHAVIOURS={'wave':_F,'nod':'System/animations/Stand/Gestures/Yes_2','clap':'System/animations/Stand/Gestures/Applause_1','happy':'System/animations/Stand/Gestures/Enthusiastic_4','stretch':'System/animations/Stand/BodyTalk/Stretch_1','cheer':'System/animations/Stand/Gestures/Enthusiastic_5','greet':_F,'farewell':'System/animations/Stand/Gestures/Hey_3','farewell_warm':'System/animations/Stand/Gestures/Hey_4','point_front':'System/animations/Stand/Gestures/You_1'}
LANGUAGE_MAP={_C:_G,'en-GB':_G,'fr-FR':'French','es-ES':'Spanish','de-DE':'German','it-IT':'Italian','nl-NL':'Dutch','ja-JP':'Japanese','zh-CN':'Chinese','ko-KR':'Korean','pt-BR':'Brazilian','pt-PT':'Portuguese','ru-RU':'Russian','pl-PL':'Polish','tr-TR':'Turkish','ar-SA':'Arabic'}
class MicModule(ALModule):
	def __init__(self,name,rate=16000,channel=3):ALModule.__init__(self,name);self._audio_device=ALProxy('ALAudioDevice');self._rate=rate;self._channel=channel;self._queue=queue.Queue();self._subscribed=_D
	def start(self):self._audio_device.setClientPreferences(self.getName(),self._rate,3,0);self._audio_device.subscribe(self.getName());self._subscribed=_B
	def stop(self):
		if self._subscribed:
			try:self._audio_device.unsubscribe(self.getName())
			except Exception as A:logger.warning('mic unsubscribe failed: %s',A)
			self._subscribed=_D
	def processRemote(self,nbOfChannels,nbrOfSamplesByChannel,timeStamp,inputBuffer):
		if not self._subscribed:return
		try:A=bytes(bytearray(inputBuffer));self._queue.put(A)
		except Exception as B:logger.warning('processRemote failed: %s',B)
	def frames(self):
		while self._subscribed:
			try:yield self._queue.get(timeout=1.)
			except queue.Empty:continue
class NaoOnboardServer:
	def __init__(self,nao_host=_H,nao_port=9559,language=_C,mic_rate=16000,sound_tmp_dir='/tmp'):
		B=nao_port;A=nao_host;self._nao_host=A;self._nao_port=B;self._sound_tmp_dir=sound_tmp_dir;self._mic_rate=mic_rate;self._tts=ALProxy('ALTextToSpeech',A,B);self._motion=ALProxy('ALMotion',A,B);self._posture=ALProxy('ALRobotPosture',A,B);self._behavior=ALProxy('ALBehaviorManager',A,B);self._leds=ALProxy('ALLeds',A,B);self._audio_player=ALProxy('ALAudioPlayer',A,B)
		try:self._life=ALProxy('ALAutonomousLife',A,B);self._life.setState('disabled')
		except Exception as C:logger.warning('ALAutonomousLife unavailable: %s',C)
		try:self._motion.wakeUp();self._posture.goToPosture('Stand',.6)
		except Exception as C:logger.warning('wakeUp/goToPosture failed: %s',C)
		for D in('Arms','Legs'):
			try:self._motion.setBreathEnabled(D,_B)
			except Exception as C:logger.warning('breathing on %s failed: %s',D,C)
		try:self._awareness=ALProxy('ALBasicAwareness',A,B);self._awareness.setEngagementMode('SemiEngaged');self._awareness.setTrackingMode('Head');self._awareness.startAwareness()
		except Exception as C:self._awareness=_A;logger.warning('ALBasicAwareness unavailable: %s',C)
		self.set_language(language);self._behavior_names_cache=_A;self._mic_broker=_A;self._mic_module=_A;logger.info('NaoOnboardServer ready (naoqi at %s:%d).',A,B)
	def _installed_behaviors(self):
		if self._behavior_names_cache is _A:
			try:self._behavior_names_cache=list(self._behavior.getBehaviorNames())
			except Exception as A:logger.warning('getBehaviorNames failed: %s',A);self._behavior_names_cache=[]
		return self._behavior_names_cache
	def _resolve_behaviour(self,gesture):
		B=gesture;A=GESTURE_BEHAVIOURS.get(B)
		if A is _A:return
		C=self._installed_behaviors()
		if A not in C:logger.warning('Behaviour %s not installed on robot; skipping gesture %s',A,B);return
		return A
	def set_language(self,lang):
		A=LANGUAGE_MAP.get(lang,lang)
		try:self._tts.setLanguage(A)
		except Exception as B:logger.error('setLanguage(%s) failed: %s',A,B)
	def set_expression(self,expression):
		A=expression;B=EXPRESSION_LEDS.get(A,16777215)
		try:self._leds.fadeRGB('FaceLeds',B,.3)
		except Exception as C:logger.error('set_expression(%s) failed: %s',A,C)
	def play_gesture(self,gesture):
		A=self._resolve_behaviour(gesture)
		if A:
			try:self._behavior.runBehavior(A)
			except Exception as B:logger.error('runBehavior(%s) failed: %s',A,B)
	def say(self,text,gesture=_A,expression=_A):
		C=expression;B=gesture
		if C:self.set_expression(C)
		A=self._resolve_behaviour(B)if B else _A
		if A:
			try:self._behavior.post.runBehavior(A)
			except Exception as D:logger.error('post.runBehavior(%s) failed: %s',A,D)
		self._tts.say(text)
	def stop_speech(self):
		try:self._tts.stopAll()
		except Exception as A:logger.warning('stopAll failed: %s',A)
	def play_sound(self,wav_data):
		B,A=tempfile.mkstemp(suffix='.wav',dir=self._sound_tmp_dir)
		try:
			with os.fdopen(B,'wb')as C:C.write(wav_data)
			D=self._audio_player.playFile(A)
			while _B:
				try:
					if not self._audio_player.isPlaying(D):break
				except Exception:break
				time.sleep(.1)
		finally:
			try:os.unlink(A)
			except OSError:0
	def start_mic(self):
		if self._mic_module is not _A:return self._mic_module
		self._mic_broker=ALBroker('nao_onboard_mic_broker',_E,0,self._nao_host,self._nao_port);self._mic_module=MicModule('nao_onboard_mic_module',rate=self._mic_rate);self._mic_module.start();return self._mic_module
	def stop_mic(self):
		if self._mic_module is not _A:self._mic_module.stop();self._mic_module=_A
		if self._mic_broker is not _A:
			try:self._mic_broker.shutdown()
			except Exception as A:logger.warning('mic broker shutdown failed: %s',A)
			self._mic_broker=_A
	def stop_idle_behaviour(self):
		if self._awareness is not _A:
			try:self._awareness.stopAwareness()
			except Exception as A:logger.warning('stopAwareness failed: %s',A)
		for B in('Arms','Legs'):
			try:self._motion.setBreathEnabled(B,_D)
			except Exception as A:logger.warning('disabling breathing on %s failed: %s',B,A)
	@property
	def app(self):
		C='/behaviour/<path:key>';B='POST';A=Flask(__name__)
		@A.route('/health')
		def D():return jsonify({'ok':_B})
		@A.route('/text',methods=[B])
		def E():
			A=request.data;B=request.headers.get('X-Gesture');C=request.headers.get('X-Expression')
			try:self.say(A,gesture=B,expression=C)
			except Exception as D:logger.error('POST /text failed: %s',D);return Response(status=500)
			return Response(status=200)
		@A.route('/sound',methods=[B])
		def F():
			B=request.content_type or''
			if not B.startswith('audio/wav'):return Response(status=400)
			A=request.data
			if not A:return Response(status=400)
			try:self.play_sound(A)
			except Exception as C:logger.error('POST /sound failed: %s',C);return Response(status=500)
			return Response(status=200)
		@A.route(C,methods=['PUT'])
		def G(key):
			A,D,B=key.partition(':')
			try:
				if A=='gesture':self.play_gesture(B)
				elif A=='expression':self.set_expression(B)
				elif A=='language':self.set_language(B)
				else:return Response(status=400)
			except Exception as C:logger.error('behaviour_start(%s) failed: %s',key,C);return Response(status=500)
			return Response(status=200)
		@A.route(C,methods=['DELETE'])
		def H(key):
			A,B,B=key.partition(':')
			if A=='speech':self.stop_speech()
			return Response(status=200)
		@A.route('/behaviours')
		def I():return jsonify({'gestures':list(GESTURE_BEHAVIOURS.keys()),'expressions':list(EXPRESSION_LEDS.keys())})
		@A.route('/audio')
		def J():
			A=self.start_mic();B='audio/L16; rate=%d; channels=1; frame_size=1024'%self._mic_rate
			def C():
				try:
					for B in A.frames():yield B
				finally:self.stop_mic()
			return Response(stream_with_context(C()),mimetype=B)
		@A.after_request
		def K(response):A=response;A.headers['Cache-Control']='no-cache, no-store, must-revalidate';A.headers['Pragma']='no-cache';A.headers['Expires']='0';return A
		return A
	def run(self,host=_E,port=7342):
		try:self.app.run(host=host,port=port,threaded=_B)
		finally:self.stop_mic();self.stop_idle_behaviour()
def main():A=argparse.ArgumentParser(description='NAO onboard HTTP server (Python 2.7)');A.add_argument('--host',type=str,default=_E,help='Interface for this HTTP server to bind to');A.add_argument('--port',type=int,default=7343,help='Port for this HTTP server to listen on');A.add_argument('--nao-host',type=str,default=_H,help='NAOqi host (default 127.0.0.1, since this runs onboard)');A.add_argument('--nao-port',type=int,default=9559);A.add_argument('--language',type=str,default=_C);A.add_argument('--mic-rate',type=int,default=16000);B=A.parse_args();C=NaoOnboardServer(nao_host=B.nao_host,nao_port=B.nao_port,language=B.language,mic_rate=B.mic_rate);C.run(host=B.host,port=B.port)
if __name__=='__main__':main()