import argparse,logging
from robond.robot.navel import NavelRobotInterface
from robond.robot.proxy.proxy import RobotProxy
logging.basicConfig(level=logging.INFO)
logger=logging.getLogger(__name__)
class _NoAudioSource:
	rate=16000;channels=1;frame_size=480
	def __enter__(self):return self
	def __exit__(self,*A):0
	@property
	def audio(self):return iter([])
def main():B=argparse.ArgumentParser(description='Navel HTTP proxy');B.add_argument('--port',type=int,default=7342);B.add_argument('--language',type=str,default='en-US');B.add_argument('--host',type=str,default='0.0.0.0');A=B.parse_args();logger.info('Starting Navel proxy on %s:%d (language=%s)',A.host,A.port,A.language);C=NavelRobotInterface(language=A.language);D=RobotProxy(robot=C,audio_source=_NoAudioSource());D.app.run(host=A.host,port=A.port)
if __name__=='__main__':main()