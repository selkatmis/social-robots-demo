_D='text/plain'
_C='utf-8'
_B='Content-Type'
_A=None
from typing import Any,List,Optional
import requests
from robond.core.robot_interface import RobotInterface,Gesture,Expression
from robond.core.listener_backend import UNSET,ListenerBackend
class RemoteRobotInterface(RobotInterface):
	def __init__(self,host:str='localhost',port:int=7342,timeout:int=5,listener:Optional[ListenerBackend]=_A):
		self._base=f"http://{host}:{port}";self._timeout=timeout;self._listener=listener;(self._gestures_cache):Optional[List[str]]=_A;(self._expressions_cache):Optional[List[str]]=_A
		try:A=requests.get(f"{self._base}/health",timeout=self._timeout);A.raise_for_status()
		except requests.RequestException as B:raise ConnectionError(f"Cannot connect to robot proxy at {self._base}: {B}")
		if self._listener is not _A:self._listener.start()
	def say(self,text:str)->_A:
		try:requests.post(f"{self._base}/text",data=text.encode(_C),headers={_B:_D},timeout=120)
		except requests.RequestException as A:print(f"[remote] say() failed: {A}")
	def set_expression(self,expression:Expression)->_A:self._put_behaviour(f"expression:{expression.value}")
	def play_gesture(self,gesture:Gesture,speed:float=.5)->_A:self._put_behaviour(f"gesture:{gesture.value}",params={'speed':speed})
	def set_language(self,lang:str)->_A:self._put_behaviour(f"language:{lang}")
	def coordinated_action(self,text:str,gesture:Optional[Gesture]=_A,expression:Optional[Expression]=_A,speed:float=.5)->_A:
		C=expression;B=gesture;A={_B:_D,'X-Speed':str(speed)}
		if B:A['X-Gesture']=B.value
		if C:A['X-Expression']=C.value
		try:requests.post(f"{self._base}/text",data=text.encode(_C),headers=A,timeout=120)
		except requests.RequestException as D:print(f"[remote] coordinated_action() failed: {D}")
	def is_speaking(self)->bool:return False
	def get_available_gestures(self)->List[Gesture]:
		if self._gestures_cache is _A:A=self._fetch_behaviours().get('gestures',[]);self._gestures_cache=[Gesture(A)for A in A if A in Gesture._value2member_map_]
		return self._gestures_cache
	def get_available_expressions(self)->List[Expression]:
		if self._expressions_cache is _A:A=self._fetch_behaviours().get('expressions',[]);self._expressions_cache=[Expression(A)for A in A if A in Expression._value2member_map_]
		return self._expressions_cache
	def listen(self,timeout:int=20,silence_timeout:Any=UNSET)->str:
		if self._listener is _A:raise NotImplementedError(f"{type(self).__name__} has no ListenerBackend — pass one via the listener= constructor argument.")
		return self._listener.listen(timeout,silence_timeout=silence_timeout)
	def play_sound(self,wav_data:bytes)->_A:
		try:requests.post(f"{self._base}/sound",data=wav_data,headers={_B:'audio/wav'},timeout=120)
		except requests.RequestException as A:print(f"[remote] play_sound() failed: {A}")
	def show_web_page(self,page_name:str)->_A:
		try:
			A=requests.post(f"{self._base}/web",data=page_name.encode(_C),headers={_B:_D},timeout=self._timeout)
			if A.status_code==501:print(f"[remote] show_web_page() not supported by this robot")
			else:A.raise_for_status()
		except requests.RequestException as B:print(f"[remote] show_web_page() failed: {B}")
	def set_image(self,image_data:bytes,content_type:str='image/jpeg')->_A:
		try:
			A=requests.post(f"{self._base}/image",data=image_data,headers={_B:content_type},timeout=self._timeout)
			if A.status_code==501:print(f"[remote] set_image() not supported by this robot")
			else:A.raise_for_status()
		except requests.RequestException as B:print(f"[remote] set_image() failed: {B}")
	def stop(self)->_A:
		try:requests.delete(f"{self._base}/behaviour/speech",timeout=self._timeout)
		except requests.RequestException as A:print(f"[remote] stop() failed: {A}")
		if self._listener is not _A:self._listener.stop()
	def _put_behaviour(self,key:str,params:dict=_A)->_A:
		try:requests.put(f"{self._base}/behaviour/{key}",params=params,timeout=self._timeout)
		except requests.RequestException as A:print(f"[remote] behaviour {key!r} failed: {A}")
	def _fetch_behaviours(self)->dict:
		try:A=requests.get(f"{self._base}/behaviours",timeout=self._timeout);A.raise_for_status();return A.json()
		except requests.RequestException as B:print(f"[remote] /behaviours failed: {B}");return{}
	def get_touch_sensors(self)->dict:
		try:A=requests.get(f"{self._base}/sensors/touch",timeout=self._timeout);A.raise_for_status();return A.json()
		except requests.RequestException as B:print(f"[remote] /sensors/touch failed: {B}");return{}
	def is_touched(self,sensor:str)->bool:return self.get_touch_sensors().get(sensor,False)
RemoteQTRobotInterface=RemoteRobotInterface