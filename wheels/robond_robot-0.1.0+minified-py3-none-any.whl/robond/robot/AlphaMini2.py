_G='behavior'
_F='random_short3'
_E='isSuccess'
_D=False
_C=True
_B='action'
_A=None
import asyncio,hashlib,logging,os,socket,tempfile,threading,time
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from typing import Any,List,Optional
from robond.core.robot_interface import RobotInterface,Gesture,Expression
from robond.core.listener_backend import UNSET,ListenerBackend
from robond.robot.qt import _clean_for_speech
from mini.apis.api_sound import AudioStorageType
logger=logging.getLogger(__name__)
try:from gtts import gTTS;_GTTS_AVAILABLE=_C
except ImportError:_GTTS_AVAILABLE=_D;gTTS=_A
try:import speech_recognition as sr;_SR_AVAILABLE=_C
except ImportError:_SR_AVAILABLE=_D;sr=_A
try:
	from websockets.asyncio.client import ClientConnection as _WSClientConnection;from websockets.protocol import State as _WSState
	if not hasattr(_WSClientConnection,'closed'):_WSClientConnection.closed=property(lambda self:self.state is _WSState.CLOSED)
except ImportError:0
try:import mini.mini_sdk as MiniSdk;from mini.apis.api_sound import PlayAudio,AudioStorageType;from mini.dns.dns_browser import WiFiDevice;ALPHAMINI_AVAILABLE=_C
except ImportError:ALPHAMINI_AVAILABLE=_D;MiniSdk=_A
_ALPHA_EXPRESSION={Expression.HAPPY:'emo_016',Expression.EXCITED:_A,Expression.NEUTRAL:'w_basic_0003-1',Expression.SAD:'codemao2',Expression.ANGRY:'emo_013',Expression.SURPRISED:'codemao8',Expression.THINKING:'codemao1',Expression.SMILE:'emo_007',Expression.CONFUSED:'emo_019',Expression.SHY:'emo_010',Expression.EYES_HEARTS:'codemao19',Expression.EYES_SUNGLASSES:'emo_027'}
_ALPHA_GESTURE={Gesture.WAVE:(_B,_F),Gesture.NOD:(_B,'011'),Gesture.CLAP:_A,Gesture.HAPPY:(_B,'action_004'),Gesture.STRETCH:(_B,'015'),Gesture.CHEER:(_B,'010'),Gesture.GREET:(_B,_F),Gesture.FAREWELL:(_B,'action_016'),Gesture.FAREWELL_WARM:(_B,'Surveillance_004'),Gesture.POINT_FRONT:(_B,'Surveillance_003'),Gesture.WIGGLE_BUTT:(_B,'action_015'),Gesture.DANCE1:(_B,'dance_0001en'),Gesture.DANCE2:(_B,'dance_0002en'),Gesture.DANCE3:(_B,'dance_0006en')}
def _local_ip_for(remote_ip:str)->str:
	A=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
	try:A.connect((remote_ip,80));return A.getsockname()[0]
	finally:A.close()
class LoggingHandler(SimpleHTTPRequestHandler):
	def do_GET(self):print('GET:',self.path,'from',self.client_address);return super().do_GET()
class AlphaMiniRobotInterface(RobotInterface):
	def __init__(self,serial:Optional[str]=_A,ip:Optional[str]=_A,tts_lang:str='en-US',volume:int=70,robot_type:str='edu',scan_timeout:int=10,static_dir:Optional[str]=_A,http_port:int=0,listener:Optional[ListenerBackend]=_A,listener_lang:Optional[str]=_A):
		H=listener;G=robot_type;F=volume;D=scan_timeout;C=tts_lang;B=ip;A=serial
		if not ALPHAMINI_AVAILABLE:raise ImportError('alphamini SDK not available. Run `pip install alphamini`.')
		if not _GTTS_AVAILABLE:raise ImportError('gTTS not available. Run `pip install gTTS`.')
		if H is _A and not _SR_AVAILABLE:raise ImportError("No `listener` was passed in, and SpeechRecognition isn't available for the built-in microphone fallback. Either pass a `listener` (e.g. your own ListenerBackend) or `pip install SpeechRecognition pyaudio`.")
		if not A and not B:raise ValueError('AlphaMiniRobotInterface needs either `serial` (to scan for the robot on the LAN) or `ip` (to connect directly, skipping the scan).')
		self._serial=A;self._ip=B;self._tts_lang=C;self._gtts_lang=C.split('-')[0].lower();self._listener_lang=listener_lang or C;self._is_speaking=threading.Event();self._recognizer=sr.Recognizer()if _SR_AVAILABLE else _A;self._listener=H;self._volume_pct=max(0,min(100,F));self._static_dir=static_dir or tempfile.mkdtemp(prefix='alphamini_tts_');os.makedirs(self._static_dir,exist_ok=_C);I=partial(LoggingHandler,directory=self._static_dir);self._httpd=ThreadingHTTPServer(('0.0.0.0',http_port),I);self._http_port=self._httpd.server_address[1];print('HTTP server bound to:',self._httpd.server_address);self._http_thread=threading.Thread(target=self._httpd.serve_forever,name='AlphaMiniTTSStaticServer',daemon=_C);self._http_thread.start();self._loop=asyncio.new_event_loop();self._loop_thread=threading.Thread(target=self._loop.run_forever,daemon=_C);self._loop_thread.start();E=getattr(MiniSdk.RobotType,G.upper(),_A)
		if E is _A:logger.warning("robot_type '%s' isn't a RobotType member on this alphamini SDK version; falling back to EDU.",G);E=MiniSdk.RobotType.EDU
		async def J()->str:
			MiniSdk.set_robot_type(E)
			if B:C=WiFiDevice(name=A or B,address=B)
			else:
				C=await MiniSdk.get_device_by_name(A,D)
				if C is _A:raise ConnectionError(f"AlphaMini '{A}' not found on LAN within {D}s. If mDNS/multicast is blocked on this network, pass `ip=` instead to skip scanning entirely.")
			if not await MiniSdk.connect(C):raise ConnectionError(f"Failed to connect to AlphaMini at {C.address!r}")
			G=max(0,min(100,F))/1e2;await MiniSdk.change_volume(.0);await MiniSdk.enter_program();await MiniSdk.change_volume(G);return C.address
		try:self._robot_ip=self._run(J(),timeout=D+15)
		except Exception:self._httpd.shutdown();self._httpd.server_close();self._loop.call_soon_threadsafe(self._loop.stop);raise
		if self._listener is not _A:self._listener.start()
		logger.info('AlphaMini connected (%s); TTS static server on port %s',self._robot_ip,self._http_port)
	def _run(self,coro,timeout:float=15.):return asyncio.run_coroutine_threadsafe(coro,self._loop).result(timeout=timeout)
	def say(self,text:str)->_A:
		self._is_speaking.set()
		try:self._run(self._speak_async(text),timeout=60)
		finally:self._is_speaking.clear()
	async def _speak_async(self,text:str)->_A:
		B,C=await asyncio.get_running_loop().run_in_executor(_A,self._generate_mp3,text);D=time.monotonic();E,A=await PlayAudio(url=B,storage_type=AudioStorageType.NET_PUBLIC,is_serial=_C).execute();F=time.monotonic()-D;print(f"[AlphaMini] PlayAudio returned in {F:.2f}s (isSuccess={getattr(A,_E,_A)})")
		if not getattr(A,_E,_D):logger.warning("AlphaMini didn't report success playing %s (resultType=%s, response=%s). If audio never comes out, check whether a firewall is blocking the robot from reaching this machine's static file server.",B,E,A)
		asyncio.create_task(self._cleanup_after_delay(C))
	async def _cleanup_after_delay(self,path:str,delay:float=1e1)->_A:
		await asyncio.sleep(delay)
		try:os.remove(path)
		except OSError:0
	def _generate_mp3(self,text:str):A=_clean_for_speech(text,self._tts_lang);E=hashlib.sha1(A.encode('utf-8')).hexdigest()[:10];B=f"{int(time.time()*1000)}_{E}.mp3";C=os.path.join(self._static_dir,B);gTTS(text=A,lang=self._gtts_lang,slow=_D).save(C);D=_local_ip_for(self._robot_ip);print('Robot IP:',self._robot_ip);print('Serving from:',D);F=f"http://{D}:{self._http_port}/{B}";return F,C
	def set_language(self,lang:str)->_A:A=lang;self._tts_lang=A;self._gtts_lang=A.split('-')[0].lower();self._listener_lang=A;logger.debug('AlphaMini TTS/STT language set to %s',A)
	def is_speaking(self)->bool:return self._is_speaking.is_set()
	def stop(self)->_A:
		try:self._run(MiniSdk.stop_audio(),timeout=5)
		except Exception as A:logger.warning('AlphaMini stop_audio failed: %s',A)
		self._is_speaking.clear()
		if self._listener is not _A:self._listener.stop()
	def listen(self,timeout:int=10,silence_timeout:Any=UNSET)->str:return self._listener.listen(timeout,silence_timeout=silence_timeout)
	def set_expression(self,expression:Expression)->_A:
		A=expression;B=_ALPHA_EXPRESSION.get(A)
		if B is _A:logger.warning('Expression %s has no AlphaMini mapping',A);return
		self._run(MiniSdk.play_expression(B),timeout=10)
	def play_gesture(self,gesture:Gesture,speed:float=.5)->_A:
		A=gesture;B=_ALPHA_GESTURE.get(A)
		if B is _A:logger.warning('Gesture %s has no AlphaMini mapping',A);return
		D,C=B;E=MiniSdk.play_behavior(C)if D==_G else MiniSdk.play_action(C);self._run(E,timeout=20)
	def say_with_gesture(self,text:str,gesture:Gesture,speed:float=.5)->_A:self.coordinated_action(text,gesture=gesture,speed=speed)
	def coordinated_action(self,text:str,gesture:Optional[Gesture]=_A,expression:Optional[Expression]=_A,speed:float=.5)->_A:
		B=expression;A=gesture;C=[f"expr={B.name}"if B else _A,f"gesture={A.name}"if A else _A];D=' | '.join(A for A in C if A);print(f"[AlphaMini + {D}] {text}")
		async def E():
			if A:
				C=_ALPHA_GESTURE.get(A)
				if C:F,D=C;asyncio.create_task(MiniSdk.play_behavior(D)if F==_G else MiniSdk.play_action(D))
			if B:
				E=_ALPHA_EXPRESSION.get(B)
				if E:asyncio.create_task(MiniSdk.play_expression(E))
			await self._speak_async(text)
		self._is_speaking.set()
		try:self._run(E(),timeout=60)
		finally:self._is_speaking.clear()
	def get_available_gestures(self)->List[Gesture]:return list(_ALPHA_GESTURE.keys())
	def get_available_expressions(self)->List[Expression]:return list(_ALPHA_EXPRESSION.keys())
	def play_sound(self,wav_data:bytes)->_A:
		A=f"{int(time.time()*1000)}.wav";B=os.path.join(self._static_dir,A)
		with open(B,'wb')as E:E.write(wav_data)
		F=_local_ip_for(self._robot_ip);C=f"http://{F}:{self._http_port}/{A}"
		try:
			G,D=self._run(PlayAudio(url=C,storage_type=AudioStorageType.NET_PUBLIC,is_serial=_C).execute(),timeout=30)
			if not getattr(D,_E,_D):logger.warning("AlphaMini didn't report success playing %s (resultType=%s, response=%s).",C,G,D)
		finally:asyncio.run_coroutine_threadsafe(self._cleanup_after_delay(B),self._loop)
	def set_volume(self,volume:int)->_A:A=max(0,min(100,int(volume)))/1e2;self._run(MiniSdk.change_volume(A),timeout=5)
	def restore_volume(self)->_A:self.set_volume(self._volume_pct)
	def shutdown(self)->_A:
		try:self._run(MiniSdk.change_volume(.0),timeout=5);self._run(MiniSdk.quit_program(),timeout=5);time.sleep(4);self._run(MiniSdk.release(),timeout=5)
		except Exception:logger.exception('Error releasing AlphaMini connection')
		try:self._httpd.shutdown();self._httpd.server_close()
		except Exception:logger.exception('Error shutting down AlphaMini static server')
		self._loop.call_soon_threadsafe(self._loop.stop)