_F='amixer'
_E='pactl'
_D='en-US'
_C=False
_B=True
_A=None
import time,subprocess
from typing import Any,List,Optional
from robond.core.robot_interface import RobotInterface,Gesture,Expression
from robond.core.listener_backend import UNSET,ListenerBackend
from robond.core.synchronizer import TaskSynchronizer
from robond.core.text import clean_for_speech
_clean_for_speech=clean_for_speech
_QT_EXPRESSION={Expression.HAPPY:'QT/happy',Expression.EXCITED:'QT/excited',Expression.NEUTRAL:'QT/neutral',Expression.SAD:'QT/sad',Expression.ANGRY:'QT/angry',Expression.SURPRISED:'QT/surprise',Expression.SMILE:'QT/showing_smile',Expression.CONFUSED:'QT/confused',Expression.SHY:'QT/shy'}
_QT_GESTURE={Gesture.WAVE:'hi',Gesture.NOD:'nodding-yes',Gesture.CLAP:'clapping',Gesture.HAPPY:'happy',Gesture.STRETCH:'stretching',Gesture.CHEER:'hoora',Gesture.GREET:'hi',Gesture.FAREWELL:'bye',Gesture.FAREWELL_WARM:'send_kiss',Gesture.POINT_FRONT:'point_front'}
try:import rospy;from qt_robot_interface.srv import speech_say,emotion_show,speech_config,behavior_talk_text,audio_play;from qt_gesture_controller.srv import gesture_play;from qt_vosk_app.srv import speech_recognize;ROS_AVAILABLE=_B
except ImportError:ROS_AVAILABLE=_C;rospy=_A
class VOSKListenerBackend(ListenerBackend):
	def __init__(self,recognize_service,current_language_fn):self._recognize_service=recognize_service;self._current_language_fn=current_language_fn
	def listen(self,timeout:int=10,silence_timeout:Any=UNSET)->str:
		D='[TIMEOUT]';A=timeout;self._ignore_silence_timeout(silence_timeout);print(f"[mic] listening... (timeout: {A}s)");time.sleep(.1)
		try:E=(self._current_language_fn()or _D).replace('-','_');B=self._recognize_service(E,[],A);C=B.transcript if B.transcript else D;print(f"[mic] heard: '{C}'");return C
		except Exception as F:print(f"[mic] recognition failed: {F}");return D
class QTRobotInterface(RobotInterface):
	def __init__(self,node_name:str='qt_demo_node',language:str=_D,volume:int=100,mic_gain:int=150,listener:Optional[ListenerBackend]=_A):
		I='/qt_robot/speech/recognize';H='/qt_robot/audio/play';G='/qt_robot/behavior/talkText';F='/qt_robot/speech/config';E='/qt_robot/gesture/play';D='/qt_robot/emotion/show';C='/qt_robot/speech/say';B=listener
		if not ROS_AVAILABLE:raise ImportError('ROS not available. Run on the robot or use DummyRobotInterface.')
		rospy.init_node(node_name,anonymous=_B);self._set_system_volume(volume);self._set_mic_gain(mic_gain);J=B is _A;A=1e1
		try:
			rospy.wait_for_service(C,timeout=A);rospy.wait_for_service(D,timeout=A);rospy.wait_for_service(E,timeout=A);rospy.wait_for_service(F,timeout=A);rospy.wait_for_service(G,timeout=A);rospy.wait_for_service(H,timeout=A)
			if J:rospy.wait_for_service(I,timeout=A)
		except rospy.ROSException as K:raise ConnectionError(f"Cannot connect to QTrobot services: {K}")
		self.speech_service=rospy.ServiceProxy(C,speech_say);self.emotion_service=rospy.ServiceProxy(D,emotion_show);self.gesture_service=rospy.ServiceProxy(E,gesture_play);self.speech_config_service=rospy.ServiceProxy(F,speech_config);self.behavior_talk_service=rospy.ServiceProxy(G,behavior_talk_text);self.audio_play_service=rospy.ServiceProxy(H,audio_play);self.ts=TaskSynchronizer();self._is_speaking=_C;self._current_language=_A;self.set_language(language)
		if B is not _A:self._listener=B
		else:L=rospy.ServiceProxy(I,speech_recognize);self._listener=VOSKListenerBackend(recognize_service=L,current_language_fn=lambda:self._current_language)
		self._listener.start()
	def say(self,text:str)->_A:
		A=clean_for_speech(text,self._current_language or _D);print(f"[QT] {A}")
		try:self._is_speaking=_B;self.behavior_talk_service(A);self._is_speaking=_C
		except rospy.ServiceException as B:print(f"[QT] speech failed: {B}");self._is_speaking=_C
	def set_expression(self,expression:Expression)->_A:
		A=expression;B=_QT_EXPRESSION.get(A)
		if B is _A:print(f"[QT] Unknown expression: {A}");return
		try:self.emotion_service(B)
		except rospy.ServiceException as C:print(f"Expression failed: {C}")
	def play_gesture(self,gesture:Gesture,speed:float=.5)->_A:
		B=gesture;A=_QT_GESTURE.get(B)
		if A is _A:print(f"[QT] Unknown gesture: {B}");return
		try:A=f"QT/{A}"if not A.startswith('QT/')else A;self.gesture_service(A,speed)
		except rospy.ServiceException as C:print(f"Gesture failed: {C}")
	@staticmethod
	def _pulse_env()->dict:
		import os,glob;A=os.environ.copy()
		for B in glob.glob('/run/user/*/pulse/native'):
			C=B.split('/')[3]
			if int(C)>=1000:A['PULSE_SERVER']=f"unix:{B}";A['XDG_RUNTIME_DIR']=f"/run/user/{C}";break
		return A
	def _set_system_volume(self,volume:int)->_A:
		C=volume;D=f"{max(0,min(150,C))}%";E=self._pulse_env();A=_C
		try:
			I=subprocess.run([_E,'list','short','sinks'],capture_output=_B,text=_B,env=E);B=[A.split()[1]for A in I.stdout.splitlines()if len(A.split())>=2]
			for J in B:subprocess.run([_E,'set-sink-volume',J,D],capture_output=_B,env=E)
			if B:print(f"[audio] Speaker volume → {D} via PulseAudio sinks: {B}");A=_B
		except(subprocess.CalledProcessError,FileNotFoundError)as K:print(f"[audio] pactl (speaker) failed: {K}")
		F=f"{max(0,min(100,C))}%"
		for G in range(3):
			for H in('Master','PCM','Speaker','Headphone'):
				L=subprocess.run([_F,'-q','-c',str(G),'set',H,F],capture_output=_B)
				if L.returncode==0:print(f"[audio] ALSA card{G} '{H}' → {F}");A=_B
		if not A:print('[audio] WARNING: could not set speaker volume via pactl or amixer')
	def _set_mic_gain(self,gain:int)->_A:
		C=f"{max(0,min(150,gain))}%";D=self._pulse_env();A=_C
		try:
			H=subprocess.run([_E,'list','short','sources'],capture_output=_B,text=_B,env=D);B=[A.split()[1]for A in H.stdout.splitlines()if len(A.split())>=2 and'monitor'not in A.split()[1].lower()]
			for I in B:subprocess.run([_E,'set-source-volume',I,C],capture_output=_B,env=D)
			if B:print(f"[audio] Mic gain → {C} via PulseAudio sources: {B}");A=_B
		except(subprocess.CalledProcessError,FileNotFoundError)as J:print(f"[audio] pactl (mic) failed: {J}")
		E=f"{max(0,min(100,gain))}%"
		for F in range(3):
			for G in('Capture','Mic','Mic Boost','Input'):
				K=subprocess.run([_F,'-q','-c',str(F),'set',G,E],capture_output=_B)
				if K.returncode==0:print(f"[audio] ALSA card{F} '{G}' → {E}");A=_B
		if not A:print('[audio] WARNING: could not set mic gain via pactl or amixer')
	def set_language(self,lang:str)->_A:
		try:self.speech_config_service(lang,0,0);self._current_language=lang
		except rospy.ServiceException as A:print(f"Language config failed: {A}");raise
	def say_with_gesture(self,text:str,gesture:Gesture,speed:float=.5)->_A:self.play_gesture(gesture,speed);self.say(text)
	def coordinated_action(self,text:str,gesture:Optional[Gesture]=_A,expression:Optional[Expression]=_A,speed:float=.5)->_A:
		C=expression;B=gesture;F=[f"expr={C.name}"if C else _A,f"gesture={B.name}"if B else _A];G=' | '.join(A for A in F if A);print(f"[QT + {G}] {clean_for_speech(text)}")
		if C:
			D=_QT_EXPRESSION.get(C)
			if D:self._expression_raw(D)
		E=[(0,lambda:self._say_raw(text))]
		if B:
			A=_QT_GESTURE.get(B)
			if A:A=f"QT/{A}"if not A.startswith('QT/')else A;E.append((0,lambda gn=A,s=speed:self._gesture_raw(gn,s)))
		self.ts.sync(E)
	def _say_raw(self,text:str):
		self._is_speaking=_B
		try:return self.behavior_talk_service(clean_for_speech(text,self._current_language or _D))
		except rospy.ServiceException as A:
			if not rospy.is_shutdown():print(f"[QT] speech failed: {A}")
		finally:self._is_speaking=_C
	def _gesture_raw(self,gesture:str,speed:float):
		try:return self.gesture_service(gesture,speed)
		except rospy.ServiceException:0
	def _expression_raw(self,expression:str):
		try:return self.emotion_service(expression)
		except rospy.ServiceException:0
	def listen(self,timeout:int=10,silence_timeout:Any=UNSET)->str:return self._listener.listen(timeout,silence_timeout=silence_timeout)
	def stop(self)->_A:
		self._is_speaking=_C
		try:self.speech_service('')
		except rospy.ServiceException:0
		self._listener.stop()
	def is_speaking(self)->bool:return self._is_speaking
	def get_available_gestures(self)->List[Gesture]:return list(_QT_GESTURE.keys())
	def get_available_expressions(self)->List[Expression]:return list(_QT_EXPRESSION.keys())
	def play_sound(self,wav_data:bytes)->_A:
		import tempfile as D,os;A=os.path.expanduser('~/robot/data/audios/');os.makedirs(A,exist_ok=_B)
		with D.NamedTemporaryFile(suffix='.wav',dir=A,delete=_C)as B:B.write(wav_data);C=B.name
		E=os.path.basename(C)
		try:self.audio_play_service(E,'')
		except Exception as F:raise RuntimeError(f"audio_play service failed: {F}")
		finally:os.unlink(C)