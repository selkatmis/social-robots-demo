_C=False
_B=True
_A=None
import asyncio,hashlib,os,threading,time
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from typing import List
from robond.core.text import clean_for_speech
from robond.core.robot_interface import RobotInterface,Gesture,Expression
_ALPHA_EXPRESSION={Expression.HAPPY:'codemao7',Expression.EXCITED:'codemao1',Expression.NEUTRAL:'w_basic_0003-1',Expression.SAD:'emo_009',Expression.ANGRY:'emo_011',Expression.SURPRISED:'emo_007',Expression.THINKING:'emo_013',Expression.SMILE:'codemao5',Expression.CONFUSED:'emo_010',Expression.SHY:'emo_019'}
_ALPHA_GESTURE:dict={}
try:from gtts import gTTS;_GTTS_AVAILABLE=_B
except ImportError:_GTTS_AVAILABLE=_C;gTTS=_A
try:from mini_robot import MiniInterface;from mini.apis.api_expression import PlayExpression,SetMouthLamp,MouthLampColor,MouthLampMode;from mini.apis.api_sound import StartPlayTTS;from mini.apis.api_action import GetActionList,RobotActionType,PlayAction,MoveRobotDirection;from mini.mini_sdk import translate;from mini.apis.api_config import LanType,ServicePlatform;from mini.apis.api_sound import PlayAudio,AudioStorageType;from functions.robot import Robot;from functions.utils import logger,safe_api_call,is_success;from functions.controller_factory import controllers;_ALPHAMINI_AVAILABLE=_B;_ALPHAMINI_IMPORT_ERROR=_A
except ImportError as e:_ALPHAMINI_AVAILABLE=_C;_ALPHAMINI_IMPORT_ERROR=e
class AlphaMiniRobotInterface(RobotInterface):
	def __init__(self,tts_lang:str,http_host:str,static_dir:str,http_port:int=0):
		A=tts_lang
		if not _ALPHAMINI_AVAILABLE:raise RuntimeError(f"alphamini SDK not importable: {_ALPHAMINI_IMPORT_ERROR}. Install via `pip install -r requirements.alphamini.txt`.")
		self.robot=_A;(self._available_gestures_set):frozenset[str]=frozenset();self.emotion_controller=controllers.emotion;self.speech_controller=controllers.speech;self._tts_lang=A;self._gtts_lang=A.split('-')[0].lower();self._http_host=http_host;self._http_port_requested=http_port;self._tts_is_speaking=threading.Event();self._static_dir=static_dir;os.makedirs(self._static_dir,exist_ok=_B)
	def connect(self):A=partial(SimpleHTTPRequestHandler,directory=self._static_dir);self._httpd=ThreadingHTTPServer(('0.0.0.0',self._http_port_requested),A);self._http_port=self._httpd.server_address[1];self._http_thread=threading.Thread(target=self._httpd.serve_forever,name='AlphaMiniTTSStaticServer',daemon=_B);self._http_thread.start();self._loop=asyncio.new_event_loop();self._loop_ready=threading.Event();self._loop_thread=threading.Thread(target=self._run_loop,name='AlphaMiniTTSLoop',daemon=_B);self._loop_thread.start();self._loop_ready.wait();logger.info('AlphaMini static server listening on %s:%s (dir=%s)',self._http_host,self._http_port,self._static_dir);self.run_coroutine(self._connect_async())
	async def _connect_async(self):self._robot_controller=Robot();self._robot_controller.setup_sdk();A=self._robot_controller.get_device('192.168.1.23');await self._robot_controller.connect_robot(A);await asyncio.sleep(1);await self._robot_controller.start_programming();self.robot=MiniInterface();self._available_gestures_set=frozenset(await self._list_actions_async());logger.info('Robot connected (%d gestures cached)',len(self._available_gestures_set))
	def _run_loop(self):asyncio.set_event_loop(self._loop);self._loop_ready.set();self._loop.run_forever()
	def shutdown(self):
		try:self._httpd.shutdown();self._httpd.server_close();logger.info('Shut down AlphaMini static server')
		except Exception:logger.exception('Error shutting down AlphaMini static server')
		try:self._loop.call_soon_threadsafe(self._loop.stop);self._loop_thread.join(timeout=5);logger.info('Shut down AlphaMini asyncio loop')
		except Exception:logger.exception('Error shutting down AlphaMini asyncio loop')
	def run_coroutine(self,coro):return asyncio.run_coroutine_threadsafe(coro,self._loop).result()
	def set_expression(self,expression:Expression)->_A:
		B=expression;A=_ALPHA_EXPRESSION.get(B)
		if A is _A:logger.warning('Expression %s has no AlphaMini mapping',B);return
		self.run_coroutine(self.emotion_controller.set_expression(A));logger.info("Expression '%s' set successfully",A)
	async def _list_actions_async(self)->List[str]:
		A=await controllers.action.list_actions()
		if not A:return[]
		def B(lst):
			for A in lst:
				if isinstance(A,list):yield from B(A)
				else:yield A
		C=list(B(A));return[A.strip()if isinstance(A,str)else A for A in C]
	def get_available_gestures(self)->List[Gesture]:return list(_ALPHA_GESTURE.keys())
	def play_gesture(self,gesture:Gesture,speed:float=.5)->_A:
		B=gesture;A=_ALPHA_GESTURE.get(B)
		if A is _A:logger.warning('Gesture %s has no AlphaMini mapping',B);return
		self.run_coroutine(controllers.action.play_action(A));logger.info("Action '%s' played successfully.",A)
	def set_language(self,lang:str)->_A:logger.debug(f"Language set to {lang}")
	def say_with_gesture(self,text:str,gesture:Gesture,speed:float=.5)->_A:
		C=gesture;A=text;B=_ALPHA_GESTURE.get(C)
		if B is _A:logger.warning('Gesture %s has no AlphaMini mapping — saying without gesture',C);self.say(A);return
		D=self._generate_mp3(A);E=f"http://{self._http_host}:{self._http_port}/{D}"
		async def F():await asyncio.gather(self._play_on_robot(E),PlayAction(action_name=B).execute())
		self._tts_is_speaking.set()
		try:self.run_coroutine(F())
		finally:self._tts_is_speaking.clear()
		logger.info("Spoke '%s' while performing '%s'",A,B)
	def get_available_expressions(self)->List[Expression]:return list(_ALPHA_EXPRESSION.keys())
	def say(self,text:str):
		self._tts_is_speaking.set()
		try:B=self._generate_mp3(text);A=f"http://{self._http_host}:{self._http_port}/{B}";logger.debug('AlphaMini playing %s',A);self.run_coroutine(self._play_on_robot(A))
		finally:self._tts_is_speaking.clear()
	def is_speaking(self)->bool:return self._tts_is_speaking.is_set()
	def _generate_mp3(self,text:str)->str:A=clean_for_speech(text);C=hashlib.sha1(A.encode('utf-8')).hexdigest()[:10];B=f"{time.time_ns()//1e6}_{C}.mp3";D=os.path.join(self._static_dir,B);gTTS(text=A,lang=self._gtts_lang,slow=_C).save(D);return B
	def play_sound(self,wav_data:bytes)->_A:raise NotImplementedError('AlphaMini does not support play_sound')
	async def _play_on_robot(self,url:str):await PlayAudio(url=url,storage_type=AudioStorageType.NET_PUBLIC,is_serial=_B).execute()