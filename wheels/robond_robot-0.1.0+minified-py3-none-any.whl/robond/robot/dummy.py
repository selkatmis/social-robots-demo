_B=False
_A=None
import time
from typing import Any,List,Optional
from robond.core.robot_interface import RobotInterface,Gesture,Expression
from robond.core.listener_backend import UNSET,ListenerBackend
class KeyboardListenerBackend(ListenerBackend):
	def listen(self,timeout:int=10,silence_timeout:Any=UNSET)->str:return input('Child: ').strip()
class DummyRobotInterface(RobotInterface):
	def __init__(self,language:str='en-US',verbose:bool=True,listener:Optional[ListenerBackend]=_A):A=listener;self._current_language=language;self._is_speaking=_B;self._verbose=verbose;(self._listener):ListenerBackend=A if A is not _A else KeyboardListenerBackend();self._listener.start()
	def say(self,text:str)->_A:self._is_speaking=True;print(f"Robot: '{text}'");time.sleep(len(text.split())*.35+.5);self._is_speaking=_B
	def set_expression(self,expression:Expression)->_A:
		if self._verbose:print(f"[expression: {expression.name}]")
	def play_gesture(self,gesture:Gesture,speed:float=.5)->_A:
		if self._verbose:print(f"[gesture: {gesture.name}]")
		time.sleep(.3)
	def set_language(self,lang:str)->_A:self._current_language=lang
	def say_with_gesture(self,text:str,gesture:Gesture,speed:float=.5)->_A:self.play_gesture(gesture,speed);self.say(text)
	def coordinated_action(self,text:str,gesture:Optional[Gesture]=_A,expression:Optional[Expression]=_A,speed:float=.5)->_A:
		B=expression;A=gesture
		if B:self.set_expression(B)
		if A:self.play_gesture(A,speed)
		self.say(text)
	def stop(self)->_A:self._is_speaking=_B;self._listener.stop();print('[robot] stopped')
	def is_speaking(self)->bool:return self._is_speaking
	def get_available_gestures(self)->List[Gesture]:return list(Gesture)
	def get_available_expressions(self)->List[Expression]:return list(Expression)
	def play_sound(self,wav_data:bytes)->_A:
		if self._verbose:print(f"[sound: {len(wav_data)} bytes WAV]")
	def listen(self,timeout:int=10,silence_timeout:Any=UNSET)->str:return self._listener.listen(timeout,silence_timeout=silence_timeout)