_A=None
import logging,os
from typing import Optional
from robond.asr.tts_base import BaseTTSMixin,TTSError,float_to_int16,optional_import
from robond.asr.tts_torch import resolve_device,torch
logger=logging.getLogger(__name__)
_coqui_api=optional_import('TTS.api')
CoquiTTS=getattr(_coqui_api,'TTS',_A)
_COQUI_DEFAULT_MODELS={'en':'tts_models/en/ljspeech/vits','nl':'tts_models/nl/css10/vits'}
_COQUI_TOS_FRAGMENTS='xtts',
_COQUI_TOS_ENV='COQUI_TOS_AGREED'
_COQUI_CPML_URL='https://coqui.ai/cpml'
__all__=['CoquiTTSMixin']
class CoquiTTSMixin(BaseTTSMixin):
	def __init__(self,*D,tts_lang:str='en-US',coqui_model:Optional[str]=_A,coqui_device:Optional[str]=_A,coqui_speaker:Optional[str]=_A,coqui_speaker_wav:Optional[str]=_A,coqui_split_sentences:bool=True,**E):
		B=tts_lang
		if CoquiTTS is _A:raise RuntimeError('coqui-tts is not installed. Run: pip install "robond.asr[tts-coqui]"')
		if torch is _A:raise RuntimeError('PyTorch is not installed, and coqui-tts does not pull it in. Run: pip install "robond.asr[tts-coqui]"')
		A=coqui_model or self._default_model(B);self._require_tos_agreement(A);self._coqui_device=resolve_device(coqui_device);self._coqui_speaker=coqui_speaker;self._coqui_speaker_wav=coqui_speaker_wav;self._coqui_split_sentences=coqui_split_sentences;logger.warning('Loading Coqui model %s on %s — the first run downloads it to ~/.local/share/tts and may take several minutes.',A,self._coqui_device)
		try:self._coqui=CoquiTTS(A,progress_bar=False).to(self._coqui_device)
		except FileNotFoundError as C:
			if'espeak'not in str(C).lower():raise
			raise TTSError(f"Coqui model {A} needs the espeak-ng system package as its phonemizer backend, which pip does not install. Run: sudo apt install espeak-ng  (or 'brew install espeak-ng' on macOS).")from C
		super().__init__(*D,tts_lang=B,**E)
	@staticmethod
	def _default_model(tts_lang:str)->str:A=tts_lang.split('-')[0].lower();return _COQUI_DEFAULT_MODELS.get(A,_COQUI_DEFAULT_MODELS['en'])
	@staticmethod
	def _require_tos_agreement(model_name:str)->_A:
		A=model_name;B=any(B in A for B in _COQUI_TOS_FRAGMENTS)
		if B and not os.environ.get(_COQUI_TOS_ENV):raise TTSError(f"{A} is licensed under the Coqui Public Model License and Coqui will prompt for agreement on stdin, which would hang a running session. Read {_COQUI_CPML_URL} and, if you accept it, set {_COQUI_TOS_ENV}=1 before starting.")
	def _synthesize_wav(self,text:str)->bytes:
		A={'split_sentences':self._coqui_split_sentences}
		if self._coqui.is_multi_lingual:A['language']=self._tts_locale.split('-')[0].lower()
		if self._coqui_speaker_wav:A['speaker_wav']=self._coqui_speaker_wav
		elif self._coqui_speaker and self._coqui.is_multi_speaker:A['speaker']=self._coqui_speaker
		B=self._coqui.tts(text=text,**A);return self._to_wav_bytes(float_to_int16(B),self._coqui.synthesizer.output_sample_rate)