_D=False
_C=1.
_B=True
_A=None
import logging,queue,threading,time
from datetime import datetime
from pathlib import Path
from typing import Any,List,Optional
import numpy as np
from robond.core.listener_backend import UNSET,ListenerBackend
try:import soundfile as sf
except ImportError:sf=_A
try:from cltl.asr.api_streaming import BufferedASR,StreamTranscription;from cltl.asr.parakeet_stream import LocalParakeetRNNTStreamingASR;_CLTL_AVAILABLE=_B
except ImportError:_CLTL_AVAILABLE=_D;BufferedASR=object;StreamTranscription=_A;LocalParakeetRNNTStreamingASR=_A
logger=logging.getLogger(__name__)
_WARMUP_SECONDS=5
class StreamingListenerBackend(ListenerBackend):
	def __init__(self,audio_source,max_queue_size:int=100,save_audio_dir:Optional[str]=_A,cutoff_window:float=1,**B):
		A=save_audio_dir
		if not _CLTL_AVAILABLE:raise ImportError('cltl.asr[impl,parakeet] is required for StreamingListenerBackend. Install it via requirements-dev.txt or the [streaming] extra.')
		self._audio_source=audio_source;self._max_queue_size=max_queue_size;self._cutoff_window=cutoff_window;self._save_audio_dir=Path(A)if A else _A
		if A:
			if sf is _A:raise RuntimeError('Audio saving requires soundfile: pip install soundfile')
			self._save_audio_dir.mkdir(parents=_B,exist_ok=_B);logger.info('Audio turns will be saved to: %s',self._save_audio_dir)
		(self._asr):LocalParakeetRNNTStreamingASR=LocalParakeetRNNTStreamingASR(**B);(self._audio_queue):Optional[queue.Queue]=_A;(self._transcript_queue):Optional[queue.Queue]=_A;(self._worker_thread):Optional[threading.Thread]=_A;(self._source_thread):Optional[threading.Thread]=_A;self._running=_D;self._shutdown_event=threading.Event();self._reset_requested=threading.Event();(self._current_turn_audio):List[np.ndarray]=[];self._turn_counter=0;(self._sampling_rate):Optional[int]=_A
	def start(self)->_A:
		if self._running:raise RuntimeError('Already running. Call stop() first.')
		self._audio_queue=queue.Queue(maxsize=self._max_queue_size);self._transcript_queue=queue.Queue();self._sampling_rate=getattr(self._audio_source,'rate',16000);self._running=_B;self._shutdown_event.clear();self._reset_requested.clear();self._worker_thread=threading.Thread(target=self._process_loop,name='ASR-StreamingListener',daemon=_D);self._worker_thread.start();self._source_thread=threading.Thread(target=self._capture_loop,name='ASR-AudioCapture',daemon=_D);self._source_thread.start();logger.info('Streaming ASR started — waiting %ss for model warm-up',_WARMUP_SECONDS);time.sleep(_WARMUP_SECONDS);logger.info('Streaming ASR ready')
	def listen(self,timeout:int=20,silence_timeout:Any=UNSET)->str:
		I='[TIMEOUT]';B=timeout;self._ignore_silence_timeout(silence_timeout)
		if not self._running:raise RuntimeError('Call start() before listen()')
		logger.info('listen() called — flushing ASR state for new turn');self._reset_requested.set();J=time.time()+.5
		while self._reset_requested.is_set()and time.time()<J:time.sleep(.01)
		C=self._asr.get_current_sample_position();logger.info('ASR ready for new turn at sample %s',C);D=time.time()+B if B>0 else _A
		while _B:
			if D:
				E=D-time.time()
				if E<=0:logger.info('listen() timed out');return I
				F=min(E,_C)
			else:F=_C
			try:A=self._transcript_queue.get(timeout=F)
			except queue.Empty:
				if not self._running:logger.info('Listening stopped while waiting');return I
				continue
			G=getattr(self._asr,'context_samples',_A);K=G.right if G is not _A else 0;H=C-K-int(self._sampling_rate*self._cutoff_window)
			if A.start<H:
				if A.is_final:logger.info("Discarding pre-listen transcript '%s' (start=%s < adjusted_cutoff=%s)",A.text,A.start,H)
				continue
			if A.is_final:logger.info('Final transcript: %s',A.text);return A.text.strip()
	def stop(self)->_A:
		if not self._running:logger.warning('stop() called but not running');return
		logger.info('Stopping streaming ASR...');self._running=_D
		if hasattr(self._audio_source,'stop'):
			try:self._audio_source.stop()
			except Exception as A:logger.error('Error stopping audio source: %s',A)
		if self._audio_queue:
			try:self._audio_queue.join()
			except Exception as A:logger.warning('Error draining audio queue: %s',A)
		if self._worker_thread and self._worker_thread.is_alive():self._shutdown_event.wait(timeout=1e1);self._worker_thread.join(timeout=_C)
		if self._source_thread and self._source_thread.is_alive():self._source_thread.join(timeout=_C)
		logger.info('Streaming ASR stopped')
	def _capture_loop(self)->_A:
		with self._audio_source as A:
			logger.debug('Audio source ready: %s  rate=%s Hz  channels=%s  frame=%s  depth=%s',type(A).__name__,A.rate,A.channels,A.frame_size,A.depth)
			try:
				for B in A.audio:
					if not self._running:break
					try:self._audio_queue.put(B.squeeze(),timeout=_C)
					except queue.Full:logger.warning('Audio queue full, dropping frame')
			except Exception as C:logger.error('Error in audio capture loop: %s',C,exc_info=_B)
			finally:logger.debug('Audio capture loop terminated')
	def _process_loop(self)->_A:
		while self._running:
			if self._reset_requested.is_set():
				C=self._asr.flush()
				if C.text:logger.info('Flushed pre-listen transcript: %r',C.text)
				while not self._transcript_queue.empty():
					try:self._transcript_queue.get_nowait()
					except queue.Empty:break
				self._reset_requested.clear();logger.debug('ASR flushed at listen() boundary')
			try:
				B=[]
				try:B.append(self._audio_queue.get(timeout=.1))
				except queue.Empty:continue
				while not self._audio_queue.empty()and len(B)<10:
					try:B.append(self._audio_queue.get_nowait())
					except queue.Empty:break
				self._current_turn_audio.extend(B)
				for A in self._asr.push_audio(B,self._sampling_rate):
					if A.is_final:
						if self._save_audio_dir:self._save_turn_audio()
						self._current_turn_audio.clear();logger.info('ASR final: %r start=%s end=%s',A.text,A.start,A.end)
					else:logger.debug('ASR partial: %r start=%s',A.text,A.start)
					self._transcript_queue.put(A)
				for E in B:self._audio_queue.task_done()
			except Exception as D:logger.error('Error in processing loop: %s',D,exc_info=_B)
		self._drain_queue();self._shutdown_event.set()
	def _drain_queue(self)->_A:
		if not self._audio_queue or self._audio_queue.empty():return
		logger.info('Draining remaining audio frames...');A=[]
		while not self._audio_queue.empty():
			try:A.append(self._audio_queue.get_nowait());self._audio_queue.task_done()
			except queue.Empty:break
		if A:
			self._current_turn_audio.extend(A)
			for C in self._asr.push_audio(A,self._sampling_rate):self._transcript_queue.put(C)
		if hasattr(self._asr,'finish'):
			B=self._asr.finish()
			if B and B.text:
				self._transcript_queue.put(B)
				if self._save_audio_dir and self._current_turn_audio:self._save_turn_audio()
	def _save_turn_audio(self)->_A:
		if not self._current_turn_audio or not self._save_audio_dir:return
		try:
			A=np.concatenate(self._current_turn_audio).astype(np.float32)
			if A.max()>_C or A.min()<-_C:A=A/32768.
			C=datetime.now().strftime('%Y%m%d_%H%M%S_%f');B=self._save_audio_dir/f"turn_{self._turn_counter:04d}_{C}.wav";sf.write(str(B),A,self._sampling_rate);self._turn_counter+=1;logger.debug('Saved turn audio to %s',B)
		except Exception as D:logger.error('Failed to save turn audio: %s',D,exc_info=_B)
	@property
	def is_listening(self)->bool:return self._running
	def get_queue_size(self)->int:return self._audio_queue.qsize()if self._audio_queue else 0
	def get_pending_transcripts(self)->List[StreamTranscription]:
		A=[]
		if self._transcript_queue:
			while not self._transcript_queue.empty():
				try:A.append(self._transcript_queue.get_nowait())
				except queue.Empty:break
		return A