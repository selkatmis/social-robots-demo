_A=None
import io,logging,os,wave
from typing import List,Optional
from robond.asr.tts_base import BaseTTSMixin,TTSError,optional_import
logger=logging.getLogger(__name__)
_piper_module=optional_import('piper')
PiperVoice=getattr(_piper_module,'PiperVoice',_A)
SynthesisConfig=getattr(_piper_module,'SynthesisConfig',_A)
_DEFAULT_MODEL_DIR='~/.local/share/piper-voices'
_PIPER_DEFAULT_VOICES={'en':'en_US-lessac-medium','nl':'nl_NL-ronnie-medium'}
__all__=['PiperTTSMixin']
class PiperTTSMixin(BaseTTSMixin):
	def __init__(self,*E,tts_lang:str='en-US',piper_model:Optional[str]=_A,piper_model_dir:Optional[str]=_A,piper_speaker_id:Optional[int]=_A,piper_length_scale:Optional[float]=_A,**F):
		D=tts_lang;A=piper_speaker_id
		if PiperVoice is _A:raise RuntimeError('Piper is not installed. Run: pip install "robond.asr[tts-piper]"')
		B=self._resolve_model(D,piper_model,piper_model_dir);logger.info('Loading Piper voice from %s',B);self._piper_voice=PiperVoice.load(B);self._piper_syn_config=SynthesisConfig(speaker_id=A,length_scale=piper_length_scale);C=self._piper_voice.config.num_speakers
		if A is not _A and C<=1:logger.warning('piper_speaker_id=%s ignored: %s has only one speaker. Pass piper_model= a multi-speaker voice to choose between voices.',A,os.path.basename(B))
		else:logger.info('Piper voice ready: %s (speakers=%d, speaker_id=%s)',os.path.basename(B),C,A if A is not _A else'0 (default)'if C>1 else'n/a')
		super().__init__(*E,tts_lang=D,**F)
	@staticmethod
	def _resolve_model(tts_lang:str,piper_model:Optional[str],piper_model_dir:Optional[str])->str:
		J='.onnx';G=piper_model_dir;F=tts_lang;D=piper_model;K=F.split('-')[0].lower();H=_PIPER_DEFAULT_VOICES.get(K,_PIPER_DEFAULT_VOICES['en']);B:List[str]=[]
		if D:
			B.append(os.path.expanduser(D));A=os.path.basename(B[0])
			if A.endswith(J):A=A[:-len(J)]
			E=os.path.dirname(D)or _DEFAULT_MODEL_DIR
		else:L=os.path.expanduser(G or _DEFAULT_MODEL_DIR);B.append(os.path.join(L,f"{H}.onnx"));A=H;E=G or _DEFAULT_MODEL_DIR
		for C in B:
			if not os.path.isfile(C):continue
			I=f"{C}.json"
			if not os.path.isfile(I):raise TTSError(f"Piper voice {C} is missing its config sidecar {I}. Re-download the voice with:\n  python -m piper.download_voices {A} --data-dir {E}")
			return C
		M='\n'.join(f"  {A}"for A in B);raise TTSError(f"No Piper voice model found for {F!r}. Searched:\n{M}\nDownload it with:\n  python -m piper.download_voices {A} --data-dir {E}\nor pass piper_model='/path/to/voice.onnx'.")
	def _synthesize_wav(self,text:str)->bytes:
		A=io.BytesIO()
		with wave.open(A,'wb')as B:self._piper_voice.synthesize_wav(text,B,syn_config=self._piper_syn_config)
		return A.getvalue()