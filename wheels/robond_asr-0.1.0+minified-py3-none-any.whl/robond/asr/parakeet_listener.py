_A=True
import io,logging,os,sys,tempfile,time
from typing import Any
import numpy as np
from cltl.backend.spi.audio import AudioSource
from robond.core.listener_backend import UNSET,ListenerBackend
SAMPLE_RATE=16000
FRAME_SIZE=480
FRAME_BYTES=FRAME_SIZE*2
SILENCE_MS=1500
SILENCE_FRAMES=SILENCE_MS//30
def _load_parakeet_model():
	logging.disable(logging.CRITICAL);B,C=sys.stdout,sys.stderr;sys.stdout=sys.stderr=io.StringIO()
	try:from nemo.collections.asr.models import ASRModel as D;A=D.from_pretrained('nvidia/parakeet-tdt-0.6b-v3');A.eval()
	finally:
		sys.stdout,sys.stderr=B,C;logging.disable(logging.NOTSET)
		for E in('nemo','nemo_logging','speechbrain','pytorch_lightning','lightning'):logging.getLogger(E).setLevel(logging.CRITICAL)
	return A
class ParakeetListenerBackend(ListenerBackend):
	_model=None
	@classmethod
	def _get_model(cls):
		if cls._model is None:print('[parakeet] loading model (first call only)...',flush=_A);cls._model=_load_parakeet_model();print('[parakeet] model ready.',flush=_A)
		return cls._model
	def __init__(self,audio_source:AudioSource):import webrtcvad as A;self._audio_source=audio_source;self._vad=A.Vad(2);self._get_model()
	def listen(self,timeout:int=20,silence_timeout:Any=UNSET)->str:
		E='[TIMEOUT]';A=timeout;self._ignore_silence_timeout(silence_timeout);print(f"[mic] listening... (timeout: {A}s)",flush=_A);time.sleep(.3);B=self._record_until_silence(A)
		if not B:print("[mic] heard: '[TIMEOUT]'",flush=_A);return E
		C=self._transcribe(B);D=C.strip()if C else E;print(f"[mic] heard: '{D}'",flush=_A);return D
	def _record_until_silence(self,timeout:int)->list:
		E=time.time()+timeout;B=[];C=0;D=False
		with self._audio_source as F:
			for G in F.audio:
				if time.time()>=E:break
				A=G.flatten().astype(np.int16).tobytes()
				if len(A)<FRAME_BYTES:continue
				A=A[:FRAME_BYTES]
				if self._vad.is_speech(A,SAMPLE_RATE):D=_A;C=0;B.append(A)
				elif D:
					C+=1;B.append(A)
					if C>=SILENCE_FRAMES:break
		return B if D else[]
	def _transcribe(self,frames:list)->str:
		import soundfile as D;E=np.frombuffer(b''.join(frames),dtype=np.int16).astype(np.float32)/32768.;A=None
		try:
			with tempfile.NamedTemporaryFile(suffix='.wav',delete=False)as F:A=F.name
			D.write(A,E,SAMPLE_RATE);G=self._get_model();C=G.transcribe([A])
			if not C:return''
			B=C[0];return B.text if hasattr(B,'text')else str(B)
		except Exception as H:print(f"[parakeet] transcription error: {H}",flush=_A);return''
		finally:
			if A and os.path.exists(A):os.unlink(A)