_A=None
import logging,os
from typing import Optional
from robond.asr.tts_base import BaseTTSMixin,TTSError,TTSSynthesisError,optional_import
logger=logging.getLogger(__name__)
speechsdk=optional_import('azure.cognitiveservices.speech')
_AZURE_DEFAULT_VOICES={'en':'en-US-JennyNeural','nl':'nl-NL-FennaNeural'}
_AZURE_FALLBACK_VOICE=_AZURE_DEFAULT_VOICES['en']
__all__=['AzureTTSMixin']
class AzureTTSMixin(BaseTTSMixin):
	def __init__(self,*G,tts_lang:str='en-US',azure_voice:Optional[str]=_A,azure_key:Optional[str]=_A,azure_region:Optional[str]=_A,azure_output_format:str='Riff22050Hz16BitMonoPcm',**H):
		C=azure_output_format;B=tts_lang
		if speechsdk is _A:raise RuntimeError('The Azure Speech SDK is not installed. Run: pip install "robond.asr[tts-azure]"')
		D=azure_key or os.environ.get('AZURE_SPEECH_KEY');E=azure_region or os.environ.get('AZURE_SPEECH_REGION')
		if not D:raise TTSError('No Azure speech key. Set AZURE_SPEECH_KEY or pass azure_key=.')
		if not E:raise TTSError("No Azure speech region. Set AZURE_SPEECH_REGION or pass azure_region= (e.g. 'westeurope').")
		self._azure_voice=azure_voice or self._default_voice(B);A=speechsdk.SpeechConfig(subscription=D,region=E);A.speech_synthesis_voice_name=self._azure_voice;F=getattr(speechsdk.SpeechSynthesisOutputFormat,C,_A)
		if F is _A:raise TTSError(f"Unknown Azure output format {C!r}. Expected a SpeechSynthesisOutputFormat member name, e.g. 'Riff22050Hz16BitMonoPcm'.")
		A.set_speech_synthesis_output_format(F);self._azure_synthesizer=speechsdk.SpeechSynthesizer(speech_config=A,audio_config=_A);super().__init__(*G,tts_lang=B,**H)
	@staticmethod
	def _default_voice(tts_lang:str)->str:
		A=tts_lang;C=A.split('-')[0].lower();B=_AZURE_DEFAULT_VOICES.get(C)
		if B is _A:logger.warning('No default Azure voice for %r; falling back to %s. Pass azure_voice= to choose one explicitly.',A,_AZURE_FALLBACK_VOICE);return _AZURE_FALLBACK_VOICE
		return B
	def _synthesize_wav(self,text:str)->bytes:
		A=self._azure_synthesizer.speak_text_async(text).get()
		if A.reason==speechsdk.ResultReason.SynthesizingAudioCompleted:return bytes(A.audio_data)
		if A.reason==speechsdk.ResultReason.Canceled:B=A.cancellation_details;raise TTSSynthesisError(f"Azure synthesis cancelled ({B.reason}): {B.error_details}")
		raise TTSSynthesisError(f"Azure synthesis failed: reason={A.reason}")