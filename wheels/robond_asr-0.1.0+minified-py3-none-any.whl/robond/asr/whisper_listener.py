_B='audio'
_A=True
import time
from typing import Any
import numpy as np
try:from dev_logger import dev_log
except ImportError:
	def dev_log(cat,msg):0
from cltl.backend.spi.audio import AudioSource
from robond.core.listener_backend import UNSET,ListenerBackend
SAMPLE_RATE=16000
FRAME_SIZE=480
FRAME_BYTES=FRAME_SIZE*2
SILENCE_MS=1500
SILENCE_FRAMES=SILENCE_MS//30
MAX_NO_SPEECH_PROB=.6
MIC_SOFTWARE_GAIN=2.
def _load_whisper_model(model_size:str):from faster_whisper import WhisperModel as A;return A(model_size,device='cpu',compute_type='int8')
class WhisperListenerBackend(ListenerBackend):
	_model=None
	@classmethod
	def _get_model(cls,model_size:str='small'):
		A=model_size
		if cls._model is None:print(f"[whisper] loading model '{A}' (first call only)...",flush=_A);cls._model=_load_whisper_model(A);print('[whisper] model ready.',flush=_A)
		return cls._model
	def __init__(self,audio_source:AudioSource,model_size:str='medium',whisper_language:str=None):import webrtcvad as A;self._audio_source=audio_source;self._whisper_language=whisper_language;self._vad=A.Vad(1);self._get_model(model_size)
	def listen(self,timeout:int=20,silence_timeout:Any=UNSET)->str:
		F='[TIMEOUT]';E="[mic] heard: '[TIMEOUT]'";C=timeout;self._ignore_silence_timeout(silence_timeout);print(f"[mic] listening... (timeout: {C}s)",flush=_A);dev_log(_B,f"listen() start — timeout={C}s lang={self._whisper_language}");time.sleep(.1);G=time.time()+C
		while _A:
			H=G-time.time()
			if H<=0:print(E,flush=_A);dev_log(_B,'total timeout elapsed → TIMEOUT');return F
			K=time.time();A=self._record_from_source(H);I=time.time()-K
			if not A:print(E,flush=_A);dev_log(_B,f"no speech detected after {I:.1f}s → TIMEOUT");return F
			L=len(A)*.03;dev_log(_B,f"recorded {len(A)} frames = {L:.2f}s in {I:.1f}s real time");M=time.time();D=self._transcribe(A);N=time.time()-M;B=D.strip()if D else'';dev_log(_B,f"Whisper took {N:.2f}s → raw='{D}' → result='{B or"[empty]"}'")
			if B:print(f"[mic] heard: '{B}'",flush=_A);return B
			J=G-time.time();dev_log(_B,f"noise burst / empty transcription — retrying ({J:.1f}s remaining)")
			if J<=0:print(E,flush=_A);return F
	def _record_from_source(self,timeout:float)->list:
		E=time.time()+timeout;B=[];C=0;D=False
		with self._audio_source as F:
			for G in F.audio:
				if time.time()>=E:break
				A=G.flatten().astype(np.int16).tobytes()
				if len(A)<FRAME_BYTES:continue
				A=A[:FRAME_BYTES]
				if self._vad.is_speech(A,SAMPLE_RATE):D=_A;C=0;B.append(A)
				elif D:
					C+=1;B.append(A)
					if C>=SILENCE_FRAMES:break
		return B if D else[]
	def _transcribe(self,frames:list)->str:
		C=1.;B=np.frombuffer(b''.join(frames),dtype=np.int16).astype(np.float32)/32768.
		if MIC_SOFTWARE_GAIN!=C:B=np.clip(B*MIC_SOFTWARE_GAIN,-C,C);dev_log(_B,f"software gain ×{MIC_SOFTWARE_GAIN} applied")
		try:
			I=self._get_model();J,D=I.transcribe(B,language=self._whisper_language,beam_size=5,vad_filter=False);E=list(J);dev_log(_B,f"Whisper segments: {len(E)} | detected_lang={getattr(D,"language","?")} prob={getattr(D,"language_probability",0):.2f}");F=[]
			for(G,A)in enumerate(E):
				dev_log(_B,f"  seg[{G}] [{A.start:.1f}s-{A.end:.1f}s] avg_logprob={A.avg_logprob:.2f} no_speech_prob={A.no_speech_prob:.2f}: '{A.text}'")
				if A.no_speech_prob<MAX_NO_SPEECH_PROB:F.append(A.text)
				else:dev_log(_B,f"  seg[{G}] DISCARDED — no_speech_prob={A.no_speech_prob:.2f} ≥ {MAX_NO_SPEECH_PROB} (hallucination guard)")
			return' '.join(F).strip()
		except Exception as H:print(f"[whisper] transcription error: {H}",flush=_A);dev_log('error',f"Whisper transcription error: {H}");return''