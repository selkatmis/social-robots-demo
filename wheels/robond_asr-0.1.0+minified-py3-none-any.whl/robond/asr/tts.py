import io,logging
from robond.asr.tts_base import BaseTTSMixin,TTSError,TTSSynthesisError,optional_import
logger=logging.getLogger(__name__)
_gtts_module=optional_import('gtts')
_gTTS=getattr(_gtts_module,'gTTS',None)
sf=optional_import('soundfile')
__all__=['GTTSMixin','LocalTTSMixin','RemoteTTSMixin','BaseTTSMixin','TTSError','TTSSynthesisError']
class GTTSMixin(BaseTTSMixin):
	def __init__(self,*B,tts_lang:str='en-US',**C):
		A=tts_lang
		if _gTTS is None:raise RuntimeError('gTTS is not installed. Run: pip install gtts')
		if sf is None:raise TTSError('gTTS output is MP3 and needs soundfile to decode. Run: pip install soundfile')
		self._tts_lang=A.split('-')[0].lower();super().__init__(*B,tts_lang=A,**C)
	def _synthesize_wav(self,text:str)->bytes:
		A=io.BytesIO();_gTTS(text=text,lang=self._tts_lang,slow=False).write_to_fp(A);A.seek(0)
		try:B,C=sf.read(A,dtype='int16',always_2d=True)
		except Exception as D:raise TTSSynthesisError("Failed to decode gTTS MP3. This needs libsndfile >= 1.1 with MPEG support; upgrade with 'pip install -U soundfile>=0.12.1'.")from D
		E=B.shape[1];return self._to_wav_bytes(B.reshape(-1),C,channels=E)
LocalTTSMixin=GTTSMixin
class RemoteTTSMixin(GTTSMixin):
	def __init__(self,*A,tts_output:str='robot',**B):super().__init__(*A,tts_output=tts_output,**B)