_A=None
import logging
from typing import Optional
from robond.asr.tts_base import BaseTTSMixin,TTSError,float_to_int16,optional_import
from robond.asr.tts_torch import resolve_device,torch
logger=logging.getLogger(__name__)
_transformers=optional_import('transformers')
VitsModel=getattr(_transformers,'VitsModel',_A)
AutoTokenizer=getattr(_transformers,'AutoTokenizer',_A)
_MMS_LANG_CODES={'en':'eng','nl':'nld'}
_MMS_MODEL_TEMPLATE='facebook/mms-tts-{code}'
__all__=['MMSTTSMixin']
class MMSTTSMixin(BaseTTSMixin):
	def __init__(self,*E,tts_lang:str='en-US',mms_model:Optional[str]=_A,mms_device:Optional[str]=_A,mms_speaking_rate:Optional[float]=_A,mms_noise_scale:Optional[float]=_A,mms_seed:Optional[int]=_A,**F):
		D=mms_noise_scale;C=mms_speaking_rate;B=tts_lang
		if VitsModel is _A or AutoTokenizer is _A:raise RuntimeError('transformers is not installed. Run: pip install "robond.asr[tts-mms]"')
		if torch is _A:raise RuntimeError('PyTorch is not installed. Run: pip install "robond.asr[tts-mms]"')
		A=mms_model or self._default_model(B);self._mms_device=resolve_device(mms_device);self._mms_seed=mms_seed;logger.warning('Loading MMS-TTS model %s on %s — the first run downloads it to the HuggingFace cache and may take a few minutes.',A,self._mms_device);self._mms_model=VitsModel.from_pretrained(A).to(self._mms_device);self._mms_tokenizer=AutoTokenizer.from_pretrained(A)
		if C is not _A:self._mms_model.speaking_rate=C
		if D is not _A:self._mms_model.noise_scale=D
		super().__init__(*E,tts_lang=B,**F)
	@staticmethod
	def _default_model(tts_lang:str)->str:
		A=tts_lang;B=A.split('-')[0].lower();C=_MMS_LANG_CODES.get(B)
		if C is _A:raise TTSError(f"No MMS model mapped for {A!r}. MMS identifies languages by ISO 639-3 code, not the {B!r} used elsewhere. Pass the model explicitly, e.g. mms_model='facebook/mms-tts-fra'. Known: {", ".join(sorted(_MMS_LANG_CODES))}.")
		return _MMS_MODEL_TEMPLATE.format(code=C)
	def _synthesize_wav(self,text:str)->bytes:
		A=self._mms_tokenizer(text,return_tensors='pt').to(self._mms_device)
		if self._mms_seed is not _A:_transformers.set_seed(self._mms_seed)
		with torch.no_grad():B=self._mms_model(**A).waveform
		C=float_to_int16(B[0]);return self._to_wav_bytes(C,self._mms_model.config.sampling_rate)