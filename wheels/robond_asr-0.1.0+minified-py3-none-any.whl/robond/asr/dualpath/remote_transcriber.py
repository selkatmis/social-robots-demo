_G='timeout'
_F='no_speech_prob'
_E='avg_logprob'
_D='error'
_C='audio'
_B=True
_A=None
import logging,os
from typing import Any,Dict,List,Optional,Set,Tuple
import numpy as np
from robond.asr.dualpath.dev_logging import get_dev_log
from robond.asr.dualpath.protocols import SAMPLE_RATE
from robond.asr.dualpath.text_guards import TextGuards
from robond.asr.dualpath.wav import pcm16_to_wav_bytes
from robond.asr.dualpath.whisper_transcriber import SegmentMetrics,TranscriptionResult,_mark_partial_rejection
logger=logging.getLogger(__name__)
dev_log=get_dev_log(__name__)
OPENAI_BASE_URL='https://api.openai.com/v1'
MODEL_GUARDS:Tuple[str,...]=(_E,_F)
_WARMUP_TIMEOUT_S=6e1
_WARNED_SERVERS:Set[Tuple[str,str]]=set()
def reset_capability_warnings()->_A:_WARNED_SERVERS.clear()
class GuardsUnavailableError(RuntimeError):0
def _field(container:Any,name:str)->Tuple[bool,Any]:
	A=container
	if isinstance(A,dict):B=A.get(name)
	else:B=getattr(A,name,_A)
	return B is not _A,B
def _unpack(response:Any)->Tuple[str,Any]:A=response;B=(_field(A,'text')[1]or'').strip();C=_field(A,'segments')[1]or[];return B,C
class RemoteTranscriber:
	def __init__(self,language:str,base_url:Optional[str]=_A,api_key:Optional[str]=_A,model:str='whisper-1',sample_rate:int=SAMPLE_RATE,timeout_s:float=1e1,max_no_speech_prob:float=.6,min_avg_logprob:float=-1.,text_guards:Optional[TextGuards]=_A,require_guards:bool=False,warmup:bool=False,client:Any=_A)->_A:
		C=text_guards;B=language;A=client
		if not B:raise ValueError("language must be a non-empty language code such as 'nl'; auto-detect is deliberately unavailable (design §7.1)")
		self.language=B;self.base_url=base_url or OPENAI_BASE_URL;self.model=model;self.sample_rate=int(sample_rate);self.timeout_s=timeout_s;self.max_no_speech_prob=max_no_speech_prob;self.min_avg_logprob=min_avg_logprob;self.text_guards=C if C is not _A else TextGuards();self.require_guards=require_guards;(self._server_guards):Optional[Tuple[str,...]]=_A;self._client=A if A is not _A else self._make_client(api_key)
		if warmup and A is _A:self._warm_up()
	def transcribe(self,samples:np.ndarray)->str:
		try:return self.transcribe_detailed(samples).text
		except GuardsUnavailableError:raise
		except Exception as A:print(f"[remote-asr] transcription error: {A}",flush=_B);dev_log(_D,f"remote transcription error: {A}");return''
	def transcribe_detailed(self,samples:np.ndarray)->TranscriptionResult:
		J=self._client.audio.transcriptions.create(**self._request_kwargs(samples));H,D=_unpack(J);self._probe_capabilities(D,H);F:List[SegmentMetrics]=[]
		if D:
			I:List[str]=[]
			for(K,L)in enumerate(D):
				B=self._measure(L);E=self._reject_reason(B);B.kept=E is _A;B.reject_reason=E;F.append(B)
				if E is _A:I.append(B.text.strip())
				else:dev_log(_C,f"  seg[{K}] DISCARDED — {E}: '{B.text.strip()}'")
			C=' '.join(A for A in I if A).strip()
		else:C=H
		A=TranscriptionResult(text=C,segments=F,language=self.language)
		if not C:A.reject_reason='all_segments_rejected'if D else'no_text';return A
		G=self.text_guards.check(C)
		if G is not _A:dev_log(_C,'transcript DISCARDED — %s (%d chars)'%(G,len(C)));A.reject_reason=G;A.text='';return A
		_mark_partial_rejection(A,F);return A
	def active_guards(self)->Tuple[str,...]:return tuple(self._server_guards or())+self.text_guards.active_guards()
	@property
	def probed(self)->bool:return self._server_guards is not _A
	def _make_client(self,api_key:Optional[str])->Any:from openai import OpenAI as A;return A(api_key=api_key or os.environ.get('OPENAI_API_KEY'),base_url=self.base_url,timeout=self.timeout_s,max_retries=0)
	def _request_kwargs(self,samples:np.ndarray)->Dict[str,Any]:return{'model':self.model,'file':pcm16_to_wav_bytes(samples,rate=self.sample_rate),'language':self.language,'response_format':'verbose_json',_G:self.timeout_s}
	def _warm_up(self)->_A:
		try:C=np.zeros(self.sample_rate,dtype=np.float32);B=self._request_kwargs(C);B[_G]=max(self.timeout_s,_WARMUP_TIMEOUT_S);D=self._client.audio.transcriptions.create(**B)
		except Exception as A:print(f"[remote-asr] warm-up failed (ignored): {A}",flush=_B);dev_log(_D,f"[remote-asr] warm-up failed (ignored): {A}");return
		E,F=_unpack(D)
		try:self._probe_capabilities(F,E);dev_log(_C,'[remote-asr] warm-up request complete')
		except GuardsUnavailableError as A:print(f"[remote-asr] warm-up: {A} — refusing on the first real decode instead",flush=_B);dev_log(_D,f"[remote-asr] warm-up guard probe: {A}")
	def _probe_capabilities(self,raw_segments:Any,whole_text:str)->_A:
		E=raw_segments;B=', '
		if self._server_guards is not _A:return
		if not E and not whole_text:return
		C=tuple(A for A in MODEL_GUARDS if any(_field(B,A)[0]for B in E));A=tuple(A for A in MODEL_GUARDS if A not in C)
		if A and self.require_guards:raise GuardsUnavailableError('server %r at %s reports no %s — require_guards=True'%(self.model,self.base_url,B.join(A)))
		self._server_guards=C
		if not A:dev_log(_C,'[remote-asr] server %r reports all model guards: %s'%(self.model,B.join(C)));return
		F=self.base_url,self.model
		if F in _WARNED_SERVERS:return
		_WARNED_SERVERS.add(F);H=B.join(self.active_guards())or'none';G=f"[remote-asr] guards active: {H}";D='[remote-asr] guards INACTIVE: %s — server %r returns no segment metadata. Confident-but-wrong transcripts will not be caught.'%(B.join(A),self.model);print(G,flush=_B);print(D,flush=_B);logger.warning(G);logger.warning(D);dev_log(_C,D)
	@staticmethod
	def _measure(raw:Any)->SegmentMetrics:A=raw;return SegmentMetrics(text=_field(A,'text')[1]or'',avg_logprob=_field(A,_E)[1],no_speech_prob=_field(A,_F)[1],compression_ratio=_field(A,'compression_ratio')[1])
	def _reject_reason(self,measured:SegmentMetrics)->Optional[str]:
		A=measured
		if A.no_speech_prob is not _A and A.no_speech_prob>=self.max_no_speech_prob:return f"no_speech_prob({A.no_speech_prob:.2f}>={self.max_no_speech_prob:.2f})"
		if A.avg_logprob is not _A and A.avg_logprob<=self.min_avg_logprob:return f"avg_logprob({A.avg_logprob:.2f}<={self.min_avg_logprob:.2f})"