import io,wave
from typing import Union
import numpy as np
from robond.asr.dualpath.protocols import SAMPLE_RATE
Samples=Union[np.ndarray,list]
def to_pcm16(samples:Samples)->np.ndarray:
	A=np.asarray(samples).reshape(-1)
	if A.dtype==np.int16:return A
	if np.issubdtype(A.dtype,np.integer):return np.clip(A,-32768,32767).astype(np.int16)
	B=A.astype(np.float32,copy=False);return(np.clip(B,-1.,1.)*32767.).astype(np.int16)
def pcm16_to_wav_bytes(samples:Samples,rate:int=SAMPLE_RATE)->io.BytesIO:
	C=to_pcm16(samples);A=io.BytesIO()
	with wave.open(A,'wb')as B:B.setnchannels(1);B.setsampwidth(2);B.setframerate(int(rate));B.writeframes(C.tobytes())
	A.seek(0);A.name='audio.wav';return A
def write_wav(path:str,samples:Samples,rate:int=SAMPLE_RATE)->int:
	A=pcm16_to_wav_bytes(samples,rate=rate).getvalue()
	with open(path,'wb')as B:B.write(A)
	return len(A)