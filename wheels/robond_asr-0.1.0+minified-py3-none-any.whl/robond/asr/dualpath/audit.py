_O='contents_rejected'
_N='sample_rate'
_M='rejected'
_L='runtime'
_K='retention_days'
_J='created'
_I='event'
_H='text'
_G='utf-8'
_F='audio'
_E='session'
_D='delete_after'
_C=False
_B=True
_A=None
import atexit,json,logging,os,queue,tempfile,threading,time
from datetime import datetime,timezone
from enum import Enum
from typing import Any,Dict,Iterable,List,Optional
from robond.asr.dualpath.dev_logging import get_dev_log
from robond.asr.dualpath.protocols import SAMPLE_RATE
from robond.asr.dualpath.segmenter import Segment
from robond.asr.dualpath.wav import write_wav
logger=logging.getLogger(__name__)
dev_log=get_dev_log(__name__)
MANIFEST_NAME='MANIFEST.json'
REJECTED_DIR=_M
REJECTED_CONTENTS='Candidate segments the level gate and onset debounce refused. By selection these are NOT the consenting participant: PA announcements, nearby conversation, ambient speech. Kept as the false-accept half of the segmentation evidence; same retention as the rest of the directory.'
DEFAULT_MAX_BYTES=2000000000
DEFAULT_WRITE_QUEUE=64
_WRITER_JOIN_S=5.
class WriterMode(Enum):THREAD='thread';INLINE='inline'
class _Barrier:
	def __init__(self)->_A:self.reached=threading.Event()
_STOP=object()
def _iso(epoch:float)->str:return datetime.fromtimestamp(epoch,tz=timezone.utc).isoformat()
def _date(epoch:float)->str:return datetime.fromtimestamp(epoch,tz=timezone.utc).date().isoformat()
def _directory_bytes(directory:str)->int:
	A=0
	for(B,E,C)in os.walk(directory):
		for D in C:
			try:A+=os.path.getsize(os.path.join(B,D))
			except OSError:continue
	return A
class AuditTrail:
	def __init__(self,directory:str,*,enabled:bool=_C,consent:bool=_C,event:str='',session:str='',retention_days:int=30,max_bytes:int=DEFAULT_MAX_BYTES,keep_rejected:bool=_B,sample_rate:int=SAMPLE_RATE,clock=time.time,writer:WriterMode=WriterMode.THREAD,write_queue:int=DEFAULT_WRITE_QUEUE)->_A:
		B=clock;self.directory=directory;self.enabled=bool(enabled);self.consent=bool(consent);self.event=event;self.retention_days=int(retention_days);self.max_bytes=int(max_bytes);self.keep_rejected=bool(keep_rejected);self.sample_rate=int(sample_rate);self._clock=B;self.session=session or datetime.fromtimestamp(B(),tz=timezone.utc).strftime('%Y%m%dT%H%M%SZ');(self._runtime):Dict[str,Any]={};self._index=0;self._rejected_index=0;(self._bytes):Optional[int]=_A;self._capped=_C;self._manifest_written=_C;self._collided=_C;self._writer=WriterMode(writer);(self._queue):'queue.Queue'=queue.Queue(int(write_queue));(self._thread):Optional[threading.Thread]=_A;self._guard=threading.Lock();self._at_exit_registered=_C;self.dropped_writes=0
		if self.enabled and not self.consent:A='[audit] recording is ENABLED but consent=False — writing NOTHING. These are participant recordings; set consent=True only once consent has actually been obtained (design §10).';print(A,flush=_B);logger.warning(A);dev_log(_F,A)
		elif self.active:dev_log(_F,'[audit] recording to %s (session %s, retention %d days)'%(self.directory,self.session,self.retention_days))
	@property
	def active(self)->bool:return self.enabled and self.consent
	def describe_runtime(self,**A:Any)->_A:
		with self._guard:self._runtime.update({B:A for(B,A)in A.items()if A is not _A})
	def record(self,segment:Segment,text:str,result:Any=_A,active_guards:Iterable[str]=(),decode_s:Optional[float]=_A,listen_elapsed_s:Optional[float]=_A)->_A:
		if not self.active:return
		self._submit(dict(segment=segment,text=text,result=result,active_guards=tuple(active_guards),subdirectory=_A,index=self._next_index(),decode_s=decode_s,listen_elapsed_s=listen_elapsed_s))
	def record_rejected(self,segment:Segment)->_A:
		if not self.active or not self.keep_rejected:return
		self._submit(dict(segment=segment,text='',result=_A,active_guards=(),subdirectory=REJECTED_DIR,index=self._next_rejected_index()))
	def flush(self,timeout:float=_WRITER_JOIN_S)->bool:
		A=timeout
		if self._writer is WriterMode.INLINE or self._thread is _A:return _B
		B=_Barrier()
		try:self._queue.put(B,timeout=A)
		except queue.Full:return _C
		return B.reached.wait(A)
	def close(self,timeout:float=_WRITER_JOIN_S)->_A:
		A=timeout
		with self._guard:B=self._thread
		if B is _A:return
		self.flush(A)
		try:self._queue.put(_STOP,timeout=A)
		except queue.Full:0
		B.join(A)
		if B.is_alive():logger.warning('[audit] writer thread did not stop within %.1fs; it is a daemon, so it cannot block exit, but writes may be pending.',A);return
		with self._guard:
			if self._thread is B:self._thread=_A
	def _submit(self,job:Dict[str,Any])->_A:
		A=job
		if self._writer is WriterMode.INLINE:self._perform(A);return
		try:self._start_writer();self._queue.put_nowait(A)
		except queue.Full:self._drop(A)
		except Exception as B:self._swallow(B)
	def _drop(self,job:Dict[str,Any])->_A:
		self.dropped_writes+=1
		if self.dropped_writes==1:A='[audit] write queue full (%d) — DROPPING recordings. Storage is not keeping up; the interaction continues, the evidence does not. Later drops are counted in AuditTrail.dropped_writes.'%self._queue.maxsize;logger.warning(A);dev_log(_F,A)
		dev_log(_F,'[audit] dropped write %s-%03d'%(self.session,job['index']))
	def _start_writer(self)->_A:
		with self._guard:
			if self._thread is not _A:return
			self._thread=threading.Thread(target=self._drain,name='dualpath-audit-writer',daemon=_B);self._thread.start()
			if not self._at_exit_registered:self._at_exit_registered=_B;atexit.register(self._at_exit)
	def _at_exit(self)->_A:
		try:self.close(timeout=_WRITER_JOIN_S)
		except Exception:0
	def _drain(self)->_A:
		while _B:
			A=self._queue.get()
			if A is _STOP:return
			if isinstance(A,_Barrier):A.reached.set();continue
			self._perform(A)
	def _perform(self,job:Dict[str,Any])->_A:
		try:self._write(**job)
		except Exception as A:self._swallow(A)
	def _next_index(self)->int:self._index+=1;return self._index
	def _next_rejected_index(self)->int:self._rejected_index+=1;return self._rejected_index
	def _swallow(self,error:Exception)->_A:A=f"[audit] write failed, continuing without it: {error}";logger.warning(A);dev_log('error',A)
	def _write(self,segment:Segment,text:str,result:Any,active_guards:Iterable[str],subdirectory:Optional[str],index:int,decode_s:Optional[float]=_A,listen_elapsed_s:Optional[float]=_A)->_A:
		D=index;C=segment;B=subdirectory
		if self._over_cap():return
		A=self.directory
		if B:A=os.path.join(A,B)
		os.makedirs(A,exist_ok=_B);self._ensure_manifest();E=self._free_stem(A,D);F=os.path.join(A,E+'.wav');H=os.path.join(A,E+'.json');I=self._sidecar(C,text=text,result=result,active_guards=active_guards,index=D,wav_name=os.path.basename(F),rejected=bool(B),decode_s=decode_s,listen_elapsed_s=listen_elapsed_s);G=json.dumps(I,indent=2,ensure_ascii=_C);J=write_wav(F,C.samples,rate=self.sample_rate)
		with open(H,'w',encoding=_G)as K:K.write(G)
		self._bytes=(self._bytes or 0)+J+len(G.encode(_G))
	def _free_stem(self,directory:str,index:int)->str:
		D=index;A=directory;B='%s-%03d'%(self.session,D)
		if not self._stem_taken(A,B):return B
		for F in range(2,1000):
			C='%s-%03d-r%d'%(self.session,D,F)
			if not self._stem_taken(A,C):
				if not self._collided:self._collided=_B;E='[audit] %s already exists in %s — this session name has been used here before. Writing as %s rather than overwriting the earlier recording; pass a distinct session= to keep runs apart.'%(B,A,C);print(E,flush=_B);logger.warning(E)
				return C
		raise OSError('cannot find a free filename for %s in %s'%(B,A))
	@staticmethod
	def _stem_taken(directory:str,stem:str)->bool:A=directory;return os.path.exists(os.path.join(A,stem+'.wav'))or os.path.exists(os.path.join(A,stem+'.json'))
	def _over_cap(self)->bool:
		if self._bytes is _A:self._bytes=_directory_bytes(self.directory)
		if self._bytes<self.max_bytes:return _C
		if not self._capped:self._capped=_B;A='[audit] size cap reached (%d bytes >= %d) in %s — recording STOPPED. Nothing is deleted to make room: the earliest segments are usually the evidence you want.'%(self._bytes,self.max_bytes,self.directory);print(A,flush=_B);logger.warning(A);dev_log(_F,A)
		return _B
	def _ensure_manifest(self)->_A:
		if self._manifest_written:return
		with self._guard:G=dict(self._runtime)
		D=self._clock();A={_I:self.event,_E:self.session,_J:_iso(D),'consent':self.consent,_K:self.retention_days,_D:_date(D+self.retention_days*864e2),_N:self.sample_rate,'max_bytes':self.max_bytes,'contents':'Raw ASR segments (16-bit mono WAV) and per-segment JSON sidecars from the dual-path listener. Participant audio, recorded with consent; delete on or before delete_after.',_L:G}
		if self.keep_rejected:A[_O]=REJECTED_CONTENTS
		E=os.path.join(self.directory,MANIFEST_NAME);A=self._merged_with_existing(E,A);F=json.dumps(A,indent=2,ensure_ascii=_C);H,B=tempfile.mkstemp(prefix=MANIFEST_NAME+'.',suffix='.tmp',dir=self.directory)
		try:
			with os.fdopen(H,'w',encoding=_G)as C:C.write(F);C.flush();os.fsync(C.fileno())
			os.replace(B,E)
		except Exception:
			if os.path.exists(B):os.remove(B)
			raise
		self._manifest_written=_B;self._bytes=(self._bytes or 0)+len(F.encode(_G));dev_log(_F,'[audit] manifest written: delete after %s'%A[_D])
	def _merged_with_existing(self,path:str,manifest:Dict[str,Any])->Dict[str,Any]:
		G='sessions';F=path;B=manifest
		try:
			with open(F,'r',encoding=_G)as H:A=json.load(H)
			if not isinstance(A,dict)or not A.get(_D):raise ValueError('no delete_after')
		except FileNotFoundError:return B
		except Exception as I:C='[audit] %s exists but could not be read (%s) — replacing it. Any earlier session in this directory had no enforceable retention date until now.'%(F,I);print(C,flush=_B);logger.warning(C);return B
		D=dict(A);E=[A for A in A.get(G)or[]if isinstance(A,dict)]
		if not E:E=[{B:A.get(B)for B in(_E,_I,_J,_K,_D,_L)}]
		if B[_E]not in[A.get(_E)for A in E]:E.append({A:B[A]for A in(_E,_I,_J,_K,_D,_L)})
		D[G]=E;D[_D]=min(str(A[_D]),str(B[_D]))
		if self.keep_rejected:D[_O]=REJECTED_CONTENTS
		C='[audit] %s already describes session %r — merging session %r into it. The directory is deleted whole, so it keeps the earliest delete_after of the two: %s.'%(F,A.get(_E),B[_E],D[_D]);logger.info(C);dev_log(_F,C);return D
	def _sidecar(self,segment:Segment,text:str,result:Any,active_guards:Iterable[str],index:int,wav_name:str,rejected:bool,decode_s:Optional[float]=_A,listen_elapsed_s:Optional[float]=_A)->Dict[str,Any]:
		G='gate_threshold_end_dbfs';F='noise_floor_end_dbfs';D=listen_elapsed_s;C=decode_s;A=segment;B:Dict[str,Any]={_E:self.session,_I:self.event,'index':index,_M:rejected,'recorded_at':_iso(self._clock()),'wav':wav_name,_N:self.sample_rate,'start_sample':int(A.start_sample),'end_sample':int(A.end_sample),'duration_s':round(float(A.duration_s),3),'reason':A.reason,'dropped_frames_before':int(A.dropped_frames_before),'dropped_samples_before':int(A.dropped_samples_before),'dropped_s_before':round(A.dropped_samples_before/float(self.sample_rate),3),'noise_floor_dbfs':round(float(A.noise_floor_dbfs),2),'gate_threshold_dbfs':round(float(A.gate_threshold_dbfs),2),F:round(float(getattr(A,F,.0)),2),G:round(float(getattr(A,G,.0)),2),'speech_probs':[round(float(A),4)for A in A.speech_probs],'rms_dbfs':[round(float(A),2)for A in A.rms_dbfs],_H:text,'active_guards':[str(A)for A in active_guards]};B['decode_s']=_A if C is _A else round(float(C),3);B['listen_elapsed_s']=_A if D is _A else round(float(D),3);B['rtf']=self._rtf(A,C);E=self._guard_block(result)
		if E is not _A:B['guards']=E
		return B
	@staticmethod
	def _rtf(segment:Segment,decode_s:Optional[float])->Optional[float]:
		A=decode_s
		if A is _A:return
		B=float(segment.duration_s)
		if B<=.0:return
		return round(float(A)/B,3)
	@staticmethod
	def _guard_block(result:Any)->Optional[Dict[str,Any]]:
		J='language';I='kept';H='compression_ratio';G='no_speech_prob';F='avg_logprob';E='segments';C='reject_reason';B=result
		if B is _A:return
		D:List[Dict[str,Any]]=[]
		for A in getattr(B,E,())or():D.append({_H:getattr(A,_H,''),F:getattr(A,F,_A),G:getattr(A,G,_A),H:getattr(A,H,_A),I:getattr(A,I,_A),C:getattr(A,C,_A)})
		return{J:getattr(B,J,''),_H:getattr(B,_H,''),C:getattr(B,C,_A),E:D}