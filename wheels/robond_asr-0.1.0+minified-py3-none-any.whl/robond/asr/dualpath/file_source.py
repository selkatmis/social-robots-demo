_A=None
import time,wave
from typing import Iterator,Optional
import numpy as np
from robond.asr.dualpath.dev_logging import get_dev_log
from robond.asr.dualpath.protocols import SAMPLE_RATE
dev_log=get_dev_log(__name__)
_BYTES_PER_SAMPLE=2
def read_wav(path:str,expected_rate:Optional[int]=SAMPLE_RATE)->np.ndarray:
	C=expected_rate;B=path
	with wave.open(B,'rb')as A:D=A.getnchannels();E=A.getsampwidth();F=A.getframerate();G=A.getnframes();H=A.readframes(G)
	if D!=1:raise ValueError(f"{B}: {D} channels, need mono — convert at mix time (tools/asr_replay/mix_corpus.py)")
	if E!=_BYTES_PER_SAMPLE:raise ValueError(f"{B}: {E*8}-bit samples, need 16-bit PCM — convert at mix time (tools/asr_replay/mix_corpus.py)")
	if C is not _A and F!=C:raise ValueError(f"{B}: {F} Hz, need {C} Hz — convert at mix time (tools/asr_replay/mix_corpus.py)")
	return np.frombuffer(H,dtype='<i2').astype(np.int16)
class FileAudioSource:
	def __init__(self,path:str,frame_size:int=512,realtime:bool=False,rate:int=SAMPLE_RATE)->_A:
		A=frame_size
		if A<=0:raise ValueError(f"frame_size must be positive, got {A}")
		self.path=path;self.rate=int(rate);self.channels=1;self.frame_size=int(A);self.depth=_BYTES_PER_SAMPLE;self.realtime=bool(realtime);self._samples=read_wav(path,expected_rate=self.rate);self._position=0;self._frame_seconds=float(self.frame_size)/float(self.rate)
	@property
	def total_samples(self)->int:return int(self._samples.size)
	@property
	def duration_s(self)->float:return self.total_samples/float(self.rate)
	@property
	def position(self)->int:return self._position
	@property
	def samples(self)->np.ndarray:return self._samples
	def rewind(self)->_A:self._position=0
	def __enter__(self)->'FileAudioSource':dev_log('audio','file source open: %s at sample %d/%d'%(self.path,self._position,self.total_samples));return self
	def __exit__(self,exc_type,exc_val,exc_tb)->_A:0
	@property
	def audio(self)->Iterator[np.ndarray]:return self._frames()
	def _frames(self)->Iterator[np.ndarray]:
		A=time.monotonic()
		while self._position<self._samples.size:
			B=min(self._position+self.frame_size,self._samples.size);D=self._samples[self._position:B];self._position=B
			if self.realtime:
				A+=self._frame_seconds;C=A-time.monotonic()
				if C>.0:time.sleep(C)
			yield D.reshape(-1,1)