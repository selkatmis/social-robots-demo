# Vendored Silero VAD model

`silero_vad_16k_op15.onnx` — the speech detector used by
`robond.asr.dualpath.detectors.SileroDetector`.

| | |
|---|---|
| Origin | [`silero-vad`](https://github.com/snakers4/silero-vad) **6.2.1**, file `silero_vad/data/silero_vad_16k_op15.onnx` of the PyPI wheel `silero_vad-6.2.1-py3-none-any.whl` |
| Licence | MIT — full text in `LICENSE.silero-vad` next to this file |
| Size | 1 289 603 bytes |
| SHA-256 | `7ed98ddbad84ccac4cd0aeb3099049280713df825c610a8ed34543318f1b2c49` |
| Extracted | 2026-08-14 |

## Why the file is vendored rather than pip-installed

The `silero-vad` package declares `torch>=1.12.0` and `torchaudio>=0.12.0` as
*unconditional* dependencies (`onnxruntime` is only an `onnx-cpu` extra), so
there is no torch-free way to install it: 4.6 GB of venv against 134 MB for
`numpy + onnxruntime`, on festival laptops that also carry a Whisper model. Its
ONNX wrapper rejects numpy arrays anyway. See design §14 (spike WP-0.1) in
`docs/plans/festival-dual-path-asr.md`.

## Why this file and not `silero_vad.onnx`

16 kHz-only and opset 15 (widest `onnxruntime` compatibility), 1.3 MB rather
than 2.3 MB, and bit-identical output to the opset-16 file at 16 kHz. We only
ever run 16 kHz.

## Staleness

A vendored model never updates itself. When upstream publishes a new release,
re-check this file against it and update the table above — the version, hash and
extraction date are the whole audit trail.

## Refreshing it

```bash
pip download silero-vad==6.2.1 --no-deps --only-binary=:all: -d /tmp/sv
unzip -o /tmp/sv/silero_vad-6.2.1-py3-none-any.whl \
    "silero_vad/data/silero_vad_16k_op15.onnx" \
    "silero_vad-6.2.1.dist-info/licenses/LICENSE" -d /tmp/sv
```

(`--no-deps` is what keeps torch out of this.)
