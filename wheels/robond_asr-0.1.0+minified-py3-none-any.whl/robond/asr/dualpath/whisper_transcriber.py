_G='no_speech_prob'
_F='avg_logprob'
_E='language'
_D=False
_C=True
_B='audio'
_A=None
from dataclasses import dataclass,field
from typing import Any,Dict,List,Optional,Tuple
import numpy as np
from robond.asr.dualpath.dev_logging import get_dev_log
from robond.asr.dualpath.protocols import SAMPLE_RATE
from robond.asr.dualpath.text_guards import TextGuards
dev_log=get_dev_log(__name__)
_MODELS:Dict[Tuple[str,str,str,Optional[int]],Any]={}
def _get_model(model_size:str,device:str,compute_type:str,cpu_threads:Optional[int]=_A)->Any:
	E=cpu_threads;D=compute_type;C=device;B=model_size;F=B,C,D,E;A=_MODELS.get(F)
	if A is not _A:return A
	from faster_whisper import WhisperModel as G;print(f"[whisper] loading model '{B}' on {C} ({D}) — first call only...",flush=_C);H={}if E is _A else{'cpu_threads':int(E)};A=G(B,device=C,compute_type=D,**H);_MODELS[F]=A;print('[whisper] model ready.',flush=_C);return A
def clear_model_cache()->_A:_MODELS.clear()
@dataclass
class SegmentMetrics:text:str;avg_logprob:Optional[float]=_A;no_speech_prob:Optional[float]=_A;compression_ratio:Optional[float]=_A;kept:bool=_C;reject_reason:Optional[str]=_A
@dataclass
class TranscriptionResult:text:str;segments:List[SegmentMetrics]=field(default_factory=list);language:str='';reject_reason:Optional[str]=_A
PARTIAL_REJECTION_PREFIX='partial'
def _mark_partial_rejection(result:TranscriptionResult,metrics:List[SegmentMetrics])->_A:
	B=metrics;A=result
	if not A.text:return
	C=[A for A in B if not A.kept]
	if not C:return
	A.reject_reason='%s(%d/%d segments dropped)'%(PARTIAL_REJECTION_PREFIX,len(C),len(B));dev_log(_B,'transcript PARTIAL — %s (%d chars)'%(A.reject_reason,len(A.text)))
class WhisperTranscriber:
	def __init__(self,language:str,model_size:str='small',device:str='cpu',compute_type:str='int8',cpu_threads:Optional[int]=_A,beam_size:int=5,max_no_speech_prob:float=.6,min_avg_logprob:float=-1.,max_compression_ratio:float=2.4,condition_on_previous_text:bool=_D,text_guards:TextGuards=_A,warmup:bool=_D,model:Any=_A)->_A:
		G=text_guards;F=cpu_threads;E=compute_type;D=device;C=model_size;B=language;A=model
		if not B:raise ValueError("language must be a non-empty language code such as 'nl'; auto-detect is deliberately unavailable (design §7.1)")
		self.language=B;self.model_size=C;self.device=D;self.compute_type=E;self.cpu_threads=F;self.beam_size=beam_size;self.max_no_speech_prob=max_no_speech_prob;self.min_avg_logprob=min_avg_logprob;self.max_compression_ratio=max_compression_ratio;self.condition_on_previous_text=condition_on_previous_text;self.text_guards=G if G is not _A else TextGuards(max_compression_ratio=_A);self._model=A if A is not _A else _get_model(C,D,E,F)
		if warmup and A is _A:self._warm_up()
	def _warm_up(self)->_A:
		try:A=np.zeros(SAMPLE_RATE,dtype=np.float32);self._model.transcribe(A,**self._decode_kwargs());dev_log(_B,'Whisper warm-up decode complete')
		except Exception as B:dev_log('error',f"Whisper warm-up failed (ignored): {B}")
	def transcribe(self,samples:np.ndarray)->str:
		try:return self.transcribe_detailed(samples).text
		except Exception as A:print(f"[whisper] transcription error: {A}",flush=_C);dev_log('error',f"Whisper transcription error: {A}");return''
	def transcribe_detailed(self,samples:np.ndarray)->TranscriptionResult:
		I=self._as_float32(samples);J,K=self._model.transcribe(I,**self._decode_kwargs());E=list(J);L=getattr(K,_E,'')or'';dev_log(_B,f"Whisper segments: {len(E)} | language={self.language} (reported {L})");F:List[SegmentMetrics]=[];H:List[str]=[]
		for(M,N)in enumerate(E):
			B=self._measure(N);C=self._reject_reason(B);B.kept=C is _A;B.reject_reason=C;F.append(B)
			if C is _A:H.append(B.text.strip())
			else:dev_log(_B,f"  seg[{M}] DISCARDED — {C}: '{B.text.strip()}'")
		D=' '.join(A for A in H if A).strip();A=TranscriptionResult(text=D,segments=F,language=self.language)
		if not D:
			if E:A.reject_reason='all_segments_rejected'
			else:A.reject_reason='no_segments'
			return A
		G=self.text_guards.check(D)
		if G is not _A:dev_log(_B,'transcript DISCARDED — %s (%d chars)'%(G,len(D)));A.reject_reason=G;A.text='';return A
		_mark_partial_rejection(A,F);return A
	def active_guards(self)->Tuple[str,...]:
		A=[_F,_G]
		if self.max_compression_ratio is not _A:A.append('compression_ratio(model)')
		return tuple(A)+self.text_guards.active_guards()
	def _decode_kwargs(self)->Dict[str,Any]:return{_E:self.language,'beam_size':self.beam_size,'condition_on_previous_text':self.condition_on_previous_text,'vad_filter':_D}
	@staticmethod
	def _as_float32(samples:np.ndarray)->np.ndarray:
		A=np.asarray(samples)
		if A.dtype==np.int16:return A.astype(np.float32)/32768.
		return A.astype(np.float32,copy=_D)
	@staticmethod
	def _measure(segment:Any)->SegmentMetrics:A=segment;return SegmentMetrics(text=getattr(A,'text','')or'',avg_logprob=getattr(A,_F,_A),no_speech_prob=getattr(A,_G,_A),compression_ratio=getattr(A,'compression_ratio',_A))
	def _reject_reason(self,measured:SegmentMetrics)->Optional[str]:
		A=measured
		if A.no_speech_prob is not _A and A.no_speech_prob>=self.max_no_speech_prob:return f"no_speech_prob({A.no_speech_prob:.2f}>={self.max_no_speech_prob:.2f})"
		if A.avg_logprob is not _A and A.avg_logprob<=self.min_avg_logprob:return f"avg_logprob({A.avg_logprob:.2f}<={self.min_avg_logprob:.2f})"
		if self.max_compression_ratio is not _A and A.compression_ratio is not _A and A.compression_ratio>self.max_compression_ratio:return f"compression_ratio({A.compression_ratio:.2f}>{self.max_compression_ratio:.2f})"