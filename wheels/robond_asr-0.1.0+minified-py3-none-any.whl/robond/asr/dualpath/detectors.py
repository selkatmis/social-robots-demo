_A=None
import os
from typing import Any,Dict,Optional,Tuple
import numpy as np
from robond.asr.dualpath.dev_logging import get_dev_log
from robond.asr.dualpath.protocols import SAMPLE_RATE
dev_log=get_dev_log(__name__)
MODEL_FILENAME='silero_vad_16k_op15.onnx'
_STATE_SHAPE=2,1,128
_WINDOW_SAMPLES=512
_CONTEXT_SAMPLES=64
_SESSIONS:Dict[Tuple[str,Tuple[str,...]],Any]={}
_DEFAULT_PROVIDERS='CPUExecutionProvider',
def model_path()->str:return os.path.join(os.path.dirname(os.path.abspath(__file__)),'data',MODEL_FILENAME)
def _load_session(path:str,providers:Tuple[str,...])->Any:
	D=providers;A=path;E=A,D;B=_SESSIONS.get(E)
	if B is not _A:return B
	import onnxruntime as F
	if not os.path.exists(A):raise FileNotFoundError(f"Silero model not found at {A}. It ships as package data of robond.asr.dualpath; a source checkout needs data/{MODEL_FILENAME}.")
	C=F.SessionOptions();C.intra_op_num_threads=1;C.inter_op_num_threads=1;dev_log('audio',f"loading Silero VAD model from {A}");B=F.InferenceSession(A,sess_options=C,providers=list(D));_SESSIONS[E]=B;return B
class SileroDetector:
	window_samples:int=_WINDOW_SAMPLES;context_samples:int=_CONTEXT_SAMPLES
	def __init__(self,session:Any=_A,path:str=_A,sample_rate:int=SAMPLE_RATE,warmup:int=3)->_A:
		C=warmup;B=session;A=sample_rate
		if A!=SAMPLE_RATE:raise ValueError(f"SileroDetector only supports {SAMPLE_RATE} Hz (the vendored model is 16 kHz-only), got {A}")
		self.path=path or model_path();self.sample_rate=int(A);self._session=B if B is not _A else _load_session(self.path,_DEFAULT_PROVIDERS);self._sr=np.array(self.sample_rate,dtype=np.int64);self._state=np.zeros(_STATE_SHAPE,dtype=np.float32);self._context=np.zeros(self.context_samples,dtype=np.float32)
		if C>0:
			D=np.zeros(self.window_samples,dtype=np.float32)
			for E in range(int(C)):self.predict(D)
			self.reset()
	def predict(self,chunk:np.ndarray)->float:
		A=np.asarray(chunk,dtype=np.float32).reshape(-1)
		if A.size!=self.window_samples:raise ValueError(f"SileroDetector expects exactly {self.window_samples} samples (32 ms at {SAMPLE_RATE} Hz), got {A.size}")
		B=np.concatenate((self._context,A));C={'input':np.ascontiguousarray(B.reshape(1,B.size),dtype=np.float32),'state':self._state,'sr':self._sr};D,E=self._session.run(_A,C);self._state=np.asarray(E,dtype=np.float32);self._context=B[-self.context_samples:].astype(np.float32);return float(np.asarray(D).reshape(-1)[0])
	def reset(self)->_A:self._state=np.zeros(_STATE_SHAPE,dtype=np.float32);self._context=np.zeros(self.context_samples,dtype=np.float32)
def clear_session_cache()->_A:_SESSIONS.clear()