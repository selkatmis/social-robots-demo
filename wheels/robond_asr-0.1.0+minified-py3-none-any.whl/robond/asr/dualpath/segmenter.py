_F='error'
_E=False
_D=.0
_C='audio'
_B=True
_A=None
import logging,math,queue,threading,time
from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass,field
from enum import Enum
from typing import Any,Callable,Iterator,List,Optional,Tuple
import numpy as np
from robond.asr.dualpath.dev_logging import get_dev_log
from robond.asr.dualpath.protocols import SAMPLE_RATE,AudioSourceLike,AudioTransform,SpeechDetector
from robond.asr.dualpath.transforms import Compose,HighPassFilter,LowPassFilter,identity
dev_log=get_dev_log(__name__)
logger=logging.getLogger(__name__)
_MAX_TRACE=2048
_RMS_EPSILON=1e-09
_BYTES_PER_SAMPLE=2
DEFAULT_CAPTURE_QUEUE_S=8.
DEFAULT_CAPTURE_QUEUE_FRAMES=250
_CAPTURE_POLL_S=.05
_CAPTURE_JOIN_S=1.
class CaptureMode(Enum):INLINE='inline';LIVE='live';AUTO='auto'
def _rms_dbfs(chunk:np.ndarray)->float:
	A=np.asarray(chunk,dtype=np.float64)
	if A.size==0:return 2e1*math.log10(_RMS_EPSILON)
	B=float(np.sqrt(np.mean(A*A)));return 2e1*math.log10(max(B,_RMS_EPSILON))
def _gate_band_filter(config:'SegmenterConfig')->Any:
	A=config;B:List[Any]=[]
	if A.gate_band_low_hz>_D:B.append(HighPassFilter(A.gate_band_low_hz,A.sample_rate));B.append(HighPassFilter(A.gate_band_low_hz,A.sample_rate))
	if A.gate_band_high_hz<A.sample_rate/2.:B.append(LowPassFilter(A.gate_band_high_hz,A.sample_rate))
	return Compose(B)if B else identity
@dataclass
class SegmenterConfig:
	sample_rate:int=SAMPLE_RATE;speech_threshold:float=.5;speech_threshold_release:float=.35;gate_margin_db:float=1e1;gate_release_margin_db:float=6.;absolute_min_dbfs:float=-58.;absolute_max_dbfs:float=-15.;floor_window_s:float=5.;floor_rise_tau_s:float=.5;floor_fall_tau_s:float=5.;gate_band_low_hz:float=3e2;gate_band_high_hz:float=65e2;floor_init_dbfs:float=-38.;min_speech_ms:int=120;candidate_tolerance_ms:int=100;hangover_ms:int=1500;post_roll_ms:int=300;max_segment_ms:int=15000;pre_roll_ms:int=300;settle_ms:int=300;ring_buffer_s:float=3e1
	def __post_init__(self)->_A:
		if self.sample_rate<=0:raise ValueError(f"sample_rate must be positive, got {self.sample_rate}")
		for B in('min_speech_ms','candidate_tolerance_ms','hangover_ms','post_roll_ms','max_segment_ms','pre_roll_ms','settle_ms'):
			if getattr(self,B)<0:raise ValueError(f"{B} must be >= 0, got {getattr(self,B)}")
		if self.max_segment_ms<=0:raise ValueError(f"max_segment_ms must be positive, got {self.max_segment_ms}")
		if self.ring_buffer_s<=_D:raise ValueError(f"ring_buffer_s must be positive, got {self.ring_buffer_s}")
		if self.floor_rise_tau_s<=_D or self.floor_fall_tau_s<=_D:raise ValueError('floor time constants must be positive')
		if self.floor_window_s<=_D:raise ValueError(f"floor_window_s must be positive, got {self.floor_window_s}")
		if self.absolute_max_dbfs<=self.absolute_min_dbfs:raise ValueError('absolute_max_dbfs (%.1f) must exceed absolute_min_dbfs (%.1f): they are the ceiling and floor of the same gate threshold'%(self.absolute_max_dbfs,self.absolute_min_dbfs))
		C=self.sample_rate/2.
		if self.gate_band_low_hz<_D:raise ValueError(f"gate_band_low_hz must be >= 0, got {self.gate_band_low_hz}")
		if self.gate_band_high_hz<=self.gate_band_low_hz:raise ValueError(f"gate_band_high_hz must exceed gate_band_low_hz, got {self.gate_band_high_hz} <= {self.gate_band_low_hz}")
		if self.gate_band_low_hz>=C:raise ValueError(f"gate_band_low_hz must be < {C}, got {self.gate_band_low_hz}")
		(self.min_speech_samples):int=self._samples(self.min_speech_ms);(self.candidate_tolerance_samples):int=self._samples(self.candidate_tolerance_ms);(self.hangover_samples):int=self._samples(self.hangover_ms);(self.post_roll_samples):int=self._samples(self.post_roll_ms);(self.max_segment_samples):int=self._samples(self.max_segment_ms);(self.pre_roll_samples):int=self._samples(self.pre_roll_ms);(self.settle_samples):int=self._samples(self.settle_ms);(self.ring_buffer_samples):int=max(1,int(round(self.ring_buffer_s*self.sample_rate)))
		if self.pre_roll_samples<self.min_speech_samples:raise ValueError('pre_roll_ms (%d) must be >= min_speech_ms (%d): a debounce rejection discards up to min_speech_ms of real speech, and only the pre-roll recovers it'%(self.pre_roll_ms,self.min_speech_ms))
		A=self.pre_roll_samples+self.max_segment_samples+self.hangover_samples+self.post_roll_samples
		if self.ring_buffer_samples<A:logger.warning('ring_buffer_s=%.1f holds %d samples but a worst-case segment needs %d (%.1fs) — long segments will be truncated at the buffer head. Raise ring_buffer_s to at least %.1f.',self.ring_buffer_s,self.ring_buffer_samples,A,A/float(self.sample_rate),A/float(self.sample_rate))
	def _samples(self,milliseconds:float)->int:return int(round(milliseconds*self.sample_rate/1e3))
@dataclass
class Segment:
	samples:np.ndarray;start_sample:int;end_sample:int;reason:str;speech_probs:List[float]=field(default_factory=list);rms_dbfs:List[float]=field(default_factory=list);noise_floor_dbfs:float=_D;gate_threshold_dbfs:float=_D;noise_floor_end_dbfs:float=_D;gate_threshold_end_dbfs:float=_D;sample_rate:int=SAMPLE_RATE;dropped_frames_before:int=0;dropped_samples_before:int=0
	@property
	def duration_s(self)->float:return(self.end_sample-self.start_sample)/float(self.sample_rate)
class _RingBuffer:
	def __init__(self,capacity_samples:int)->_A:
		A=capacity_samples
		if A<=0:raise ValueError(f"capacity must be positive, got {A}")
		self._capacity=int(A);self._buffer=np.zeros(self._capacity,dtype=np.int16);self._write_pos=0;self._clamped=_E
	@property
	def capacity(self)->int:return self._capacity
	@property
	def write_pos(self)->int:return self._write_pos
	def write(self,samples:np.ndarray)->_A:
		A=np.asarray(samples).reshape(-1)
		if A.dtype!=np.int16:A=A.astype(np.int16)
		B=A.size
		if B==0:return
		E=self._write_pos;self._write_pos+=B
		if B>self._capacity:E+=B-self._capacity;A=A[-self._capacity:];B=self._capacity
		C=E%self._capacity;D=C+B
		if D<=self._capacity:self._buffer[C:D]=A
		else:F=self._capacity-C;self._buffer[C:]=A[:F];self._buffer[:D-self._capacity]=A[F:]
	def skip(self,count:int)->_A:
		A=count;A=int(A)
		if A<=0:return
		B=min(A,self._capacity);self.write(np.zeros(B,dtype=np.int16));self._write_pos+=A-B
	def read(self,start:int,end:int)->np.ndarray:
		B=end;A=start;A=int(A);B=int(B);C=max(0,self._write_pos-self._capacity)
		if A<C:
			if not self._clamped:self._clamped=_B;logger.warning('ring buffer: a segment started %d samples before the oldest one still held — its head is being cut off. Increase ring_buffer_s (the ring holds %d samples).',C-A,self._capacity)
			dev_log(_C,'ring buffer: segment start %d predates the oldest held sample %d — clamping (increase ring_buffer_s)'%(A,C));A=C
		B=min(B,self._write_pos)
		if B<=A:return np.zeros(0,dtype=np.int16)
		D=A%self._capacity;E=B%self._capacity
		if E>D:return self._buffer[D:E].copy()
		return np.concatenate((self._buffer[D:],self._buffer[:E]))
class _NoiseFloor:
	def __init__(self,config:SegmenterConfig,window_samples:int)->_A:A=config;self._config=A;self._chunk_seconds=float(window_samples)/float(A.sample_rate);B=max(1,int(round(A.floor_window_s/self._chunk_seconds)));(self._levels):deque=deque(maxlen=B);self._min_chunks=max(1,min(B,int(round(1./self._chunk_seconds))));self._current=float(A.floor_init_dbfs);self._primed=_E;self._ceiling_warned=_E;self._alpha_rise=1.-math.exp(-self._chunk_seconds/A.floor_rise_tau_s);self._alpha_fall=1.-math.exp(-self._chunk_seconds/A.floor_fall_tau_s)
	@property
	def dbfs(self)->float:return self._current
	@property
	def ready(self)->bool:return len(self._levels)>=self._min_chunks
	def reprime(self)->_A:self._levels.clear();self._primed=_E;self._ceiling_warned=_E;self._current=float(self._config.floor_init_dbfs)
	def update(self,rms_dbfs:float)->_A:
		B=float(rms_dbfs)
		if not math.isfinite(B):dev_log(_C,'noise floor: ignoring a non-finite chunk level');return
		self._levels.append(B)
		if not self.ready:return
		A=float(np.median(np.asarray(self._levels,dtype=np.float64)))
		if not self._primed:self._primed=_B;self._current=A;return
		C=self._alpha_rise if A>self._current else self._alpha_fall;self._current+=C*(A-self._current)
	def threshold_dbfs(self,margin_db:float)->float:
		A=self._config;B=max(self._current+margin_db,A.absolute_min_dbfs)
		if B<=A.absolute_max_dbfs:return B
		if not self._ceiling_warned:self._ceiling_warned=_B;logger.warning('noise floor %.1f dBFS puts the gate at %.1f dBFS — clamped to the %.1f dBFS ceiling. The room is loud enough that an unclamped gate would refuse a child outright.',self._current,B,A.absolute_max_dbfs)
		return A.absolute_max_dbfs
class _InlineFrames:
	dropped_frames=0;dropped_samples=0
	def __init__(self,frames:Iterator[np.ndarray])->_A:self._frames=frames
	def pull(self,deadline:float)->Optional[np.ndarray]:return next(self._frames)
	def take_dropped(self)->Tuple[int,int]:return 0,0
	def close(self,source:Optional[AudioSourceLike]=_A)->_A:0
class _Reader(threading.Thread):
	def __init__(self,frames:Iterator[np.ndarray],maxsize:int=DEFAULT_CAPTURE_QUEUE_FRAMES,poll_s:float=_CAPTURE_POLL_S,join_s:float=_CAPTURE_JOIN_S)->_A:
		A=maxsize;super().__init__(daemon=_B,name='dualpath-capture')
		if int(A)<=0:raise ValueError(f"capture queue must hold at least one frame, got {A}")
		self._frames=frames;(self._queue):'queue.Queue'=queue.Queue(int(A));self._stopping=threading.Event();self._finished=threading.Event();self._poll_s=float(poll_s);self._join_s=float(join_s);(self._error):Optional[Exception]=_A;self.dropped_frames=0;self.dropped_samples=0;(self._pending):Tuple[int,int]=(0,0);(self._last):Tuple[int,int]=(0,0)
	def run(self)->_A:
		try:
			for A in self._frames:
				if self._stopping.is_set():return
				try:self._queue.put_nowait((A,self._pending))
				except queue.Full:self._drop(A)
				else:self._pending=0,0
		except Exception as B:self._error=B
		finally:self._finished.set()
	def _drop(self,frame:np.ndarray)->_A:
		B,C=self._pending;A=int(np.asarray(frame).size);self._pending=B+1,C+A;self.dropped_frames+=1;self.dropped_samples+=A
		if self.dropped_frames==1:logger.warning('capture queue full (%d frames) — dropping audio. The decode is not keeping up with the microphone; segments after this one carry dropped_frames_before.',self._queue.maxsize)
		dev_log(_C,'capture drop: %d frames / %d samples so far'%(self.dropped_frames,self.dropped_samples))
	def pull(self,deadline:float)->Optional[np.ndarray]:
		while _B:
			try:A,self._last=self._queue.get(timeout=self._poll_s)
			except queue.Empty:0
			else:return A
			if self._finished.is_set()and self._queue.empty():
				if self._error is not _A:B,self._error=self._error,_A;raise B
				raise StopIteration
			if self._stopping.is_set():raise StopIteration
			if time.monotonic()>=deadline:return
	def take_dropped(self)->Tuple[int,int]:A,self._last=self._last,(0,0);return A
	def close(self,source:Optional[AudioSourceLike]=_A)->_A:
		self._stopping.set();self.join(timeout=self._join_s)
		if not self.is_alive():return
		A=getattr(source,'stop',_A)
		if callable(A):
			dev_log(_C,'capture thread still in a source read — asking the source to stop')
			try:A()
			except Exception as B:dev_log(_F,'audio source stop() raised during capture shutdown: %s'%B)
		self.join(timeout=self._join_s)
		if self.is_alive():logger.warning('capture thread did not stop within %.1fs — it is a daemon, so it cannot block interpreter exit, but the audio source is still being read and the next session will open it again.',2.*self._join_s)
class _State(Enum):IDLE='idle';PENDING='pending';SPEECH='speech'
class _Session:
	def __init__(self,config:SegmenterConfig,detector:SpeechDetector,vad_transform:AudioTransform,floor:_NoiseFloor,frames:Any,on_rejected:Optional[Callable[[Segment],_A]]=_A,silence_timeout_s:Optional[float]=_A)->_A:
		E=vad_transform;D=detector;C=silence_timeout_s;B=floor;A=config;self._config=A;self._detector=D;self._vad_transform=E;self._floor=B;self._frames=frames;self._on_rejected=on_rejected;self._window_samples=int(D.window_samples);self._ring=_RingBuffer(A.ring_buffer_samples);(self._silence_limit_samples):Optional[int]=_A if C is _A else max(1,int(round(float(C)*A.sample_rate)));self._silence_samples=0;self._silence_stopped=_E
		if self._silence_limit_samples is not _A and self._silence_limit_samples<self._window_samples:logger.warning('silence_timeout_s=%s is %d samples, under one %d-sample detector window — every turn will time out before anyone can answer. Did you pass milliseconds?',C,self._silence_limit_samples,self._window_samples)
		self._gate_on_output=bool(getattr(E,'gate_on_output',_E));self._gate_band=_gate_band_filter(A);self._window_start=A.settle_samples;self._checked_first_frame=_E;self._measure_only=_E;self._state=_State.IDLE;self._candidate_start=0;self._speech_start=0;self._last_speech=0;(self._probs):List[float]=[];(self._rms):List[float]=[];self._open_floor_dbfs=B.dbfs;self._open_threshold_dbfs=B.threshold_dbfs(A.gate_margin_db);self._gap_frames=0;self._gap_samples=0;(self._pending_error):Optional[BaseException]=_A;(self._pending_endpoint):Optional[int]=_A;(self._deferred_gap):Tuple[int,int]=(0,0)
	@property
	def state(self)->str:return self._state.value
	@property
	def samples_written(self)->int:return self._ring.write_pos
	@property
	def noise_floor_dbfs(self)->float:return self._floor.dbfs
	@property
	def dropped_frames(self)->int:return int(self._frames.dropped_frames)
	@property
	def dropped_samples(self)->int:return int(self._frames.dropped_samples)
	@property
	def silence_timed_out(self)->bool:return self._silence_stopped
	@property
	def silence_samples(self)->int:return self._silence_samples
	def next_segment(self,deadline:float)->Optional[Segment]:
		B=deadline
		if self._pending_error is not _A:A,self._pending_error=self._pending_error,_A;raise A
		while _B:
			if self._pending_endpoint is not _A:return self._emit_at_gap()
			C=self._drain_windows()
			if C is not _A:return C
			if self._silence_limit_samples is not _A and self._state is _State.IDLE and self._silence_samples>=self._silence_limit_samples:self._silence_stopped=_B;dev_log(_C,'silence budget exhausted: %.2fs of captured non-speech with no transcript'%(self._silence_samples/float(self._config.sample_rate)));return
			if time.monotonic()>=B:return
			try:D=self._frames.pull(B)
			except StopIteration:
				if self._state is _State.SPEECH:return self._emit(self._ring.write_pos,'eof')
				return
			except Exception as A:
				if self._state is _State.SPEECH:self._pending_error=A;logger.error('audio source failed mid-utterance (%r) — emitting the %.2fs already captured; the failure is re-raised on the next read',A,(self._ring.write_pos-self._speech_start)/float(self._config.sample_rate));return self._emit(self._ring.write_pos,_F)
				raise
			if D is _A:continue
			self._accept(D)
	def observe(self,deadline:float)->_A:
		A=deadline;self._measure_only=_B
		try:
			while _B:
				self._drain_windows()
				if time.monotonic()>=A:return
				try:B=self._frames.pull(A)
				except StopIteration:return
				if B is _A:continue
				self._accept(B)
		finally:self._measure_only=_E
	def _accept(self,frame:np.ndarray)->_A:
		A=frame;C,B=self._frames.take_dropped()
		if B:self._note_gap(C,B)
		self._check_frame_dtype(A);self._ring.write(A)
	def _note_gap(self,lost_frames:int,lost_samples:int)->_A:
		B=lost_frames;A=lost_samples
		if self._state is _State.SPEECH and A>=self._config.hangover_samples:self._pending_endpoint=self._ring.write_pos
		self._ring.skip(A);self._window_start=max(self._window_start,self._ring.write_pos)
		if self._pending_endpoint is not _A:self._deferred_gap=self._deferred_gap[0]+B,self._deferred_gap[1]+A
		else:self._gap_frames+=B;self._gap_samples+=A
		dev_log(_C,'capture gap: %d frames / %d samples (%.2fs) — stream position advanced, hole zeroed'%(B,A,A/float(self._config.sample_rate)))
	def _check_frame_dtype(self,frame:np.ndarray)->_A:
		if self._checked_first_frame:return
		self._checked_first_frame=_B;A=np.asarray(frame).dtype
		if A==np.int16:return
		raise ValueError('audio source yields %s frames; the segmenter needs int16 PCM. A float source in [-1, 1] would be truncated to digital silence.'%A)
	def _drain_windows(self)->Optional[Segment]:
		B=self._window_samples
		while self._ring.write_pos-self._window_start>=B:
			A=self._window_start;D=self._ring.read(A,A+B);self._window_start=A+B;C=self._process_window(D,A)
			if C is not _A:return C
	def _process_window(self,window:np.ndarray,window_start:int)->Optional[Segment]:
		G=window_start;E=window;A=self._config;B=G+int(E.size);H=E.astype(np.float32)/32768.;I=self._vad_transform(H);C=float(self._detector.predict(I));L=I if self._gate_on_output else H;D=_rms_dbfs(self._gate_band(L))
		if C<A.speech_threshold_release:self._floor.update(D)
		if self._measure_only:return
		J=self._state is not _State.IDLE;M=A.speech_threshold_release if J else A.speech_threshold;N=A.gate_release_margin_db if J else A.gate_margin_db;K=self._floor.threshold_dbfs(N);F=C>=M and D>K
		if self._state is _State.IDLE:
			if not F:
				if self._silence_limit_samples is not _A:self._silence_samples+=int(E.size)
				return
			self._state=_State.PENDING;self._candidate_start=G;self._last_speech=B;self._probs=[];self._rms=[];self._open_floor_dbfs=self._floor.dbfs;self._open_threshold_dbfs=K;self._trace(C,D);return
		self._trace(C,D)
		if self._state is _State.PENDING:
			if F:self._last_speech=B
			elif B-self._last_speech>=A.candidate_tolerance_samples:self._reject(B);return
			if self._last_speech-self._candidate_start>=A.min_speech_samples:self._state=_State.SPEECH;self._speech_start=self._candidate_start
			return
		if F:self._last_speech=B
		elif B-self._last_speech>=A.hangover_samples:return self._emit(B,'hangover')
		if B-self._speech_start>=A.max_segment_samples:return self._emit(B,'cap')
	def _emit_at_gap(self)->Segment:A,self._pending_endpoint=self._pending_endpoint,_A;B=self._emit(int(A),'gap');C,D=self._deferred_gap;self._deferred_gap=0,0;self._gap_frames+=C;self._gap_samples+=D;return B
	def _trace(self,probability:float,rms_dbfs:float)->_A:
		if len(self._probs)<_MAX_TRACE:self._probs.append(probability);self._rms.append(rms_dbfs)
	def _emit(self,now:int,reason:str)->Segment:E=reason;A=self._config;C=max(0,self._speech_start-A.pre_roll_samples);D=min(self._last_speech+A.post_roll_samples,now);F=self._ring.read(C,D);B=Segment(samples=F,start_sample=C,end_sample=D,reason=E,speech_probs=list(self._probs),rms_dbfs=list(self._rms),noise_floor_dbfs=self._open_floor_dbfs,gate_threshold_dbfs=self._open_threshold_dbfs,noise_floor_end_dbfs=self._floor.dbfs,gate_threshold_end_dbfs=self._floor.threshold_dbfs(A.gate_release_margin_db),sample_rate=A.sample_rate,dropped_frames_before=self._gap_frames,dropped_samples_before=self._gap_samples);dev_log(_C,'segment %s: [%d, %d) = %.2fs, floor=%.1f dBFS gate=%.1f dBFS'%(E,C,D,B.duration_s,B.noise_floor_dbfs,B.gate_threshold_dbfs));self._close_candidate();return B
	def _reject(self,now:int)->_A:
		A=now;B=self._config;C=max(0,self._candidate_start-B.pre_roll_samples);D=Segment(samples=self._ring.read(C,A),start_sample=C,end_sample=A,reason='debounce',speech_probs=list(self._probs),rms_dbfs=list(self._rms),noise_floor_dbfs=self._open_floor_dbfs,gate_threshold_dbfs=self._open_threshold_dbfs,noise_floor_end_dbfs=self._floor.dbfs,gate_threshold_end_dbfs=self._floor.threshold_dbfs(B.gate_release_margin_db),sample_rate=B.sample_rate,dropped_frames_before=self._gap_frames,dropped_samples_before=self._gap_samples);dev_log(_C,'candidate rejected after %d samples (< min_speech_ms)'%(A-self._candidate_start))
		if self._silence_limit_samples is not _A:self._silence_samples+=max(0,A-self._candidate_start)
		self._close_candidate(keep_gap=_B)
		if self._on_rejected is not _A:
			try:self._on_rejected(D)
			except Exception as E:dev_log(_F,'on_rejected raised: %s'%E)
	def _close_candidate(self,keep_gap:bool=_E)->_A:
		self._state=_State.IDLE;self._probs=[];self._rms=[]
		if not keep_gap:self._gap_frames=0;self._gap_samples=0
class Segmenter:
	def __init__(self,audio_source:AudioSourceLike,detector:SpeechDetector,vad_transform:Optional[AudioTransform]=_A,config:Optional[SegmenterConfig]=_A,on_rejected:Optional[Callable[[Segment],_A]]=_A,capture:CaptureMode=CaptureMode.AUTO,capture_queue_frames:Optional[int]=_A,capture_queue_s:float=DEFAULT_CAPTURE_QUEUE_S)->_A:
		E=capture_queue_s;D=capture_queue_frames;C=config;B=vad_transform;A=detector;self._audio_source=audio_source;self._detector=A;self._vad_transform=B if B is not _A else identity;self._config=C if C is not _A else SegmenterConfig();self._on_rejected=on_rejected;self._capture=CaptureMode(capture);self._capture_queue_frames=_A if D is _A else int(D);self._capture_queue_s=float(E)
		if self._capture_queue_s<=_D:raise ValueError('capture_queue_s must be positive, got %r'%(E,))
		self._window_samples=int(A.window_samples);self._floor=_NoiseFloor(self._config,int(A.window_samples));self._dropped_frames=0;self._dropped_samples=0
	@property
	def config(self)->SegmenterConfig:return self._config
	@property
	def capture(self)->CaptureMode:return self._capture
	def capture_mode_for(self,source:AudioSourceLike)->CaptureMode:
		if self._capture is not CaptureMode.AUTO:return self._capture
		if getattr(source,'realtime',_B):return CaptureMode.LIVE
		return CaptureMode.INLINE
	@property
	def dropped_frames(self)->int:return self._dropped_frames
	@property
	def dropped_samples(self)->int:return self._dropped_samples
	@property
	def noise_floor_dbfs(self)->float:return self._floor.dbfs
	@property
	def floor_ready(self)->bool:return self._floor.ready
	@property
	def gate_threshold_dbfs(self)->float:return self._floor.threshold_dbfs(self._config.gate_margin_db)
	def calibrate(self,seconds:float=3.)->float:
		A=seconds;self._floor.reprime()
		with self.session()as B:B.observe(deadline=time.monotonic()+float(A))
		dev_log(_C,'calibrated noise floor: %.1f dBFS (gate at %.1f dBFS, %s)'%(self._floor.dbfs,self.gate_threshold_dbfs,'measured'if self.floor_ready else'STILL THE PRIOR'))
		if not self.floor_ready:logger.warning('calibrate(%.1fs) measured no usable room tone: fewer than ~1 s of detector-non-speech chunks arrived, so the estimate is still the %.1f dBFS prior. Something was talking — a PA, a crowd, the robot. Re-run it in silence.',float(A),self._config.floor_init_dbfs)
		return self._floor.dbfs
	@contextmanager
	def session(self,silence_timeout_s:Optional[float]=_A)->Iterator[_Session]:
		with self._audio_source as D:
			B=D if D is not _A else self._audio_source;self._check_format(B);self._detector.reset();E=getattr(self._vad_transform,'reset',_A)
			if callable(E):E()
			F=self.capture_mode_for(B);C=self._open_frames(B,F)
			try:A=self._build_session(C,silence_timeout_s)
			except BaseException:C.close(B);raise
			dev_log(_C,'segmenter session open — capture=%s floor=%.1f dBFS (%s)'%(F.value,self._floor.dbfs,'calibrated'if self._floor.ready else'initial'))
			try:yield A
			finally:
				C.close(B);self._dropped_frames+=A.dropped_frames;self._dropped_samples+=A.dropped_samples
				if A.dropped_frames:logger.info('capture dropped %d frames (%.2fs) this session — the decode is not keeping up with the source',A.dropped_frames,A.dropped_samples/float(self._config.sample_rate))
				dev_log(_C,'segmenter session closed after %d samples (%d dropped)'%(A.samples_written,A.dropped_frames))
	def _build_session(self,frames:Any,silence_timeout_s:Optional[float]=_A)->_Session:return _Session(config=self._config,detector=self._detector,vad_transform=self._vad_transform,floor=self._floor,frames=frames,on_rejected=self._on_rejected,silence_timeout_s=silence_timeout_s)
	def _open_frames(self,source:AudioSourceLike,mode:CaptureMode)->Any:
		A=source;B=iter(A.audio)
		if mode is CaptureMode.INLINE:return _InlineFrames(B)
		C=_Reader(B,maxsize=self._queue_depth_for(A));C.start();return C
	def _queue_depth_for(self,source:AudioSourceLike)->int:
		if self._capture_queue_frames is not _A:return self._capture_queue_frames
		A=int(getattr(source,'frame_size',0)or self._window_samples);B=max(1,int(round(self._capture_queue_s*self._config.sample_rate/A)));dev_log(_C,'capture queue: %.1fs = %d frames of %d samples'%(self._capture_queue_s,B,A));return B
	def _check_format(self,source:AudioSourceLike)->_A:
		B=source;A=getattr(B,'rate',_A)
		if A is _A:raise ValueError("audio source declares no 'rate'; the segmenter needs %d Hz and cannot check a rate that is not stated"%self._config.sample_rate)
		A=int(A);C=int(getattr(B,'channels',1));D=int(getattr(B,'depth',_BYTES_PER_SAMPLE))
		if A!=self._config.sample_rate:raise ValueError('audio source rate is %d Hz, segmenter needs %d Hz'%(A,self._config.sample_rate))
		if C!=1:raise ValueError('audio source has %d channels, segmenter needs mono'%C)
		if D!=_BYTES_PER_SAMPLE:raise ValueError('audio source depth is %d bytes/sample, segmenter needs 16-bit PCM'%D)