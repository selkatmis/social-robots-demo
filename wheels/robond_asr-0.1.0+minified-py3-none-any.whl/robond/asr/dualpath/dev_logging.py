import logging
from typing import Callable
try:from dev_logger import dev_log as _dev_log
except(ImportError,OSError):
	def _dev_log(category,message):0
def get_dev_log(name:str)->Callable[[str,str],None]:
	C=logging.getLogger(name)
	def A(category:str,message:str)->None:
		B=message;A=category
		try:_dev_log(A,B)
		except Exception:C.debug('[%s] (dev_logger hook raised) %s',A,B)
		else:C.debug('[%s] %s',A,B)
	return A