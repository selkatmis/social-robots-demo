_N='unknown ASR profile %r — valid profiles are %s'
_M='remote'
_L='whisper-1'
_K='reject_reason'
_J='device'
_I='cuda'
_H='beam_size'
_G='compute_type'
_F='model_size'
_E='cpu'
_D='error'
_C='audio'
_B=True
_A=None
import logging,os,threading,time
from contextlib import contextmanager
from typing import Any,Dict,Iterator,Optional,Tuple
import numpy as np
from robond.asr.dualpath.dev_logging import get_dev_log
from robond.core.listener_backend import UNSET as _UNSET,ListenerBackend
from robond.asr.dualpath.remote_transcriber import GuardsUnavailableError
from robond.asr.dualpath.protocols import AudioSourceLike,AudioTransform,SpeechDetector,Transcriber
from robond.asr.dualpath.segmenter import DEFAULT_CAPTURE_QUEUE_S,CaptureMode,Segment,Segmenter,SegmenterConfig
from robond.asr.dualpath.transforms import PEAK,Compose,HighPassFilter,PeakNormalize,dc_removal
dev_log=get_dev_log(__name__)
logger=logging.getLogger(__name__)
TIMEOUT_SENTINEL='[TIMEOUT]'
def _check_silence_timeout(value:Any)->Optional[float]:
	A=value
	if A is _A:return
	B=float(A)
	if B<=.0:raise ValueError('silence_timeout must be positive or None, got %r — None is how you turn it off'%(A,))
	return B
PROFILE_ENV_VAR='ROBOND_ASR_PROFILE'
OVMS_URL_ENV_VAR='ROBOND_ASR_OVMS_URL'
OVMS_MODEL_ENV_VAR='ROBOND_ASR_OVMS_MODEL'
DEFAULT_OVMS_BASE_URL='http://127.0.0.1:8000/v1'
DEFAULT_OVMS_MODEL='OpenVINO/whisper-small-fp16-ov'
REMOTE_URL_ENV_VAR='ROBOND_ASR_REMOTE_URL'
REMOTE_MODEL_ENV_VAR='ROBOND_ASR_REMOTE_MODEL'
REMOTE_API_KEY_ENV_VAR='ROBOND_ASR_REMOTE_API_KEY'
DEFAULT_REMOTE_BASE_URL='http://127.0.0.1:8080/v1'
DEFAULT_REMOTE_MODEL=_L
DEFAULT_PROFILE=_E
PROFILES:Tuple[str,...]=(_I,_E,'ovms','openai',_M)
LOCAL_PROFILES:Dict[str,Dict[str,Any]]={_I:{_F:'medium',_J:_I,_G:'float16',_H:5},_E:{_F:'small',_J:_E,_G:'int8',_H:5}}
def _default_vad_transform()->AudioTransform:return HighPassFilter(1e2)
def _default_asr_transform(statistic:str=PEAK)->AudioTransform:return Compose([dc_removal,PeakNormalize(statistic=statistic)])
class DualPathListenerBackend(ListenerBackend):
	def __init__(self,audio_source:AudioSourceLike,detector:SpeechDetector,transcriber:Transcriber,vad_transform:Optional[AudioTransform]=_A,asr_transform:Optional[AudioTransform]=_A,config:Optional[SegmenterConfig]=_A,audit:Any=_A,profile:Optional[str]=_A,capture:CaptureMode=CaptureMode.AUTO,capture_queue_frames:Optional[int]=_A,capture_queue_s:float=DEFAULT_CAPTURE_QUEUE_S,silence_timeout:Optional[float]=_A)->_A:C=asr_transform;B=vad_transform;A=detector;self._silence_timeout=_check_silence_timeout(silence_timeout);self._transcriber=transcriber;self._detector=A;self._busy=threading.Lock();self._capture_failures=0;self._asr_transform=C if C is not _A else _default_asr_transform();self._audit=audit;self._segmenter=Segmenter(audio_source=audio_source,detector=A,vad_transform=B if B is not _A else _default_vad_transform(),config=config,on_rejected=self._on_rejected,capture=capture,capture_queue_frames=capture_queue_frames,capture_queue_s=capture_queue_s);self._profile=profile;self._align_sample_rates();self._describe_runtime()
	def _align_sample_rates(self)->_A:
		A=self._segmenter.config.sample_rate
		for(C,D)in(('audit trail',self._audit),('transcriber',self._transcriber)):
			B=getattr(D,'sample_rate',_A)
			if B is _A or int(B)==A:continue
			logger.warning("%s was built for %d Hz but the segmenter captures at %d Hz — using the segmenter's rate. They are the same audio.",C,int(B),A)
			try:D.sample_rate=A
			except Exception as E:logger.warning("could not correct the %s's sample rate: %r",C,E)
	def _describe_runtime(self)->_A:
		if self._audit is _A:return
		C=getattr(self._audit,'describe_runtime',_A)
		if not callable(C):return
		B=self._transcriber;A=self._segmenter.config
		try:C(profile=self._profile,transcriber=type(B).__name__,model=getattr(B,_F,_A)or getattr(B,'model',_A),device=getattr(B,_J,_A),compute_type=getattr(B,_G,_A),beam_size=getattr(B,_H,_A),base_url=getattr(B,'base_url',_A),language=getattr(B,'language',_A),detector=type(self._detector).__name__,sample_rate=A.sample_rate,hangover_ms=A.hangover_ms,post_roll_ms=A.post_roll_ms,pre_roll_ms=A.pre_roll_ms,min_speech_ms=A.min_speech_ms,max_segment_ms=A.max_segment_ms,gate_margin_db=A.gate_margin_db,gate_release_margin_db=A.gate_release_margin_db,absolute_min_dbfs=A.absolute_min_dbfs,absolute_max_dbfs=A.absolute_max_dbfs,floor_init_dbfs=A.floor_init_dbfs,speech_threshold=A.speech_threshold)
		except Exception as D:dev_log(_D,f"audit.describe_runtime raised: {D}")
	@property
	def segmenter(self)->Segmenter:return self._segmenter
	@property
	def noise_floor_dbfs(self)->float:return self._segmenter.noise_floor_dbfs
	@contextmanager
	def _exclusive(self,what:str)->Iterator[_A]:
		if not self._busy.acquire(blocking=False):raise RuntimeError("%s while another call is already in progress: the detector's RNN state and the noise floor are shared across calls, and turns are assumed strictly alternating (design §13 non-goal 1)."%what)
		try:yield
		finally:self._busy.release()
	def calibrate(self,seconds:float=3.)->float:
		B=seconds
		with self._exclusive('calibrate()'):print(f"[mic] calibrating noise floor ({B:.0f}s of room tone — robot silent, nobody speaking)...",flush=_B);A=self._segmenter.calibrate(B)
		C=self._segmenter.gate_threshold_dbfs
		if self._segmenter.floor_ready:print(f"[mic] noise floor: {A:.1f} dBFS (gate at {C:.1f} dBFS)",flush=_B)
		else:print(f"[mic] NO USABLE ROOM TONE — nothing was measured, the gate is still on the {A:.1f} dBFS prior (at {C:.1f} dBFS). Something was talking. Re-run this in silence.",flush=_B)
		return A
	def listen(self,timeout:int=20,silence_timeout:Any=_UNSET)->str:
		A=silence_timeout;B=self._silence_timeout if A is _UNSET else _check_silence_timeout(A)
		with self._exclusive('listen()'):return self._listen(timeout,B)
	def _listen(self,timeout:int,silence_timeout:Optional[float])->str:
		B=silence_timeout;A=timeout;print(f"[mic] listening... (timeout: {A}s)",flush=_B);dev_log(_C,'listen() start — timeout=%ss floor=%.1f dBFS'%(A,self._segmenter.noise_floor_dbfs))
		if B is not _A:dev_log(_C,'silence timeout armed: %.1fs of captured non-speech ends the call'%B)
		C=time.monotonic();D=C+A
		try:E=self._capture(C,D,B)
		except GuardsUnavailableError:raise
		except ValueError:raise
		except Exception as F:return self._capture_failed(F)
		self._capture_failures=0;return E
	def _capture(self,started:float,deadline:float,silence_timeout:Optional[float]=_A)->str:
		D=deadline
		with self._segmenter.session(silence_timeout_s=silence_timeout)as E:
			while _B:
				if time.monotonic()>=D:return self._timeout('total timeout elapsed')
				A=E.next_segment(D)
				if A is _A:
					if E.silence_timed_out:return self._timeout('silence timeout: no speech captured')
					return self._timeout('no speech segment before the deadline')
				dev_log(_C,'segment %s: %.2fs, floor=%.1f dBFS gate=%.1f dBFS'%(A.reason,A.duration_s,A.noise_floor_dbfs,A.gate_threshold_dbfs));B,C,F=self._decode(A);G=time.monotonic()-started;self._record(A,B,C,decode_s=F,listen_elapsed_s=G);self._log_turn(A,B,C,F,G)
				if B:
					print(f"[mic] heard: '{B}'",flush=_B);H=getattr(C,_K,_A)
					if H:print(f"[mic] NOTE transcript is incomplete ({H}) — a decoder segment was guard-rejected between the words above",flush=_B)
					return B
				I=D-time.monotonic();dev_log(_C,'empty transcription (%s) — retrying (%.1fs left)'%(getattr(C,_K,_A)or'no detail',I))
	def start(self)->_A:0
	def stop(self)->_A:
		if not self._busy.acquire(blocking=False):logger.warning('stop() called while listen() or calibrate() is in progress — skipping the detector reset rather than corrupting the turn in flight. Harmless: the next session resets it anyway.');return
		try:
			A=getattr(self._detector,'reset',_A)
			if callable(A):A()
		except Exception as B:logger.warning('detector.reset() raised during stop(): %r — the next session resets it again anyway.',B)
		finally:self._busy.release()
	def _capture_failed(self,error:BaseException)->str:
		A=error;self._capture_failures+=1;print(f"[mic] AUDIO CAPTURE FAILED: {A} — this turn is lost",flush=_B);logger.error('turn=TIMEOUT why=capture_failed consecutive=%d error=%r floor=%.1fdBFS gate=%.1fdBFS',self._capture_failures,A,self._segmenter.noise_floor_dbfs,self._segmenter.gate_threshold_dbfs,exc_info=_B)
		if self._capture_failures>1:logger.error('the audio source has now failed %d times in a row — this is a dead or disconnected microphone, not a quiet room. Every turn until it is fixed returns %r.',self._capture_failures,TIMEOUT_SENTINEL)
		print(f"[mic] heard: '{TIMEOUT_SENTINEL}'",flush=_B);return TIMEOUT_SENTINEL
	@property
	def capture_failures(self)->int:return self._capture_failures
	def _timeout(self,why:str)->str:print(f"[mic] heard: '{TIMEOUT_SENTINEL}'",flush=_B);dev_log(_C,f"{why} → TIMEOUT");logger.info('turn=TIMEOUT why=%r floor=%.1fdBFS gate=%.1fdBFS',why,self._segmenter.noise_floor_dbfs,self._segmenter.gate_threshold_dbfs);return TIMEOUT_SENTINEL
	def _log_turn(self,segment:Segment,text:str,result:Any,decode_s:float,elapsed_s:float)->_A:C=decode_s;A=segment;B=A.duration_s;logger.info('turn: reason=%s duration=%.2fs decode=%.2fs elapsed=%.2fs rtf=%s floor=%.1fdBFS gate=%.1fdBFS chars=%d reject=%s dropped=%d',A.reason,B,C,elapsed_s,'%.2f'%(C/B)if B>0 else'n/a',A.noise_floor_dbfs,A.gate_threshold_dbfs,len(text),getattr(result,_K,_A)or'-',A.dropped_frames_before)
	def _decode(self,segment:Segment)->Tuple[str,Any,float]:
		C=segment;D=time.monotonic();E=getattr(self._transcriber,'transcribe_detailed',_A)
		try:
			F=self._asr_transform(C.samples.astype(np.float32)/32768.)
			if callable(E):B=E(F);A=(B.text or'').strip()
			else:B=_A;A=(self._transcriber.transcribe(F)or'').strip()
		except GuardsUnavailableError:raise
		except Exception as G:print(f"[dual-path] transcription error: {G}",flush=_B);dev_log(_D,f"transcription error: {G}");return'',_A,time.monotonic()-D
		H=time.monotonic()-D;dev_log(_C,'decoded %.2fs of audio in %.2fs → %s'%(C.duration_s,H,'%d chars'%len(A)if A else'[empty]'));return A,B,H
	def _record(self,segment:Segment,text:str,result:Any,decode_s:Optional[float]=_A,listen_elapsed_s:Optional[float]=_A)->_A:
		if self._audit is _A:return
		try:self._audit.record(segment,text,result=result,active_guards=self._active_guards(),decode_s=decode_s,listen_elapsed_s=listen_elapsed_s)
		except Exception as A:dev_log(_D,f"audit.record raised: {A}")
	def _on_rejected(self,segment:Segment)->_A:
		if self._audit is _A:return
		try:self._audit.record_rejected(segment)
		except Exception as A:dev_log(_D,f"audit.record_rejected raised: {A}")
	def _active_guards(self)->Tuple[str,...]:
		A=getattr(self._transcriber,'active_guards',_A)
		if A is _A:return()
		try:
			if callable(A):A=A()
			if isinstance(A,str):return A,
			return tuple(str(A)for A in A)
		except Exception as B:dev_log(_D,f"active_guards unreadable: {B}");return()
def resolve_profile(profile:Optional[str]=_A)->str:
	A=profile or os.environ.get(PROFILE_ENV_VAR)or DEFAULT_PROFILE;A=A.strip().lower()
	if A not in PROFILES:raise ValueError(_N%(A,', '.join(repr(A)for A in PROFILES)))
	return A
def _build_transcriber(profile:str,language:str,model:Optional[str]=_A,beam_size:Optional[int]=_A,compute_type:Optional[str]=_A,cpu_threads:Optional[int]=_A)->Transcriber:
	L='not-used';J=cpu_threads;I=compute_type;H=beam_size;F=language;C=model;A=profile
	if A not in PROFILES:raise ValueError(_N%(A,', '.join(repr(A)for A in PROFILES)))
	if A in LOCAL_PROFILES:
		from robond.asr.dualpath.whisper_transcriber import WhisperTranscriber as M;D=dict(LOCAL_PROFILES[A])
		if C is not _A:D[_F]=C
		if H is not _A:D[_H]=int(H)
		if I is not _A:D[_G]=I
		if J is not _A:D['cpu_threads']=int(J)
		return M(F,**D)
	try:from robond.asr.dualpath.remote_transcriber import RemoteTranscriber as G
	except ImportError as K:raise ImportError('profile %r needs RemoteTranscriber, which is unavailable: %s'%(A,K))from K
	if A=='ovms':B=os.environ.get(OVMS_URL_ENV_VAR)or DEFAULT_OVMS_BASE_URL;E=C or os.environ.get(OVMS_MODEL_ENV_VAR)or DEFAULT_OVMS_MODEL;print("[dual-path] profile 'ovms': avg_logprob and no_speech_prob guards are INACTIVE — OVMS returns no per-segment metadata. compression_ratio(text), phrases and min_length remain. Confident-but-wrong transcripts will not be caught.",flush=_B);dev_log(_C,"profile 'ovms' selected — model-internal guards inactive, server=%s model=%s"%(B,E));return G(F,base_url=B,model=E,api_key=L)
	if A==_M:B=os.environ.get(REMOTE_URL_ENV_VAR)or DEFAULT_REMOTE_BASE_URL;E=C or os.environ.get(REMOTE_MODEL_ENV_VAR)or DEFAULT_REMOTE_MODEL;print("[dual-path] profile 'remote': avg_logprob and no_speech_prob guards are REQUIRED — the server at %s must return them per segment or the first response raises."%B,flush=_B);dev_log(_C,"profile 'remote' selected — require_guards on, server=%s model=%s"%(B,E));return G(F,base_url=B,model=E,api_key=os.environ.get(REMOTE_API_KEY_ENV_VAR)or L,require_guards=_B,warmup=_B)
	return G(F,model=C or _L)
def make_festival_backend(audio_source:AudioSourceLike,language:str='nl',profile:Optional[str]=_A,detector:Optional[SpeechDetector]=_A,audit:Any=_A,silence_timeout:Optional[float]=_A,**E:Any)->DualPathListenerBackend:
	D=language;A=detector;B=resolve_profile(profile);C=SegmenterConfig(**E)
	if A is _A:from robond.asr.dualpath.detectors import SileroDetector as F;A=F()
	G=_build_transcriber(B,D);dev_log(_C,'festival backend: profile=%s language=%s hangover=%dms gate_margin=%.1fdB'%(B,D,C.hangover_ms,C.gate_margin_db));return DualPathListenerBackend(audio_source=audio_source,detector=A,transcriber=G,config=C,audit=audit,profile=B,silence_timeout=silence_timeout)