_C=None
_B=1.
_A=.0
import math
from typing import Sequence,Tuple
import numpy as np
from robond.asr.dualpath.protocols import SAMPLE_RATE,AudioTransform
_SILENCE_PEAK=1e-06
class HighPassFilter:
	gate_on_output=True
	def __init__(self,cutoff_hz:float=1e2,sample_rate:int=SAMPLE_RATE,q:float=.707)->_C:
		B=sample_rate;A=cutoff_hz
		if A<=_A or A>=B/2.:raise ValueError(f"cutoff_hz must be in (0, {B/2.}), got {A}")
		if q<=_A:raise ValueError(f"q must be positive, got {q}")
		self.cutoff_hz=float(A);self.sample_rate=int(B);self.q=float(q);self._b0,self._b1,self._b2,self._a1,self._a2=self._design(self.cutoff_hz,self.sample_rate,self.q);self._z1=_A;self._z2=_A
	@staticmethod
	def _design(cutoff_hz:float,sample_rate:int,q:float)->Tuple[float,float,float,float,float]:C=2.*math.pi*cutoff_hz/sample_rate;B=math.cos(C);D=math.sin(C)/(2.*q);E=(_B+B)/2.;F=-(_B+B);G=(_B+B)/2.;A=_B+D;H=-2.*B;I=_B-D;return E/A,F/A,G/A,H/A,I/A
	def __call__(self,x:np.ndarray)->np.ndarray:
		A=np.asarray(x,dtype=np.float32);F=np.empty(A.shape,dtype=np.float32);H,I,J=self._b0,self._b1,self._b2;K,L=self._a1,self._a2;B,C=self._z1,self._z2
		for G in range(A.shape[0]):D=float(A[G]);E=H*D+B;B=I*D-K*E+C;C=J*D-L*E;F[G]=E
		self._z1,self._z2=B,C;return F
	def reset(self)->_C:self._z1=_A;self._z2=_A
class LowPassFilter:
	def __init__(self,cutoff_hz:float=65e2,sample_rate:int=SAMPLE_RATE,q:float=.707)->_C:
		B=sample_rate;A=cutoff_hz
		if A<=_A or A>=B/2.:raise ValueError(f"cutoff_hz must be in (0, {B/2.}), got {A}")
		if q<=_A:raise ValueError(f"q must be positive, got {q}")
		self.cutoff_hz=float(A);self.sample_rate=int(B);self.q=float(q);self._b0,self._b1,self._b2,self._a1,self._a2=self._design(self.cutoff_hz,self.sample_rate,self.q);self._z1=_A;self._z2=_A
	@staticmethod
	def _design(cutoff_hz:float,sample_rate:int,q:float)->Tuple[float,float,float,float,float]:C=2.*math.pi*cutoff_hz/sample_rate;B=math.cos(C);D=math.sin(C)/(2.*q);E=(_B-B)/2.;F=_B-B;G=(_B-B)/2.;A=_B+D;H=-2.*B;I=_B-D;return E/A,F/A,G/A,H/A,I/A
	def __call__(self,x:np.ndarray)->np.ndarray:
		A=np.asarray(x,dtype=np.float32);F=np.empty(A.shape,dtype=np.float32);H,I,J=self._b0,self._b1,self._b2;K,L=self._a1,self._a2;B,C=self._z1,self._z2
		for G in range(A.shape[0]):D=float(A[G]);E=H*D+B;B=I*D-K*E+C;C=J*D-L*E;F[G]=E
		self._z1,self._z2=B,C;return F
	def reset(self)->_C:self._z1=_A;self._z2=_A
def dc_removal(x:np.ndarray)->np.ndarray:
	A=np.asarray(x,dtype=np.float32)
	if A.size==0:return A
	return(A-float(A.mean(dtype=np.float64))).astype(np.float32)
PEAK='peak'
RMS='rms'
STATISTICS=PEAK,RMS
class PeakNormalize:
	def __init__(self,target_dbfs:float=-3.,max_gain:float=8.,statistic:str=PEAK,target_rms_dbfs:float=-2e1,ceiling_dbfs:float=-_B)->_C:
		B=statistic;A=max_gain
		if A<=_A:raise ValueError(f"max_gain must be positive, got {A}")
		if B not in STATISTICS:raise ValueError(f"statistic must be one of {STATISTICS}, got {B!r}")
		self.target_dbfs=float(target_dbfs);self.max_gain=float(A);self.statistic=B;self.target_rms_dbfs=float(target_rms_dbfs);self.ceiling_dbfs=float(ceiling_dbfs)
	def __call__(self,x:np.ndarray)->np.ndarray:
		A=np.asarray(x,dtype=np.float32)
		if A.size==0:return A
		B=float(np.max(np.abs(A)))
		if B<=_SILENCE_PEAK:return A
		if self.statistic==RMS:C=self._rms_gain(A,B)
		else:C=min(1e1**(self.target_dbfs/2e1)/B,self.max_gain)
		return np.clip(A*C,-_B,_B).astype(np.float32)
	def _rms_gain(self,samples:np.ndarray,peak:float)->float:A=float(np.sqrt(np.mean(np.asarray(samples,dtype=np.float64)**2)));B=1e1**((self.target_rms_dbfs-2e1*math.log10(max(A,1e-09)))/2e1);C=1e1**(self.ceiling_dbfs/2e1)/peak;return min(B,self.max_gain,C)
class Compose:
	def __init__(self,transforms:Sequence[AudioTransform])->_C:self.transforms=tuple(transforms)
	@property
	def gate_on_output(self)->bool:return bool(self.transforms)and all(getattr(A,'gate_on_output',False)for A in self.transforms)
	def __call__(self,x:np.ndarray)->np.ndarray:
		for A in self.transforms:x=A(x)
		return x
	def reset(self)->_C:
		for B in self.transforms:
			A=getattr(B,'reset',_C)
			if callable(A):A()
def identity(x:np.ndarray)->np.ndarray:return x