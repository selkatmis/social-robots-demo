_A=None
import zlib
from dataclasses import dataclass,field
from typing import Optional,Tuple
_EDGE_CHARS=' \t\r\n.,!?;:-–—"\'“”‘’()[]…'
DEFAULT_HALLUCINATION_PHRASES:Tuple[str,...]=('ondertiteling door de amara.org gemeenschap','ondertiteling door','ondertiteld door','bedankt voor het kijken','abonneer je op','tot de volgende keer','thank you for watching','thanks for watching','subtitles by the amara.org community','subtitles by','subscribe to my channel','please subscribe','amara.org')
def compression_ratio(text:str)->float:
	A=text.encode('utf-8')
	if not A:return .0
	return len(A)/len(zlib.compress(A))
def _normalize(text:str)->str:A=' '.join(text.split());return A.strip(_EDGE_CHARS).casefold().strip(_EDGE_CHARS)
def _is_boundary(char:str)->bool:return not(char.isalnum()or char=="'")
def _matches_phrase(normalized:str,phrase:str)->bool:
	D=False;C=True;B=normalized;A=phrase
	if not A:return D
	if B==A:return C
	if B.startswith(A)and _is_boundary(B[len(A)]):return C
	if B.endswith(A)and _is_boundary(B[-len(A)-1]):return C
	return D
@dataclass
class TextGuards:
	max_compression_ratio:Optional[float]=2.4;min_chars:int=1;phrases:Tuple[str,...]=field(default=DEFAULT_HALLUCINATION_PHRASES)
	def __post_init__(self)->_A:self._normalized_phrases=tuple(_normalize(A)for A in self.phrases if _normalize(A))
	def check(self,text:str)->Optional[str]:
		F='empty';A=text
		if A is _A:return F
		B=_normalize(A)
		if not B:return F
		C=sum(1 for A in B if A.isalnum())
		if C<self.min_chars:return f"too_short({C}<{self.min_chars})"
		for D in self._normalized_phrases:
			if _matches_phrase(B,D):return f"hallucination_phrase({D!r})"
		if self.max_compression_ratio is not _A:
			E=compression_ratio(A)
			if E>self.max_compression_ratio:return f"compression_ratio({E:.2f}>{self.max_compression_ratio:.2f})"
	def active_guards(self)->Tuple[str,...]:
		A=[]
		if self.max_compression_ratio is not _A:A.append('compression_ratio(text)')
		if self.phrases:A.append('phrases')
		if self.min_chars>0:A.append('min_length')
		return tuple(A)