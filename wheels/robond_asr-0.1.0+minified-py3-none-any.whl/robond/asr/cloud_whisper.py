_D='whisper-1'
_C=None
_B=True
_A='audio'
import io,os,time,wave
from typing import Any
import numpy as np
try:from dev_logger import dev_log
except ImportError:
	def dev_log(cat,msg):0
from cltl.backend.spi.audio import AudioSource
from robond.core.listener_backend import UNSET,ListenerBackend
SAMPLE_RATE=16000
FRAME_SIZE=480
FRAME_BYTES=FRAME_SIZE*2
SILENCE_MS=1500
SILENCE_FRAMES=SILENCE_MS//30
MAX_NO_SPEECH_PROB=.6
MIC_SOFTWARE_GAIN=2.
DEFAULT_MODEL=_D
def _frames_to_wav_file(frames:list,gain:float=1.)->io.BytesIO:
	C=np.frombuffer(b''.join(frames),dtype=np.int16)
	if gain!=1.:C=np.clip(C.astype(np.float32)*gain,-32768,32767).astype(np.int16)
	A=io.BytesIO()
	with wave.open(A,'wb')as B:B.setnchannels(1);B.setsampwidth(2);B.setframerate(SAMPLE_RATE);B.writeframes(C.tobytes())
	A.seek(0);A.name='audio.wav';return A
class OpenAIWhisperListenerBackend(ListenerBackend):
	_client=_C
	@classmethod
	def _get_client(cls,api_key:str=_C):
		if cls._client is _C:from openai import OpenAI as A;cls._client=A(api_key=api_key or os.environ.get('OPENAI_API_KEY'))
		return cls._client
	def __init__(self,audio_source:AudioSource,model:str=DEFAULT_MODEL,whisper_language:str=_C,api_key:str=_C):import webrtcvad as A;self._audio_source=audio_source;self._model=model;self._whisper_language=whisper_language;self._vad=A.Vad(1);self._get_client(api_key)
	def listen(self,timeout:int=20,silence_timeout:Any=UNSET)->str:
		E='[TIMEOUT]';D="[mic] heard: '[TIMEOUT]'";C=timeout;self._ignore_silence_timeout(silence_timeout);print(f"[mic] listening... (timeout: {C}s)",flush=_B);dev_log(_A,f"listen() start — timeout={C}s lang={self._whisper_language}");time.sleep(.1);F=time.time()+C
		while _B:
			G=F-time.time()
			if G<=0:print(D,flush=_B);dev_log(_A,'total timeout elapsed → TIMEOUT');return E
			K=time.time();A=self._record_from_source(G);H=time.time()-K
			if not A:print(D,flush=_B);dev_log(_A,f"no speech detected after {H:.1f}s → TIMEOUT");return E
			L=len(A)*.03;dev_log(_A,f"recorded {len(A)} frames = {L:.2f}s in {H:.1f}s real time");M=time.time();I=self._transcribe(A);N=time.time()-M;B=I.strip()if I else'';dev_log(_A,f"OpenAI ({self._model}) took {N:.2f}s → result='{B or"[empty]"}'")
			if B:print(f"[mic] heard: '{B}'",flush=_B);return B
			J=F-time.time();dev_log(_A,f"noise burst / empty transcription — retrying ({J:.1f}s remaining)")
			if J<=0:print(D,flush=_B);return E
	def _record_from_source(self,timeout:float)->list:
		E=time.time()+timeout;B=[];C=0;D=False
		with self._audio_source as F:
			for G in F.audio:
				if time.time()>=E:break
				A=G.flatten().astype(np.int16).tobytes()
				if len(A)<FRAME_BYTES:continue
				A=A[:FRAME_BYTES]
				if self._vad.is_speech(A,SAMPLE_RATE):D=_B;C=0;B.append(A)
				elif D:
					C+=1;B.append(A)
					if C>=SILENCE_FRAMES:break
		return B if D else[]
	def _transcribe(self,frames:list)->str:
		L='text';K='no_speech_prob';M=_frames_to_wav_file(frames,gain=MIC_SOFTWARE_GAIN)
		if MIC_SOFTWARE_GAIN!=1.:dev_log(_A,f"software gain ×{MIC_SOFTWARE_GAIN} applied")
		try:
			E=self._get_client();B={'model':self._model,'file':M}
			if self._whisper_language:B['language']=self._whisper_language
			if self._model==_D:
				B['response_format']='verbose_json';C=E.audio.transcriptions.create(**B);F=getattr(C,'segments',_C)or[]
				if not F:return(C.text or'').strip()
				G=[]
				for(H,A)in enumerate(F):
					D=A.get(K,.0)if isinstance(A,dict)else getattr(A,K,.0);I=A.get(L,'')if isinstance(A,dict)else getattr(A,L,'');dev_log(_A,f"  seg[{H}] no_speech_prob={D:.2f}: '{I}'")
					if D<MAX_NO_SPEECH_PROB:G.append(I)
					else:dev_log(_A,f"  seg[{H}] DISCARDED — no_speech_prob={D:.2f} ≥ {MAX_NO_SPEECH_PROB} (hallucination guard)")
				return' '.join(A.strip()for A in G).strip()
			else:C=E.audio.transcriptions.create(**B);return(C.text or'').strip()
		except Exception as J:print(f"[openai-whisper] transcription error: {J}",flush=_B);dev_log('error',f"OpenAI transcription error: {J}");return''