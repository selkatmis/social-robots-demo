_A=None
import logging
from typing import Optional
from robond.asr.tts_base import optional_import
logger=logging.getLogger(__name__)
torch=optional_import('torch')
__all__=['torch','resolve_device']
def resolve_device(requested:Optional[str]=_A)->str:
	D='mps';C='cpu';A=requested
	if A:return A
	if torch is _A:return C
	if torch.cuda.is_available():return'cuda'
	B=getattr(getattr(torch,'backends',_A),D,_A)
	if B is not _A and B.is_available():return D
	return C