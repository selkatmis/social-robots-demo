_C='robot'
_B='local'
_A=None
import io,logging,threading,time,wave
from typing import Optional,Tuple
from robond.core.text import clean_for_speech
logger=logging.getLogger(__name__)
def optional_import(name:str):
	import importlib as A
	try:return A.import_module(name)
	except(ImportError,OSError)as B:logger.debug('%s unavailable: %s',name,B);return
sd=optional_import('sounddevice')
np=optional_import('numpy')
_OUTPUTS=_B,_C
def float_to_int16(samples):
	A=samples
	if hasattr(A,'detach'):A=A.detach().cpu().numpy()
	B=np.asarray(A,dtype=np.float32).reshape(-1);return(np.clip(B,-1.,1.)*32767.).astype(np.int16)
class TTSError(RuntimeError):0
class TTSSynthesisError(TTSError):0
class BaseTTSMixin:
	def __init__(self,*C,tts_lang:str='en-US',tts_output:str=_B,tts_clean:bool=True,tts_target_rate:Optional[int]=_A,tts_raise_on_error:bool=False,**D):
		B=tts_target_rate;A=tts_output
		if A not in _OUTPUTS:raise ValueError(f"tts_output must be one of {_OUTPUTS}, got {A!r}")
		if A==_C and not hasattr(self,'play_sound'):raise TTSError(f"tts_output='robot' needs a robot interface with play_sound(), but {type(self).__name__} has none. Mix this into a RobotInterface implementation, or use tts_output='local'.")
		if A==_B and sd is _A:raise TTSError("tts_output='local' needs sounddevice. Run: pip install sounddevice")
		if A==_B and np is _A:raise TTSError("tts_output='local' needs numpy. Run: pip install numpy")
		if B is not _A and np is _A:raise TTSError('tts_target_rate needs numpy for resampling. Run: pip install numpy')
		self._tts_locale=tts_lang;self._tts_output=A;self._tts_clean=tts_clean;self._tts_target_rate=B;self._tts_raise_on_error=tts_raise_on_error;self._tts_is_speaking=threading.Event();self._tts_engine_name=next((A.__name__ for A in type(self).__mro__ if'_synthesize_wav'in A.__dict__ and A is not BaseTTSMixin),type(self).__name__);super().__init__(*C,**D)
	def say(self,text:str)->_A:
		A=clean_for_speech(text,self._tts_locale)if self._tts_clean else text;self._tts_is_speaking.set()
		try:
			D=time.monotonic();B=self._synthesize_wav(A);E=time.monotonic()-D;self._log_synthesis(A,B,E);C=self._normalize_wav(B)
			if self._tts_output==_C:self._play_wav_robot(C)
			else:self._play_wav_local(C)
		except Exception as F:
			logger.error('TTS failed for %r: %s',A[:80],F,exc_info=True)
			if self._tts_raise_on_error:raise
		finally:self._tts_is_speaking.clear()
	def is_speaking(self)->bool:return self._tts_is_speaking.is_set()
	def coordinated_action(self,text:str,gesture=_A,expression=_A,**C)->_A:
		B=expression;A=gesture
		if B:self.set_expression(B)
		if A:self.play_gesture(A)
		self.say(text)
	def stop(self)->_A:
		if self._tts_output==_B and sd is not _A:sd.stop()
		self._tts_is_speaking.clear();A=getattr(super(),'stop',_A)
		if A is not _A:A()
	def _synthesize_wav(self,text:str)->bytes:raise NotImplementedError(f"{type(self).__name__} must implement _synthesize_wav()")
	def _play_wav_local(self,wav:bytes)->_A:
		A,C,B=self._from_wav_bytes(wav)
		if B>1:A=A.reshape(-1,B)
		sd.play(A,samplerate=C);sd.wait()
	def _play_wav_robot(self,wav:bytes)->_A:self.play_sound(wav)
	def _normalize_wav(self,wav:bytes)->bytes:
		B=wav
		if self._tts_target_rate is _A:return B
		A,E,C=self._from_wav_bytes(B)
		if C>1:A=A.reshape(-1,C).mean(axis=1).astype(np.int16)
		if E==self._tts_target_rate and C==1:return B
		F=int(round(len(A)*self._tts_target_rate/E));D=np.interp(np.linspace(0,len(A)-1,F),np.arange(len(A)),A.astype(np.float64));D=np.clip(np.round(D),-32768,32767).astype(np.int16);return self._to_wav_bytes(D,self._tts_target_rate)
	def _log_synthesis(self,text:str,wav:bytes,seconds:float)->_A:
		A=seconds;B=self._wav_duration(wav)
		if B:logger.info('%s synthesised %d chars in %.2fs (%.1fs audio, RTF %.2f)',self._tts_engine_name,len(text),A,B,A/B)
		else:logger.info('%s synthesised %d chars in %.2fs',self._tts_engine_name,len(text),A)
	@staticmethod
	def _wav_duration(wav:bytes)->Optional[float]:
		try:
			with wave.open(io.BytesIO(wav),'rb')as A:
				B=A.getframerate()
				if not B:return
				return A.getnframes()/B
		except Exception:return
	@staticmethod
	def _to_wav_bytes(data,samplerate:int,channels:int=1)->bytes:
		B=data;D=B.astype('<i2').tobytes()if hasattr(B,'astype')else bytes(B);C=io.BytesIO()
		with wave.open(C,'wb')as A:A.setnchannels(channels);A.setsampwidth(2);A.setframerate(samplerate);A.writeframes(D)
		return C.getvalue()
	@staticmethod
	def _from_wav_bytes(wav:bytes)->Tuple['np.ndarray',int,int]:
		with wave.open(io.BytesIO(wav),'rb')as A:
			if A.getsampwidth()!=2:raise TTSSynthesisError(f"Expected 16-bit PCM WAV, got {A.getsampwidth()*8}-bit")
			B=A.getnchannels();C=A.getframerate();D=A.readframes(A.getnframes())
		return np.frombuffer(D,dtype='<i2'),C,B