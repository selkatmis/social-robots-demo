# FOAF - Hackathon 2026

FOAF ("friend of a friend") is a social robot that helps people make new friends. It first gets to know people one at a time, then finds out who has the most in common and introduces them to each other.

`python main.py` opens a menu with four modes:

1. **New friend** - FOAF has a one-on-one conversation (name, study, languages, hobbies, music, food, films and series, travel), reacts to what the person says, asks a follow-up or an easier question when needed, and saves the answers as a profile in `profiles.json`.
2. **Matching** - choose a saved profile and FOAF finds the most similar other profile, topic by topic. It can then introduce the two people.
3. **Introduction** - pick any two saved profiles and FOAF introduces them to each other right away.
4. **Look around** - FOAF drives around the room, scanning and mapping as it goes, and comes back (see below).

People talk to FOAF through the laptop microphone; FOAF checks the microphone when it starts and uses the keyboard if there is none.

In an introduction FOAF greets both people and goes through the topics they have most in common (three by default, interests first): it brings up what each of them told it earlier, asks a question, lets both of them answer, taking turns in who goes first, reacts to the two answers together and moves on to the next topic. At the end it sums up what they found out they have in common and leaves them to keep talking. Every introduction is saved to `introductions.json`.

On the robot, FOAF's face follows what it says: Mistral marks every reaction with an expression (happy, excited, surprised, ...) that the robot shows while speaking, and FOAF waves when it greets and says goodbye and nods when it reacts to an answer. If Mistral is briefly unavailable, FOAF retries and otherwise carries on with a fixed line instead of stopping the conversation.

## Setup

You need [Python](https://www.python.org/downloads/) 3.10 or newer and a [Mistral API key](https://console.mistral.ai/).

> The commands below are written for **Windows**. On macOS/Linux, activate the virtual environment with `source hackathon2026/bin/activate` instead.

1. Clone this repository, open the folder in VSCode (or a similar editor) and open a terminal.
2. Create and activate a virtual environment:
   ```bash
   python -m venv hackathon2026
   hackathon2026\Scripts\activate
   ```
3. Install the dependencies, including the voice packages for the microphone (on macOS/Linux install PortAudio first, see the top of the file):
   ```bash
   pip install -r requirements.txt
   pip install -r requirements-voice.txt
   ```
4. Create a file called `.env` in the project folder with your Mistral API key:
   ```
   MISTRAL_API_KEY=your-key-here
   ```
5. Check that the robot packages work:
   ```bash
   python test.py
   ```

## Quick start: everything in one command

```bash
python start.py --install              # once: installs all packages
python start.py --host <ip-address>    # FOAF on ARI, with the touch interface on ARI's tablet
python start.py --demo                 # no robot: a pretend robot on this laptop, to try it all
```

`start.py --host` copies `ari_explore_proxy.py` to ARI over ssh and starts it there (enter ARI's password when ssh asks), waits until it answers, then starts FOAF with the interface and opens it on ARI's tablet. Ctrl+C stops everything, including the proxy on the robot. Add `--keyboard` to type instead of talking, `--no-base` to keep the robot from driving, `--ssh pal@ari-47c` if ARI's ssh name differs from its ip-address.

## Running FOAF

```bash
python main.py
```

FOAF's lines are printed in the terminal and spoken by the robot when one is connected; people answer through the laptop microphone (test it first with `python mic_test.py`). Settings for `.env`:

| Setting | What it does |
| --- | --- |
| `ROBOT_HOST=<ip-address>` | The robot says FOAF's lines, with the matching face and gestures. Start the robot's proxy first, see [robot_instructions.md](robot_instructions.md). |
| `ROBOT_PORT=7342` | Port of the proxy, only needed if you started it on a different port. |
| `ROBOT_TABLET_PAGE=<page>` | A page from ARI's web interface to show on its tablet while FOAF runs. |
| `FOAF_INPUT=keyboard` | Type the answers instead of using the microphone. |
| `WHISPER_MODEL=small` | Speech recognition model for the microphone. `base` is faster, `medium` is more accurate. |
| `INTRO_TOPICS=3` | Number of topics in an introduction. |

### On ARI

Start ARI's proxy (see [robot_instructions.md](robot_instructions.md)), then from the laptop:

```bash
python ari.py --host <ip-address> --test   # ARI tries every expression, gesture, speech, sound and the tablet
python ari.py --host <ip-address>          # FOAF's menu, spoken by ARI
```

`--host` can be left out when `ROBOT_HOST` is in `.env`. Gestures or expressions ARI does not have are skipped automatically.

### Looking around and mapping the room

For this, run `ari_explore_proxy.py` on ARI instead of the stock proxy (copy the file to the robot; it needs the same virtual environment as the stock proxy):

```bash
python3 ari_explore_proxy.py --port 7342 --language en-US
```

It does everything the stock proxy does, plus head movement, turning, driving and reading ARI's laser or depth camera. Then, from the laptop:

```bash
python explore.py --host <ip-address>             # or option 4 in main.py
python explore.py --host <ip-address> --legs 5    # explore a bit further
python explore.py --host <ip-address> --no-drive  # only look around and scan from where it is
```

FOAF looks around with its head, turns a full circle reading the camera as it goes, picks the most open direction, drives there, scans again, and so on (3 legs by default). Then it says what it found, drives back to where it started, prints a map of the room and saves it with the path it drove to `room_map.json`:

```
#  what it saw      .  floor it looked across
S  start            o  where it drove        R  the robot now
```

Driving is slow and short on purpose (at most 1 m per leg at 0.15 m/s, always towards open space) and the robot stops by itself when something comes within 50 cm. `--no-base` on the proxy disables all base movement; then FOAF only looks around and scans. To try the whole thing without a robot, run `python ari_explore_proxy.py --fake --port 7342` on the laptop: it pretends to be ARI in a small room.

### Touch interface

Instead of the terminal menu, FOAF can be driven from a page with big buttons, meant for ARI's tablet but fine on a phone or any browser on the same wifi:

```bash
python ui.py --host <ip-address>             # prints the address, e.g. http://192.168.1.20:8080
python ui.py --host <ip-address> --tablet    # ... and opens it on ARI's tablet (needs ari_explore_proxy.py on ARI)
```

The page has buttons for New friend, Matching (with an "Introduce ..." button once a match is found), Introduction, Look around and Stop. It shows the conversation as it happens, when FOAF is listening, and draws the map of the room after FOAF has explored it. With `FOAF_INPUT=keyboard` a text field appears whenever FOAF waits for an answer. Black and white, Ubuntu font.

The parts can also be run on their own: `python new_friend.py` for a single one-on-one conversation, or `python introduction.py` to introduce two saved profiles.

## Files

| File | |
| --- | --- |
| `start.py` | One command that starts the proxy on ARI, FOAF and the interface |
| `main.py` | Menu: New friend, Matching, Introduction or Look around |
| `ari.py` | Runs FOAF on ARI, with a hardware check |
| `explore.py`, `ari_explore_proxy.py` | FOAF drives around, scans and maps the room; the proxy to run on ARI for that |
| `ui.py` | Touch interface with buttons for everything, for ARI's tablet or any browser |
| `new_friend.py`, `1on1-prompts.json` | One-on-one conversation, with its questions and prompts |
| `matching.py` | Finds the best match by comparing profiles topic by topic with sentence embeddings |
| `introduction.py`, `intro_prompts.json` | Introduces two people to each other, topic by topic |
| `llm.py` | Mistral calls, with retries and fallback lines |
| `robot.py` | Robot speech, expressions and gestures, and listening by keyboard or microphone |
| `profiles.py`, `profiles.json` | Saved profiles |
| `introductions.json` | Transcripts of the introductions FOAF has done |
| `room_map.json` | The last map FOAF made of the room |
| `robot_instructions.md` | How to start the proxy on each robot |
