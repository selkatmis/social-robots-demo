from shared.llm2 import LLM

llm = LLM()

answer = llm.prompt("Leg breuken uit in het Nederlands.")
print(answer)

another_answer = llm.prompt("Geef een voorbeeld met pizza.")
print(another_answer)