# Robot Code Quickstart Guide

This guide covers how to run code on each robot.

---

## Group 1: Navel, NAO, ARI, QT

**Workflow:** SSH into the robot and start the proxy, then run your script from your laptop. Read "[Start Proxy](https://git.vu.nl/robot-interaction/hackathon2026/-/blob/main/robot_instructions.md?ref_type=heads#start-proxy)" and "[Then, from the VSCode terminal](https://git.vu.nl/robot-interaction/hackathon2026/-/blob/main/robot_instructions.md?ref_type=heads#then-from-the-vscode-terminal)"

### Start Proxy

Open the command prompt (type command prompt in the windows search bar), and copy-paste your robot-specific lines one by one

#### Navel

```bash
ssh navel@<ip-address>
cd robond
source venv/bin/activate
robond-navel-proxy --port 7342 --language en-US
```



#### NAO

```bash
ssh nao@<ip-address>
source /home/nao/robond/bin/activate
python /home/nao/nao_proxy.py --port 7342 --language en-US
```



#### ARI

```bash
ssh pal@ari-47c
source robond-venv/bin/activate
python3 -m robond.robot.proxy.ari_proxy --port 7342 --language en-US
```



#### QTRobot

Need to start relay on QTRP first, and proxy on QTPC after. (I will look into automating this)

Open two Command Prompts (cmd), one for the relay on QTRP: 

```bash
ssh developer@ip-address
su qtrobot
cd  qtrp_relay/relay_env
python3 -m robond.robot.proxy.relay
```

And one for the proxy on QTPC:

```bash
ssh developer@ip-address
su qtrobot
ssh qtpc
cd ~/catkin_ws/src/qt_proxy
source venv/bin/activate
python3 -m robond.robot.proxy.qt_proxy --port 7342 --language en_US --volume 130
```



### Then, from the VSCode terminal:

I am assuming you already have the hackathon2026 Git repo, and that you have a virtual environment set up, following the structure from the setup README.

```bash
cd hackathon2026
hackathon2026\Scripts\activate
python navel.py
```

> Replace `navel.py` with `nao.py`, `ari.py`, or `qtrobot.py` depending on which robot you're running.
>
> For ARI with FOAF: `python ari.py --host <ip-address> --test` runs a hardware check first, and `python ari.py --host <ip-address>` starts FOAF on the robot (see the README).
>
> To let FOAF drive around and map the room, start `python3 ari_explore_proxy.py --port 7342 --language en-US` on ARI instead of the stock proxy (copy the file to the robot first). It does everything the stock proxy does as well.

Notes:

In the robot code, these robots are called with

```bash
robot = RemoteRobotInterface(host="ip-address", port=7342, listener=None)
```

---



## Group 2: Furhat, Mini, Misty

**Workflow:** run a script directly from VSCode. 

I am assuming you already have the hackathon2026 Git repo, and that you have a virtual environment set up, following the structure from the setup README.

### Furhat

1. Open a browser and fill in the robot's IP address in the search bar to open the web interface
2. Click "Real-time API" and start it from there 
3. From the VSCode terminal, run script

```bash
cd hackathon2026
hackathon2026\Scripts\activate
python furhat.py
```



#### Notes:

In the robot code, Furhat is called with 

```bash
robot = FurhatRobotInterface(host="ip-address", listener=None, auth_key = "furhat_key") 
```



### Mini

1. Run script

```bash
cd hackathon2026
hackathon2026\Scripts\activate
python mini.py
```



#### Notes:

In the robot code, Mini is called with 

```bash
robot = AlphaMiniRobotInterface(ip="ip-address", listener=None, tts_lang = "en-US", http_port=8765)
```



### Misty

Run script

```bash
cd hackathon2026
hackathon2026\Scripts\activate
python misty.py
```



#### Notes:

In the robot code, Misty is called with 

```bash
robot = MistyRobotInterface(host="ip-address", listener=None)
```

---



## Group 3: Buddy, iPal

**Workflow:** start the proxy directly on the robot's own screen, then run your script from VSCode.

I am assuming you already have the hackathon2026 Git repo, and that you have a virtual environment set up, following the structure from the setup README.

### Buddy

1. Look for "Proxy" app from the app menu and open it. "Proxy started" message will appear.
2. From your VSCode terminal, run script

```bash
cd hackathon2026
hackathon2026\Scripts\activate
python buddy.py
```



#### Notes

In the robot code, Buddy is called with

```bash
robot = RemoteRobotInterface(host="ip-address", port=7342, listener = None)
```



### iPal

1. Look for "Other" or "Anders" in the app menu, and select "MyApplication". 
 The screen will turn black and a "Proxy started" message will appear
2. From your laptop, run script

```bash
cd hackathon2026
hackathon2026\Scripts\activate
python ipal.py
```



#### Notes

In the robot code, iPal is called with

```bash
robot = RemoteRobotInterface(host="ip-address", port=7342, listener = None)
```

